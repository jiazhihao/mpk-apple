import os
os.environ['VLLM_ENABLE_V1_MULTIPROCESSING']='0'
os.environ['HF_HUB_OFFLINE']='1'
os.environ['HF_HOME']='/tmp/monolith-m5max/baseline-verify/hf-cache'
os.environ['VLLM_CACHE_ROOT']='/tmp/monolith-m5max/baseline-verify/vllm-cache'
from vllm import LLM,SamplingParams
m=LLM(model='/tmp/monolith-models/Qwen3.8-27B-NVFP4',dtype='bfloat16',max_model_len=33024,max_num_seqs=1,max_num_batched_tokens=128,gpu_memory_utilization=0.7,enable_prefix_caching=False,enable_chunked_prefill=True,enforce_eager=True,disable_log_stats=True,async_scheduling=False)
print('LOADED',flush=True)
print(m.generate([{'prompt_token_ids':[561]*136}],SamplingParams(max_tokens=1,temperature=0),use_tqdm=False),flush=True)
