import sys,json,pathlib,numpy as np,statistics,hashlib
sys.path.insert(0,'/Users/zhihaojia/lithos/mpk-apple')
from monolith.formats.safetensors_reader import SafetensorsDir
from monolith.formats.fp import bf16_to_f32
b=pathlib.Path('/tmp/monolith-m5max/baseline-verify')
def load(p):
 ck=SafetensorsDir(p);v=ck.get('logits');return (bf16_to_f32(v) if ck.info('logits').dtype=='BF16' else v).reshape(8,-1).astype(np.float64)
def compare(p,q):
 x,y=load(p),load(q);cos=np.sum(x*y,1)/np.sqrt(np.sum(x*x,1)*np.sum(y*y,1))
 return {'min_cosine':float(cos.min()),'cosine_per_row':cos.tolist(),'argmax_equal':int(np.sum(x.argmax(1)==y.argmax(1))),'max_abs':float(np.max(np.abs(x-y))),'left_argmax':x.argmax(1).tolist(),'right_argmax':y.argmax(1).tolist()}
validation={'ollama_serial':{},'ollama_snapshot_equivalence':{},'cross_backend':{},'vllm_serial':[]}
for ctx in [128,4096,8192,16384,32768]:
 x=b/f'ollama-logits-{ctx}-false.safetensors';y=b/f'ollama-serial-logits-{ctx}.safetensors';z=b/f'ollama-logits-{ctx}-true.safetensors'
 if all(p.exists() for p in [x,y,z]):
  validation['ollama_serial'][ctx]=compare(x,y);assert validation['ollama_serial'][ctx]['min_cosine']>.999
  validation['ollama_snapshot_equivalence'][ctx]=bool(np.array_equal(load(x),load(z)));assert validation['ollama_snapshot_equivalence'][ctx]
 v=b/f'vllm-bf16-logits-{ctx}.safetensors'
 if x.exists() and v.exists():validation['cross_backend'][ctx]=compare(x,v)
if (b/'serial-audit.jsonl').exists():validation['vllm_serial']=[json.loads(l) for l in (b/'serial-audit.jsonl').read_text().splitlines()]
if (b/'vllm-bf16-validation.jsonl').exists():
 perf={r['context']:r for r in map(json.loads,(b/'vllm-bf16.jsonl').read_text().splitlines())}
 rerun={r['context']:r for r in map(json.loads,(b/'vllm-bf16-validation.jsonl').read_text().splitlines())}
 validation['vllm_bf16_independent_run_hash_agreement']={str(c):perf[c]['logits_sha256']==rerun[c]['logits_sha256'] for c in perf}
 assert all(validation['vllm_bf16_independent_run_hash_agreement'].values())
(b/'validation.json').write_text(json.dumps(validation,indent=2))
summary=[]
for name in ['ollama.jsonl','vllm-bf16.jsonl','vllm-mxfp8.jsonl']:
 if not (b/name).exists():continue
 for line in (b/name).read_text().splitlines():
  x=json.loads(line);ws=x.pop('wall_ms');x.pop('active_memory_samples',None)
  x.update(min_ms=min(ws),median_ms=statistics.median(ws),max_ms=max(ws),repetitions=len(ws));summary.append(x)
(b/'summary.json').write_text(json.dumps(summary,indent=2))
for x in summary:print(x['engine'],x.get('fp8_mode'),x['context'],x.get('capture_per_token_states'),round(x['median_ms'],2),round(x['min_ms'],2))
print('Ollama serial minimum cosine',min(x['min_cosine'] for x in validation['ollama_serial'].values()))
