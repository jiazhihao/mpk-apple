import os,sys,dataclasses
os.environ['VLLM_ENABLE_V1_MULTIPROCESSING']='0'
os.environ['HF_HUB_OFFLINE']='1'
os.environ['HF_HOME']='/tmp/monolith-m5max/baseline-verify/hf-cache'
os.environ['VLLM_CACHE_ROOT']='/tmp/monolith-m5max/baseline-verify/vllm-cache'
sys.path[:0]=['/Users/zhihaojia/lithos/mpk-apple','/Users/zhihaojia/lithos/mpk-apple/tools/bench']
from vllm import LLM,SamplingParams
from vllm_metal.v1.model_lifecycle import ModelLifecycle,GenerationLoadRequest
from modelopt_full_mlx import load_full
old=GenerationLoadRequest.from_runner.__func__
GenerationLoadRequest.from_runner=classmethod(lambda cls,*a,**k: dataclasses.replace(old(cls,*a,**k),is_vlm=False))
ModelLifecycle._load_generation_model=lambda self,model_name,*a,**k:load_full(model_name,os.environ.get('VERIFY_FP8_MODE','bf16'))
m=LLM(model='/tmp/monolith-models/Qwen3.8-27B-NVFP4',dtype='bfloat16',max_model_len=33024,max_num_seqs=1,max_num_batched_tokens=128,kv_cache_memory_bytes=4*1024**3,enable_prefix_caching=False,enable_chunked_prefill=True,enforce_eager=True,disable_log_stats=True,async_scheduling=False)
print('LOADED',flush=True)
print(m.generate([{'prompt_token_ids':[561]*136}],SamplingParams(max_tokens=1,temperature=0),use_tqdm=False),flush=True)
