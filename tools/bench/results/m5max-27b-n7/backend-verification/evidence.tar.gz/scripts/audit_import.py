import sys,json,pathlib,numpy as np
sys.path.insert(0,'/Users/zhihaojia/lithos/mpk-apple')
from monolith.formats.safetensors_reader import SafetensorsDir,read_header
b=pathlib.Path('/tmp/monolith-m5max/baseline-verify');src=SafetensorsDir('/tmp/monolith-models/Qwen3.8-27B-NVFP4')
m=json.loads((b/'ollama-models/manifests/registry.ollama.ai/library/monolith-benchmark-qwen38-nvfp4-bf16/latest').read_text())
results=[]
for l in m['layers']:
 if l['mediaType']!='application/vnd.ollama.image.tensor':continue
 p=b/'ollama-models/blobs'/l['digest'].replace(':','-')
 infos,meta=read_header(p)
 for n,info in infos.items():
  if n.endswith('.weight') and n in src.infos and src.info(n).dtype=='U8':
   ck=SafetensorsDir(p)
   checks={'weight_bytes':np.array_equal(ck.get(n).view(np.uint8).reshape(-1),src.get(n).reshape(-1)), 'block_scale_bytes':np.array_equal(ck.get(n+'.scale').view(np.uint8).reshape(-1),src.get(n.removesuffix('.weight')+'.weight_scale').view(np.uint8).reshape(-1)), 'global_scale':np.array_equal(ck.get(n+'.global_scale').reshape(-1),src.get(n.removesuffix('.weight')+'.weight_scale_2').reshape(-1))}
   results.append({'tensor':n,**checks})
assert len(results)==193,len(results)
assert all(all(v for k,v in r.items() if k!='tensor') for r in results)
(b/'ollama-import-audit.json').write_text(json.dumps({'nvfp4_matrices':len(results),'all_exact':True,'checks':results},indent=2))
print('AUDIT PASS',len(results))
