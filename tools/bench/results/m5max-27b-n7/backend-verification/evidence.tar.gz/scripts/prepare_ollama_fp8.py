import sys,json,pathlib,hashlib,shutil,collections,numpy as np
sys.path.insert(0,'/Users/zhihaojia/lithos/mpk-apple')
from monolith.formats.safetensors_reader import SafetensorsDir,write_safetensors
from monolith.formats.fp import e4m3_to_f32,f32_to_bf16
src=pathlib.Path('/tmp/monolith-models/Qwen3.8-27B-NVFP4');dst=pathlib.Path('/tmp/monolith-m5max/baseline-verify/checkpoint-fp8-bf16');dst.mkdir(exist_ok=True)
ck=SafetensorsDir(src); fp8={n for n in ck.names() if n.endswith('.weight') and ck.info(n).dtype=='F8_E4M3'}
skip={n.removesuffix('.weight')+'.weight_scale' for n in fp8}|{n for n in ck.names() if n.endswith('.input_scale')}
groups=collections.defaultdict(list)
for n in ck.names():
 if n in skip:continue
 parts=n.split('.');group='layer-'+parts[parts.index('layers')+1] if 'layers' in parts else 'other'
 groups[group].append(n)
index={};audit=[]
for group,names in groups.items():
 tensors={}
 for n in names:
  a=ck.get(n);dtype=ck.info(n).dtype
  if n in fp8:
   scale=ck.get(n.removesuffix('.weight')+'.weight_scale');assert scale.size==1
   a=f32_to_bf16(e4m3_to_f32(a)*scale);dtype='BF16'
   audit.append({'tensor':n,'transform':'BF16(e4m3_decode(codes) * original_fp32_scale)'})
  tensors[n]=(dtype,a);index[n]=group+'.safetensors'
 write_safetensors(dst/(group+'.safetensors'),tensors,{'format':'pt'})
 print(group,flush=True)
for f in src.iterdir():
 if f.suffix in ('.json','.txt','.jinja') and f.name!='model.safetensors.index.json':shutil.copy2(f,dst/f.name)
(dst/'model.safetensors.index.json').write_text(json.dumps({'weight_map':index}))
(dst/'fp8-materialization.json').write_text(json.dumps({'source':str(src),'fp8_matrices':len(fp8),'transforms':audit,'nvfp4':'codes/block scales/global scales copied unchanged'},indent=2))
