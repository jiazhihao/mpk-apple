#include <metal_stdlib>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
using namespace mpp::tensor_ops;
constexpr constant auto desc=matmul2d_descriptor(M_ROWS,N_COLS,K_COLS,false,true,false,matmul2d_descriptor::mode::multiply_accumulate);
kernel void probe(device const bfloat* x [[buffer(0)]], device float* y [[buffer(1)]], uint tid [[thread_index_in_simdgroup]]) {
 matmul2d<desc,execution_simdgroup> op;
 auto a=op.get_left_input_cooperative_tensor<bfloat,bfloat,float>();
 auto b=op.get_right_input_cooperative_tensor<bfloat,bfloat,float>();
 auto c=op.get_destination_cooperative_tensor<decltype(a),decltype(b),float>();
 for(uint16_t i=0;i<a.get_capacity();i++)a[i]=x[tid*a.get_capacity()+i];
 for(uint16_t i=0;i<b.get_capacity();i++)b[i]=x[tid*b.get_capacity()+i];
 for(uint16_t i=0;i<c.get_capacity();i++)c[i]=0.f;
 op.run(a,b,c);
 for(uint16_t i=0;i<c.get_capacity();i++)y[tid*c.get_capacity()+i]=c[i];
}
