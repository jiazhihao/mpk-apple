import json, collections, csv
from pathlib import Path
root=Path(__file__).resolve().parent
phases=['geometry','structural','scheduler','fp8','projection','packing','packing-geometry','packing-wide','half-operand','extended','occupancy','nonpower','codegen','traversal','prefetch','interleave','predecoded','independent-grid','polling','refine-knobs','refine-workers','refine-projections','refine-projection-families','refine-interactions','refine-polish','refinement']
summary={}; flattened=[]; total=0
for phase in phases:
 path=root/(phase+'.jsonl')
 if not path.exists():continue
 rows=[json.loads(s) for s in path.read_text().splitlines()]
 good=[r for r in rows if 'results' in r]
 total+=len(rows)
 ratio=lambda r:r['results']['single_kernel']['gpu_us']/r['results']['previous_geometry']['gpu_us']
 best=min(good,key=ratio) if good else None
 summary[phase]=dict(trials=len(rows),accepted=len(good),rejected=len(rows)-len(good),best=best,
                    rejections=dict(collections.Counter(r['error'].splitlines()[0] for r in rows if 'error' in r)))
 for index,r in enumerate(rows):
  item=dict(phase=phase,index=index,config=json.dumps(r['config'],sort_keys=True),error=r.get('error',''))
  if 'results' in r:
   item.update({n+'_'+m:v for n,vs in r['results'].items() for m,v in vs.items()})
   item['ratio_previous_gpu']=ratio(r)
   item['cosine']=r['check']['cosine'];item['relative_l2']=r['check']['relative_l2']
  flattened.append(item)
 print(phase,len(rows),len(good),round(ratio(best),5) if best else None)
 if best:print('  ',best['config'],{n:round(v['gpu_us'],2) for n,v in best['results'].items()})
(root/'screen-summary.json').write_text(json.dumps(dict(total_trials=total,phases=summary),indent=2)+'\n')
fields=list(dict.fromkeys(k for row in flattened for k in row))
with (root/'tuning.csv').open('w') as f:
 w=csv.DictWriter(f,fields);w.writeheader();w.writerows(flattened)
print('Total trials',total)
