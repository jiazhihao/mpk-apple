"""Compiler capability probe only: creates no queue and dispatches no GPU work."""
import json,itertools,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from monolith.runtime import _native as nt
root=Path(__file__).resolve().parent
dev=nt.Device();rows=[]
source='''#include <metal_stdlib>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
using namespace mpp::tensor_ops;
constexpr constant auto desc=matmul2d_descriptor(M_ROWS,N_COLS,K_COLS,false,true,false,matmul2d_descriptor::mode::multiply_accumulate);
kernel void probe(device const bfloat* x [[buffer(0)]], device float* y [[buffer(1)]], uint tid [[thread_index_in_simdgroup]]) {
 matmul2d<desc,execution_simdgroup> op;
 auto a=op.get_left_input_cooperative_tensor<bfloat,bfloat,float>();
 auto b=op.get_right_input_cooperative_tensor<bfloat,bfloat,float>();
 auto c=op.get_destination_cooperative_tensor<decltype(a),decltype(b),float>();
 for(uint16_t i=0;i<a.get_capacity();i++)a[i]=x[tid*a.get_capacity()+i];
 for(uint16_t i=0;i<b.get_capacity();i++)b[i]=x[tid*b.get_capacity()+i];
 for(uint16_t i=0;i<c.get_capacity();i++)c[i]=0.f;
 op.run(a,b,c);
 for(uint16_t i=0;i<c.get_capacity();i++)y[tid*c.get_capacity()+i]=c[i];
}
'''
(root/'shape_compile_probe.metal').write_text(source)
for m,n,k in itertools.product((8,16,32),(8,16,32,64),(16,32,64,128)):
 row=dict(m=m,n=n,k=k)
 try:
  lib=nt.Library(dev,source,{'M_ROWS':str(m),'N_COLS':str(n),'K_COLS':str(k)},4<<16)
  pipeline=nt.Pipeline(lib,'probe')
  row['compiled']=True
 except RuntimeError as exc:row.update(compiled=False,error=str(exc))
 rows.append(row)
 print(m,n,k,row['compiled'],flush=True)
(root/'shape_compile_probe.json').write_text(json.dumps(rows,indent=2)+'\n')
