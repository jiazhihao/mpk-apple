#!/bin/zsh
# Run only after finalist selection, profile promotion and validation of that recipe.
# No detached or concurrent launch: Metal timings must remain serial.
set -e
cd /Users/zhihaojia/lithos/mpk-apple
study_root=/tmp/monolith-m5max/gdn-exhaustive
study_layers=$(.venv/bin/python -c 'print(",".join(str(i) for i in range(64) if i%4!=3))')
common=(--model /tmp/monolith-models/Qwen3.8-27B-NVFP4 --pack /tmp/monolith-m5max/target-pack --layers "$study_layers" --ctx 128 --fusion --fusion-scope mixer-prefix --config "$study_root/selected-layer.json" --reference-config "$study_root/baseline-layer.json" --reference-fusion-scope mixer-prefix --comparison-control-config "$study_root/selected-control-layer.json" --default-fusion)
for required in selected.json selected-layer.json selected-control-layer.json; do
  [[ -f "$study_root/$required" ]] || { print "Missing reviewed selection: $required"; exit 1; }
done
# Refuse to append to existing evidence accidentally.
for output in all48-shader.jsonl chain5-shader.json all48.jsonl chain5.json chain64-real.json; do
  [[ ! -f "$study_root/$output" ]] || { print "Existing evidence: $output"; exit 1; }
done
env MTL_SHADER_VALIDATION=1 MTL_SHADER_VALIDATION_REPORT_TO_STDERR=1 .venv/bin/python -m pytest tests/kernels/test_gdn_block_static.py tests/kernels/test_gdn_default.py tests/kernels/test_attention_static.py tests/kernels/test_mlp_block_static.py tests/contract -q > "$study_root/final-regressions.log" 2>&1
env MTL_SHADER_VALIDATION=1 MTL_SHADER_VALIDATION_REPORT_TO_STDERR=1 .venv/bin/python tools/bench/modelopt_layer_bench.py "${common[@]}" --no-mlx --reps 1 --steps 2 --out "$study_root/all48-shader.jsonl" > "$study_root/all48-shader.log" 2>&1
env MTL_SHADER_VALIDATION=1 MTL_SHADER_VALIDATION_REPORT_TO_STDERR=1 .venv/bin/python "$study_root/chain_compare.py" --config "$study_root/selected.json" --reference "$study_root/baseline.json" --layers 5 --reps 1 --steps 2 --out "$study_root/chain5-shader.json" > "$study_root/chain5-shader.log" 2>&1
.venv/bin/python tools/bench/modelopt_layer_bench.py "${common[@]}" --fp8-mode both --fail-on-regression --reps 9 --steps 32 --out "$study_root/all48.jsonl" > "$study_root/all48.log" 2>&1
.venv/bin/python "$study_root/layer_summary.py" "$study_root/all48.jsonl" --prefix "$study_root/all48" > "$study_root/all48-summary.log"
.venv/bin/python "$study_root/chain_compare.py" --config "$study_root/selected.json" --reference "$study_root/baseline.json" --layers 5 --reps 9 --steps 16 --out "$study_root/chain5.json" > "$study_root/chain5.log" 2>&1
.venv/bin/python -c 'import json;from pathlib import Path;p=Path("/tmp/monolith-m5max/gdn-exhaustive");(p/"selected-list.json").write_text(json.dumps([json.loads((p/"selected.json").read_text())],indent=2)+"\n")'
for study_layer in 0 1 30 62; do
  [[ ! -f "$study_root/mixer-${study_layer}.jsonl" ]] || { print "Existing isolated mixer evidence"; exit 1; }
  .venv/bin/python tools/bench/modelopt_mega_tune.py --model /tmp/monolith-models/Qwen3.8-27B-NVFP4 --pack /tmp/monolith-m5max/target-pack --kind gdn --layer "$study_layer" --configs "$study_root/selected-list.json" --reference-config "$study_root/baseline.json" --reps 9 --steps 32 --out "$study_root/mixer-${study_layer}.jsonl" > "$study_root/mixer-${study_layer}.log" 2>&1
done
# Real prompt embeddings and zero initial state; the synthetic 64-layer stress
# has a documented accumulated-accuracy failure and is not a timing baseline.
.venv/bin/python "$study_root/chain_compare.py" --config "$study_root/selected.json" --reference "$study_root/baseline.json" --layers 64 --real-inputs --reps 9 --steps 16 --out "$study_root/chain64-real.json" > "$study_root/chain64-real.log" 2>&1
