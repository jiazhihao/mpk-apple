#!/bin/zsh
set -e
cd /Users/zhihaojia/lithos/mpk-apple
study_root=/tmp/monolith-m5max/gdn-exhaustive
# This is the known launcher of this study, not a system-wide GPU lock.
while kill -0 33111 2>/dev/null; do sleep 10; done
cp monolith/compiler/static_fusion.py "$study_root/refinement-compiler.py"
cp monolith/compiler/gdn_fusion.py "$study_root/refinement-gdn-fusion.py"
cp monolith/compiler/fp8_tiles.py "$study_root/refinement-fp8-tiles.py"
env MTL_SHADER_VALIDATION=1 MTL_SHADER_VALIDATION_REPORT_TO_STDERR=1 .venv/bin/python -m pytest tests/kernels/test_gdn_block_static.py tests/kernels/test_gdn_default.py -q > "$study_root/refinement-tests.log" 2>&1
env MTL_SHADER_VALIDATION=1 MTL_SHADER_VALIDATION_REPORT_TO_STDERR=1 .venv/bin/python tools/bench/modelopt_mega_tune.py --model /tmp/monolith-models/Qwen3.8-27B-NVFP4 --pack /tmp/monolith-m5max/target-pack --kind gdn-prefix --configs "$study_root/refinement-smoke-configs.json" --reference-config "$study_root/baseline.json" --reps 1 --steps 2 --out "$study_root/refinement-smoke.jsonl" > "$study_root/refinement-smoke.log" 2>&1
.venv/bin/python -c 'import json;from pathlib import Path;r=[json.loads(s) for s in Path("/tmp/monolith-m5max/gdn-exhaustive/refinement-smoke.jsonl").read_text().splitlines()];assert len(r)==4 and all("results" in v for v in r),r'
env MTL_SHADER_VALIDATION=1 MTL_SHADER_VALIDATION_REPORT_TO_STDERR=1 .venv/bin/python -m pytest tests/contract -q > "$study_root/all-contract-metal.log" 2>&1
for study_phase in traversal refine-knobs refine-workers refine-projections refine-interactions; do
  if [[ "$study_phase" == refine-* ]]; then
    .venv/bin/python "$study_root/build_refinement.py" --stage "${study_phase#refine-}" >> "$study_root/refinement-plan.log"
  fi
  cp monolith/compiler/static_fusion.py "$study_root/${study_phase}-compiler.py"
  .venv/bin/python tools/bench/modelopt_mega_tune.py --model /tmp/monolith-models/Qwen3.8-27B-NVFP4 --pack /tmp/monolith-m5max/target-pack --kind gdn-prefix --configs "$study_root/${study_phase}-configs.json" --reference-config "$study_root/baseline.json" --reps 5 --steps 16 --out "$study_root/${study_phase}.jsonl" > "$study_root/${study_phase}.log" 2>&1
done

.venv/bin/python "$study_root/select_finalists.py" > "$study_root/finalists-plan.log"
for study_layer in 0 1 30 62; do
  .venv/bin/python tools/bench/modelopt_mega_tune.py --model /tmp/monolith-models/Qwen3.8-27B-NVFP4 --pack /tmp/monolith-m5max/target-pack --kind gdn-prefix --layer "$study_layer" --configs "$study_root/finalists-configs.json" --reference-config "$study_root/baseline.json" --reps 9 --steps 32 --out "$study_root/finalists-${study_layer}.jsonl" > "$study_root/finalists-${study_layer}.log" 2>&1
done
