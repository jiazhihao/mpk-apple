"""Fixed-input decoder chain audit/timing; no tokens, sampling or speculation."""
import argparse,copy,json,sys,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from monolith.core import Graph,DType,T
from monolith.nn import LowerContext,state_shape
from monolith.compiler import emit_program
from monolith.compiler.passes import DEFAULT_PASSES
from monolith.generate import Session
from monolith.runtime import Engine
from monolith.formats.fp import bf16_to_f32, f32_to_bf16
from tools.bench.layer_vs_mlx import our_model
from tools.bench.modelopt_layer_bench import initialize,inputs,metrics,run_engine,source_digest

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--config',type=Path,required=True)
ap.add_argument('--reference',type=Path,required=True)
ap.add_argument('--layers',type=int,default=5)
ap.add_argument('--out',type=Path,required=True)
ap.add_argument('--reps',type=int,default=9)
ap.add_argument('--steps',type=int,default=16)
ap.add_argument('--real-inputs',action='store_true',help='Use real prompt embeddings and zero initial model state')
a=ap.parse_args()
sess=Session(our_model('/tmp/monolith-models/Qwen3.8-27B-NVFP4',None,512),'/tmp/monolith-m5max/target-pack')
g=Graph('fixed_decoder_chain');lc=LowerContext(t=T)
for name,(dtype,arr) in sess.model.tables().items():lc.consts[name]=g.const(name,tuple(arr.shape),DType.parse(dtype.lower()))
h=g.input('hidden',(T,5120),DType.BF16);outputs=[]
for layer in sess.model.layers()[:a.layers]:
 for entry in layer.mixer.state_entries():lc.states[entry.name]=g.state(entry.name,state_shape(entry),entry.dtype)
 h=layer.mixer.lower(g,h,layer.input_norm.lower(g,h),lc)
 h=layer.mlp.lower(g,h,layer.post_norm.lower(g,h),lc)
 outputs.append(h.name)
g.check()
for ps in DEFAULT_PASSES:ps(g)
configs={'original':None,'previous':json.loads(a.reference.read_text()),'candidate':json.loads(a.config.read_text())}
programs={};engines={};shared={}
for name,cfg in configs.items():
 profile=copy.deepcopy(sess.profile)
 if cfg:profile.gdn_mixer_fusion=dict(cfg,shape=[5120,16,48,128,128,4])
 program=emit_program(g,pack=sess.pack,profile=profile,t=8,tuner=sess.tuner,tail=None,gdn_mixer_fusion=cfg is not None)
 programs[name]=program;engines[name]=Engine(program,sess.dev,buffers=shared)
 shared.update({n:b for n,b in engines[name].buffers.items() if program.buffers[n].role=='weights'})
 expected=sum(i%4!=3 for i in range(a.layers))
 assert sum(o.name=='gdn_mixer_megakernel' for o in program.ops)==(expected if cfg else 0)
for i,layer in enumerate(sess.model.layers()[:a.layers]):
 x,state=inputs(layer,i,128)
 for e in engines.values():initialize(e,layer,x,state,128,'layer')
real_inputs=None
if a.real_inputs:
 from tokenizers import Tokenizer
 from monolith.formats.safetensors_reader import SafetensorsDir
 tokenizer=Tokenizer.from_file('/tmp/monolith-models/Qwen3.8-27B-NVFP4/tokenizer.json')
 text='The scientific method begins with a question, develops a testable hypothesis, and compares predictions with careful observations. Measurements should be repeated and uncertainty reported. Explain how controlled experiments help separate cause from correlation.'
 ids=tokenizer.encode(text,add_special_tokens=False).ids[:32]
 assert len(ids)==32
 ck=SafetensorsDir('/tmp/monolith-models/Qwen3.8-27B-NVFP4')
 embedding=ck.get('model.language_model.embed_tokens.weight')
 assert embedding.dtype==np.uint16,embedding.dtype
 real_inputs=[np.array(embedding[ids[i:i+8]],copy=True).tobytes() for i in range(0,32,8)]
 del embedding;ck.close()
 for e in engines.values():
  for name,spec in e.program.buffers.items():
   if spec.role=='state':e.buffers[name].fill(0)
# Reuse exact emitted chain segments, but feed each the original chain's input
# and read-state. Private activations/states prevent the local audit from changing
# either complete chain. This isolates local errors from accumulated differences.
from monolith.runtime.program import Program
local_engines=[];start=0;cp=programs['candidate']
for index,output in enumerate(outputs):
 end=next(j+1 for j,op in enumerate(cp.ops) if j>=start and any(n==output and slot in op.meta.get('writes',[]) for slot,n,off in op.bindings))
 ops=cp.ops[start:end];start=end
 names={n for op in ops for _,n,_ in op.bindings}|{cp.step_state,cp.ring}
 sub=Program({op.kernel:cp.kernels[op.kernel] for op in ops},{n:cp.buffers[n] for n in names},ops,
             step_state=cp.step_state,ring=cp.ring,ring_capacity=cp.ring_capacity,layout=cp.layout,context_capacity=cp.context_capacity)
 local_engines.append(Engine(sub,sess.dev,buffers=shared))
native_engines=[];start=0;np_=programs['original']
for output in outputs:
 end=next(j+1 for j,op in enumerate(np_.ops) if j>=start and any(n==output and slot in op.meta.get('writes',[]) for slot,n,off in op.bindings))
 ops=np_.ops[start:end];start=end
 names={n for op in ops for _,n,_ in op.bindings}|{np_.step_state,np_.ring}
 sub=Program({op.kernel:np_.kernels[op.kernel] for op in ops},{n:np_.buffers[n] for n in names},ops,
             step_state=np_.step_state,ring=np_.ring,ring_capacity=np_.ring_capacity,layout=np_.layout,context_capacity=np_.context_capacity)
 native_engines.append(Engine(sub,sess.dev,buffers=engines['original'].buffers))
from monolith.kernels import x_permute_columns
layouts={}
for key,program in [('original',programs['original']),('candidate',programs['candidate'])]:
 layouts[key]={}
 for op in program.ops:
  macros=program.kernels[op.kernel].macros
  if macros.get('NORM_OUT')=='1':
   dims=tuple(int(macros[k].rstrip('u')) for k in ['NORM_K','NORM_WPW','NORM_TK'])
   for slot,name,off in op.bindings:
    if slot==14:
     assert off==0
     layouts[key][name]=dims
layout_transforms={name:(dims,layouts['candidate'][name]) for name,dims in layouts['original'].items()
                   if name in layouts['candidate'] and dims!=layouts['candidate'][name]}
print('Layout conversions:',len(layout_transforms),list(layout_transforms.items())[:2],flush=True)
checks=[];local_checks=[]
for step in range(4):
 x=real_inputs[step] if real_inputs else f32_to_bf16(np.random.default_rng(2000+step).normal(0,.1,(8,5120)).astype(np.float32)).tobytes()
 for e in engines.values():
  e.buffers['hidden'].write(x,0)
  e.buffers[e.program.step_state].write(e.program.layout.pack({'step':step,'position':(0 if real_inputs else 128)+8*step,'t_this_step':8}),0)
  if e is not engines['original']:e.run(1,steps_per_cb=1,in_flight=2)
 for index,(local,output) in enumerate(zip(local_engines,outputs)):
  native=engines['original']
  for name,spec in local.program.buffers.items():
   if name in programs['original'].buffers and spec.role not in ('weights','params'):
    original_spec=programs['original'].buffers[name]
    assert spec.nbytes==original_spec.nbytes,(index,name,spec.nbytes,original_spec.nbytes)
    data=native.read(name)
    if name in layout_transforms:
     source,target=layout_transforms[name]
     assert source[0]==target[0]
     columns=np.argsort(x_permute_columns(*source))[x_permute_columns(*target)]
     data=np.frombuffer(data,np.uint16).reshape(-1,source[0])[:,columns].copy().tobytes()
    local.buffers[name].write(data,0)
  native_engines[index].run(1,steps_per_cb=1,in_flight=2)
  local.run(1,steps_per_cb=1,in_flight=2)
  got=bf16_to_f32(np.frombuffer(local.read(output,8*5120*2),np.uint16))
  expected=bf16_to_f32(np.frombuffer(native.read(output,8*5120*2),np.uint16))
  local_checks.append(dict(step=step,layer=index,**metrics(got,expected)))
 for name in outputs:
  values={key:bf16_to_f32(np.frombuffer(e.read(name,8*5120*2),np.uint16)) for key,e in engines.items()}
  for key in ['previous','candidate']:checks.append(dict(step=step,buffer=name,engine=key,**metrics(values[key],values['original'])))
 for name,spec in programs['original'].buffers.items():
  if spec.role!='state':continue
  dtype=np.float32 if name.endswith('rec_state') else np.uint16
  values={key:np.frombuffer(e.read(name),dtype) for key,e in engines.items()}
  if dtype==np.uint16:values={key:bf16_to_f32(v) for key,v in values.items()}
  for key in ['previous','candidate']:checks.append(dict(step=step,buffer=name,engine=key,**metrics(values[key],values['original'])))
result=dict(layers=a.layers,real_inputs=bool(real_inputs),checks=checks,local_checks=local_checks,layout_transforms=layout_transforms,
            local_gate=all(c['finite'] and c['cosine']>=.9999 and c['relative_l2']<.005 for c in local_checks),
            accumulated_gate=all(c['finite'] and c['cosine']>.999 for c in checks))
a.out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','local_checks']}))
print('worst_local',sorted(local_checks,key=lambda c:c['cosine'])[:5])
print('worst_accumulated',sorted(checks,key=lambda c:c['cosine'])[:5])
