"""Check whether isolated-layer selection also survives hoisted chain boundaries."""
import json,math,statistics,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
configs=json.loads((p/'finalists-configs.json').read_text());rank=[]
for i,cfg in enumerate(configs):
 out=p/f'chain5-finalist-{i}.json'
 if i==2:
  row=json.loads((p/'chain5.json').read_text())
 else:
  assert not out.exists(),out
  config=p/f'chain-finalist-{i}.json';config.write_text(json.dumps(cfg,indent=2)+'\n')
  with (p/f'chain5-finalist-{i}.log').open('w') as log:
   subprocess.run([sys.executable,str(p/'chain_compare.py'),'--config',str(config),'--reference',str(p/'baseline.json'),'--layers','5','--reps','9','--steps','16','--out',str(out)],check=True,stdout=log,stderr=subprocess.STDOUT)
  row=json.loads(out.read_text())
 ratios=[row['samples']['candidate'][j]['wall_us']/row['samples']['previous'][j]['wall_us'] for j in range(row['reps'])]
 rank.append(dict(index=i,config=cfg,wall_over_previous=row['results']['candidate']['wall_us']/row['results']['previous']['wall_us'],wall_over_original=row['results']['candidate']['wall_us']/row['results']['original']['wall_us'],paired_geomean=math.exp(statistics.mean(map(math.log,ratios))),paired_wins=sum(x<1 for x in ratios),pairs=len(ratios),min_cosine=row['min_cosine'],replay_bit_exact=row['replay_bit_exact']))
 print(i,rank[-1]['wall_over_previous'],flush=True)
rank.sort(key=lambda r:r['wall_over_previous'])
(p/'chain-finalists-ranking.json').write_text(json.dumps(rank,indent=2)+'\n')
