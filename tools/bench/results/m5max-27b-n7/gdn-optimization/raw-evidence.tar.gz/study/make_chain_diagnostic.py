from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'chain_compare.py').read_text()
s=s.replace('checks=[]\nfor step in range(4):', '''# Reuse exact emitted chain segments, but feed each the original chain's input
# and read-state. Private activations/states prevent the local audit from changing
# either complete chain. This isolates local errors from accumulated differences.
from monolith.runtime.program import Program
local_engines=[];start=0;cp=programs['candidate']
for index,output in enumerate(outputs):
 end=next(j+1 for j,op in enumerate(cp.ops) if j>=start and any(n==output and slot in op.meta.get('writes',[]) for slot,n,off in op.bindings))
 ops=cp.ops[start:end];start=end
 names={n for op in ops for _,n,_ in op.bindings}|{cp.step_state,cp.ring}
 sub=Program({op.kernel:cp.kernels[op.kernel] for op in ops},{n:cp.buffers[n] for n in names},ops,
             step_state=cp.step_state,ring=cp.ring,ring_capacity=cp.ring_capacity,layout=cp.layout,context_capacity=cp.context_capacity)
 local_engines.append(Engine(sub,sess.dev,buffers=shared))
checks=[];local_checks=[]
for step in range(4):''')
s=s.replace(" for name in outputs:\n", """ for index,(local,output) in enumerate(zip(local_engines,outputs)):
  native=engines['original']
  for name,spec in local.program.buffers.items():
   if name in programs['original'].buffers and spec.role not in ('weights','params'):
    original_spec=programs['original'].buffers[name]
    assert spec.nbytes==original_spec.nbytes,(index,name,spec.nbytes,original_spec.nbytes)
    local.buffers[name].write(native.read(name),0)
  local.run(1,steps_per_cb=1,in_flight=2)
  got=bf16_to_f32(np.frombuffer(local.read(output,8*5120*2),np.uint16))
  expected=bf16_to_f32(np.frombuffer(native.read(output,8*5120*2),np.uint16))
  local_checks.append(dict(step=step,layer=index,**metrics(got,expected)))
 for name in outputs:
""")
pos=s.index("correct=all(c['finite']")
s=s[:pos]+'''result=dict(layers=a.layers,real_inputs=bool(real_inputs),checks=checks,local_checks=local_checks,
            local_gate=all(c['finite'] and c['cosine']>=.9999 and c['relative_l2']<.005 for c in local_checks),
            accumulated_gate=all(c['finite'] and c['cosine']>.999 for c in checks))
a.out.write_text(json.dumps(result,indent=2)+'\\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','local_checks']}))
print('worst_local',sorted(local_checks,key=lambda c:c['cosine'])[:5])
print('worst_accumulated',sorted(checks,key=lambda c:c['cosine'])[:5])
'''
(p/'chain_diagnostic.py').write_text(s)
