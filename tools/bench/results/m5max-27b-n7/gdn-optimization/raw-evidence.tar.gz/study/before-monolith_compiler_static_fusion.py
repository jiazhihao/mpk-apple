"""Static decoder-half task compiler, shared by profile selection and tuning tools.

Inline the production task bodies into one fixed-worker kernel. The normalized
multi-dispatch program is a required control: cooperative activation loading and
common threadgroup geometry change performance independently of fusion.
"""
import re, subprocess, copy, struct
from monolith.kernels import KERNELS_DIR
from monolith.runtime.program import KernelSpec, OpSpec, BufferSpec

def normalize(p,sgs,mode="coop",groups=None, *, tn=16, split=False,
              ksplit=None, compact=False, narrow_scales=False, unroll=False,
              gdn_sl=None, k_unroll=1, decode=3, gemm_overrides=None, scalar_sgs=None,
              short_decode=False, attention_groups=None, attention_qm=16,
              merge_sgs=None, merge_unroll=4):
    if mode not in ('coop','staged'):
        raise ValueError('unsupported activation loading mode')
    if short_decode and mode!='coop':
        raise ValueError('short decode requires the eight-value cooperative tile')
    if groups is not None and (not isinstance(groups,int) or not 1<=groups<=4096):
        raise ValueError('projection task groups must be between 1 and 4096')
    if sgs not in (4,8,16,32) or (mode=='staged' and sgs>8):
        raise ValueError('unsupported SIMD-group geometry')
    if ksplit is not None and (ksplit < 1 or sgs % ksplit):
        raise ValueError('K split must divide the SIMD-group count')
    if k_unroll not in (1,2,4,8) or decode not in (0,1,2,3):
        raise ValueError('unsupported inner-loop specialization')
    if scalar_sgs is not None and (scalar_sgs not in (1,2,4,8,16,32) or scalar_sgs>sgs):
        raise ValueError('scalar SIMD-group count must fit the threadgroup')
    if attention_groups is not None and (type(attention_groups) is not int or not 1<=attention_groups<=4096):
        raise ValueError('attention task groups must be between 1 and 4096')
    if attention_qm not in (8,16):
        raise ValueError('attention query tile must be 8 or 16')
    if merge_sgs is not None and (merge_sgs not in (1,2,4,8,16,32) or merge_sgs>sgs):
        raise ValueError('merge SIMD-group count must fit the threadgroup')
    if merge_unroll not in (1,2,4,8,16,32):
        raise ValueError('unsupported attention merge unroll')
    if gemm_overrides:
        common=dict(tn=tn,split=split,ksplit=ksplit,compact=compact,narrow_scales=narrow_scales,
                    unroll=unroll,gdn_sl=gdn_sl,k_unroll=k_unroll,decode=decode,scalar_sgs=scalar_sgs,
                    short_decode=short_decode,attention_groups=attention_groups,attention_qm=attention_qm,
                    merge_sgs=merge_sgs,merge_unroll=merge_unroll)
        out=normalize(p,sgs,mode,groups,**common)
        ordinal=0
        for i,o in enumerate(p.ops):
            if p.kernels[o.kernel].function!='gemm_tile': continue
            override=gemm_overrides.get(str(ordinal),{})
            if override:
                single=copy.deepcopy(p);single.ops=[single.ops[i]]
                cfg=dict(common,**override)
                stage_groups=cfg.pop('groups',groups)
                specialized=normalize(single,sgs,mode,stage_groups,**cfg)
                op=specialized.ops[0];key=f'{op.kernel}.stage{ordinal}'
                out.kernels[key]=specialized.kernels[op.kernel];op.kernel=key
                out.ops[i]=op
                for _,name,_ in op.bindings:
                    if out.buffers[name].role=='params':out.buffers[name]=specialized.buffers[name]
            ordinal+=1
        out.kernels={o.kernel:out.kernels[o.kernel] for o in out.ops}
        return out
    p=copy.deepcopy(p)
    changed=set()
    original_tn={n:int(k.macros["TN"].rstrip("u")) for n,k in p.kernels.items() if k.function=="gemm_tile"}
    changed_params=set()
    for o in p.ops:
        k=p.kernels[o.kernel]
        if k.function not in ('gemm_tile','x_permute','rmsnorm_stat','gdn_mixer','gdn_norm',
                              'gqa_decode_mma','gqa_merge'):
            raise ValueError(f'unsupported experimental task: {k.function}')
        if k.function=='gemm_tile':
            if o.kernel not in changed:
                k.macros['NVFP4_DECODE']=str(decode)
                if mode=='staged':
                    k.source=k.source.replace('tensor<device bfloat,', 'tensor<threadgroup bfloat,')
                    k.source=k.source.replace('tA_t tA(xp, dextents<int, 2>(int(K), int(TM)));',f'threadgroup bfloat activations[{sgs}][TK * TM];')
                    k.source=k.source.replace('auto sA = tA.slice<int(TK), int(TM)>(int(kp * TK), 0);', f"""for (uint ai=lane; ai<TK*TM; ai+=32u)
        activations[sg % {sgs}u][ai]=xp[(ulong)(ai/TK)*K+kp*TK+ai%TK];
      simdgroup_barrier(mem_flags::mem_threadgroup);
      tA_t tA(activations[sg % {sgs}u], dextents<int,2>(int(TK),int(TM)));
      auto sA=tA.slice<int(TK),int(TM)>(0,0);""")
                else:
                    if tn not in (16, 32):
                        raise ValueError('cooperative output tile must have 16 or 32 rows')
                    k.macros.update(TM='16',TN=f'{tn}u',TK='32u',SCALE_CACHE='0')
                    # At TK=32 a quad member owns eight values, including only
                    # one uint of an NVFP4 payload word. Its scale is still
                    # selected from the original sixteen-value scale group.
                    k.source=k.source.replace('#define NCH (CT / 16u)', '#define NCH ((CT + 15u) / 16u)')
                    k.source=k.source.replace('words[0] = (e0 != 0u) ? uint4(words[0].z, words[0].w, 0u, 0u) : words[0];',
                        'words[0] = (WPW == 32u && CT == 8u) ? uint4(words[0][e0 / 8u], 0u, 0u, 0u) : ((e0 != 0u) ? uint4(words[0].z, words[0].w, 0u, 0u) : words[0]);')
                    k.source=k.source.replace('tA_t tA(xp, dextents<int, 2>(int(K), int(TM)));','auto aT=op.get_left_input_cooperative_tensor<bfloat,bfloat,float>();')
                    k.source=k.source.replace('get_destination_cooperative_tensor<tA_t, decltype(bT), float>()','get_destination_cooperative_tensor<decltype(aT), decltype(bT), float>()')
                    k.source=k.source.replace('auto sA = tA.slice<int(TK), int(TM)>(int(kp * TK), 0);', """for(uint16_t ai=0;ai<aT.get_capacity();ai++) {
      auto c=aT.get_multidimensional_index(ai);
      aT[ai]=(c[1]<T_act && c[0]<TK) ? xp[(ulong)c[1]*K+kp*TK+c[0]] : bfloat(0);
     }""").replace('op.run(sA,bT,cT)','op.run(aT,bT,cT)').replace('op.run(sA, bT, cT)','op.run(aT, bT, cT)')
                k.source=k.source.split('kernel void coop_layout')[0]
                if short_decode:
                    if not any(marker in k.source for marker in ('#ifndef NVFP4_DECODE',
                            'static inline float fp8_e4m3(', '#define BF16_STORAGE 1')):
                        raise ValueError('short decode is validated only for NVFP4, FP8 and BF16')
                    # The quarter/half-word selection above puts the eight
                    # consumed values first. Do not materialize unused values.
                    k.source=k.source.replace('for (uint e = 0; e < 32; e++)', 'for (uint e = 0; e < 8; e++)')
                    k.source=k.source.replace('for (uint e = 0; e < 16; e++)', 'for (uint e = 0; e < 8; e++)')
                    k.source=k.source.replace('for (uint i = 0; i < 4; i++) for (uint b = 0; b < 4; b++)',
                        'for (uint i = 0; i < 1; i++) for (uint b = 0; b < 4; b++)')
                    k.source=k.source.replace('float wv[NW * WPW];','float wv[8];')
                if narrow_scales:
                    # TK=32 consumes one NVFP4 scale per lane. Loading the entire
                    # K-dependent scale run creates unnecessary live registers.
                    start=k.source.index('#if SCALE_PAYLOAD_ORDER\n')
                    end=k.source.index('#endif // SCALE_PAYLOAD_ORDER',start)+len('#endif // SCALE_PAYLOAD_ORDER')
                    original=k.source[start:end]
                    k.source=k.source[:start]+'''#if WEIGHTS_PER_WORD == 32 && SCALE_UNIT_BYTES == 1 && SCALE_GROUP == 16 && CT == 8 && !SCALE_PAYLOAD_ORDER
          const uint ln = ln0 + i;
          const uint g = (LANE_OFF + j * WPW + e0) / SCALE_GROUP;
          uint one_scale = reinterpret_cast<device const uchar*>(wb + SCALE_WORD(ln, r, 0))[SCALE_SOFF(ln) + g];
          scv[0] = decode_scale(&one_scale, 0u);
#else
'''+original+'\n#endif'+k.source[end:]
                if unroll:
                    k.source=k.source.replace('for(uint16_t ai=0;ai<aT.get_capacity();ai++)',
                        '\n#pragma clang loop unroll(full)\n     for(uint16_t ai=0;ai<aT.get_capacity();ai++)')
                if k_unroll>1:
                    k.source=k.source.replace('    for (uint kt =',
                        f'    #pragma clang loop unroll_count({k_unroll})\n    for (uint kt =')
                if compact:
                    # This experimental compiler only emits the fixed T<=8 path.
                    # The cooperative accumulator still has sixteen token rows.
                    k.macros.update(T_HI='8u', T_LO='0u', COMPACT_PARTIALS='1')
                    # Cooperative MMA pads to sixteen rows, but only the first
                    # eight are live. POST_NORM's one scalar per lane covers
                    # exactly those rows at a native-producer boundary.
                    k.source=k.source.replace('#if TM > 8\n#error POST_NORM requires a short tile',
                        '#if TM > 16 || T_HI > 8\n#error POST_NORM requires at most eight active rows')
                if ksplit is not None and ksplit > 1 and ksplit < sgs:
                    teams=sgs//ksplit
                    k.source=k.source.replace('threadgroup float part[KSPLIT - 1]',
                        f'const uint team = (sg % {sgs}u) / KSPLIT;\n  threadgroup float part[{teams}][KSPLIT - 1]')
                    k.source=k.source.replace('part[slice - 1u]', 'part[team][slice - 1u]').replace('part[s2 - 1u]', 'part[team][s2 - 1u]')
                    # The divisibility gate below keeps every team's barrier
                    # count equal without introducing dummy output tiles.
                changed.add(o.kernel)
            if mode=='coop':
                pname=next(n for slot,n,off in o.bindings if slot==4)
                if pname not in changed_params:
                    old_tn=original_tn[o.kernel]
                    param=bytearray(p.buffers[pname].init)
                    nr,nt,ns,ta,scale,tile0,nb,pad=struct.unpack('<IIIIfIII',param)
                    if tile0*old_tn % tn:
                        raise ValueError('output tile does not align with the slab segment')
                    nt,tile0=(nr+tn-1)//tn,tile0*old_tn//tn
                    p.buffers[pname].init=struct.pack('<IIIIfIII',nr,nt,ns,ta,scale,tile0,nb,pad)
                    for field,value in (('N_TILES',nt),('TILE0',tile0)):
                        key='STATIC_GEMM_P_'+field
                        if key in k.macros: k.macros[key]=f'{value}u'
                    changed_params.add(pname)
            if ksplit is not None and 1<ksplit<sgs:
                pname=next(n for slot,n,off in o.bindings if slot==4)
                nt=struct.unpack_from('<I',p.buffers[pname].init,4)[0]
                if nt%(sgs//ksplit):
                    # Padded multi-team output tiles failed the recurrent
                    # state replay gate despite guarded scalar stores.
                    raise ValueError('ragged multi-team output tiles are unsupported')
            desired_split=ksplit if ksplit is not None else (sgs if split or int(k.macros.get('KSPLIT','1').rstrip('u'))>1 else 1)
            k.macros['KSPLIT']=f'{desired_split}u'
            if desired_split>1:
                if k.macros.get('SCALE_CACHE')=='1': k.macros['SCALE_CACHE']='0'
                k.macros['STATIC_GEMM_P_N_SG']=f'{o.grid[0]*sgs}u'
            else:
                o.grid=(o.grid[0]*o.threadgroup[0]//(32*sgs),1,1)
        elif k.function=='gdn_mixer':
            if gdn_sl is not None:
                old_sl=int(k.macros['SL'].rstrip('u'))
                dv=int(k.macros['DV'].rstrip('u'))
                if k.macros.get('SINGLE_PASS')!='1' or gdn_sl not in (1,2,4,8) or (dv//gdn_sl)%sgs:
                    raise ValueError('unsupported GDN state slice')
                tasks=o.grid[0]*o.threadgroup[0]//32*old_sl//gdn_sl
                k.macros['SL']=f'{gdn_sl}u'
                o.grid=(tasks//sgs,1,1)
                o.threadgroup=(32*sgs,1,1)
            k.macros['LOCAL_GROUPS']=f'{sgs}u'
            o.grid=(o.grid[0]*o.threadgroup[0]//(32*sgs),1,1)
        elif k.function=='gqa_decode_mma':
            if mode != 'coop' or sgs not in (4,8) or k.macros.get('DIRECT_KV') == '1':
                raise ValueError('experimental attention requires staged MMA with 4 or 8 SIMD groups')
            k.macros['MMA_SG']=str(sgs)
            k.source=k.source.replace('#define QM 16',f'#define QM {attention_qm}')
            if attention_groups is not None:
                o.grid=(attention_groups,1,1)
                k.macros['STATIC_GQA_P_N_SG']=f'{attention_groups}u'
                pname=next(n for slot,n,_ in o.bindings if slot==9)
                param=bytearray(p.buffers[pname].init)
                struct.pack_into('<I',param,16,attention_groups)
                p.buffers[pname].init=bytes(param)
        else:
            if mode=='coop':
                if k.function=='x_permute':
                    k.macros['TK']='32u'
                    # This source also contains the unused GEMM entry; it must
                    # remain syntactically valid at the smaller TK.
                    k.source=k.source.replace('#define NCH (CT / 16u)', '#define NCH ((CT + 15u) / 16u)')
                elif k.function=='gdn_norm': k.macros['PERM_TK']='32u'
            assert o.threadgroup[0]==32,k.function
            active=scalar_sgs if scalar_sgs is not None and k.function in ('x_permute','rmsnorm_stat','gdn_norm','gqa_merge') else sgs
            if k.function=='gqa_merge':
                active=merge_sgs if merge_sgs is not None else active
                k.macros['MERGE_UNROLL']=f'{merge_unroll}u'
                k.source=k.source.replace('#define MERGE_UNROLL 4u',f'#define MERGE_UNROLL {merge_unroll}u')
            if active!=sgs and o.kernel not in changed:
                if k.function=='x_permute' and int(k.macros.get('PERM_GROUPS','1').rstrip('u'))!=1:
                    raise ValueError('scalar subgroups cannot skip threadgroup barriers')
                entry=r'(kernel void '+re.escape(k.function)+r'\(.*?\)\s*\{)'
                prefix=f'\nif ((gid / 32u) % {sgs}u >= {active}u) return;\ngid = (gid / {32*sgs}u) * {32*active}u + gid % {32*sgs}u;\n'
                k.source,count=re.subn(entry,lambda m:m[1]+prefix,k.source,count=1,flags=re.S)
                if count!=1:raise ValueError('scalar entry not found')
                changed.add(o.kernel)
            o.grid=((o.grid[0]+active-1)//active,1,1)
        if groups is not None and k.function=='gemm_tile':
            o.grid=(groups,1,1)
            k.macros['STATIC_GEMM_P_N_SG']=f'{groups*sgs}u'
            pname=next(n for slot,n,off in o.bindings if slot==4)
            param=bytearray(p.buffers[pname].init);struct.pack_into('<I',param,8,groups*sgs);p.buffers[pname].init=bytes(param)
        if mode=='coop':
            # Fused producers must write the same TK=32 activation layout as
            # their cooperative consumers, including the MLP down projection.
            for key in ('PERM_TK','NORM_TK'):
                if key in k.macros: k.macros[key]='32u'
        o.threadgroup=(32*sgs,1,1)
    return p

def stage(k,i,immutable=()):
    src=re.sub(r'^\s*#include[^\n]*','',k.source,flags=re.M)
    defs='\n'.join(f'#define {a} {b}' for a,b in k.macros.items())
    src=subprocess.run(['xcrun','clang','-E','-P','-x','c++','-'],input=defs+'\n'+src,text=True,capture_output=True,check=True).stdout
    # Only the desired kernel becomes a callable task. Remove all other entries.
    signature=None;body=None
    for m in reversed(list(re.finditer(r'kernel void (\w+)\((.*?)\)\s*\{',src,re.S))):
        end=m.end(); depth=1
        while depth:
            if src[end]=='{':depth+=1
            elif src[end]=='}':depth-=1
            end+=1
        if m[1]==k.function:signature=m[2];body=src[m.end():end-1]
        src=src[:m.start()]+src[end:]
    assert signature is not None,k.function
    scratch=[]
    def shared(m):
        scratch.append(f'{m[1]} {m[2]}{m[3]};');return ''
    body=re.sub(r'threadgroup\s+(\w+)\s+(\w+)\s*((?:\[[^\]]+\])*)\s*;',shared,body)
    for decl in scratch:
        name=re.match(r'\w+ (\w+)',decl)[1]
        body=re.sub(r'\b'+name+r'\b','sm.'+name,body)
    pars=[];clean=[]
    for param in signature.split(','):
        param=param.strip();m=re.search(r'\[\[(.*?)\]\]',param);attr=m[1] if m else None
        plain=re.sub(r'\s*\[\[.*?\]\]','',param)
        mm=re.match(r'(.*?)\b(\w+)\s*$',plain);typ,name=mm.groups()
        pars.append((typ.strip(),name,attr));clean.append(plain)
    src+='\nstruct Scratch { '+ ' '.join(scratch or ['uint unused;'])+' };\n'
    src+='static inline void task('+','.join(clean)+', threadgroup Scratch& sm) {\n'+body+'\n}\n'
    # The tensor view type is part of MPP and cannot carry coherent qualification;
    # other device pointers (including its backing activation pointer) can.
    src=re.sub(r'\bdevice\b','coherent(device) device',src)
    for name in immutable:
        src=re.sub(r'coherent\(device\) (device[^,;(){}=\n]*\b'+re.escape(name)+r'\b)',r'\1',src)
    if k.function=='gemm_tile':
        # uint4 pointers in this kernel address immutable packed weights only.
        src=src.replace('coherent(device) device const uint4*','device const uint4*')
        # Narrow scale loads are also views of the immutable weight block, not
        # cross-worker activations. Preserve their ordinary weight-cache path.
        src=re.sub(r'reinterpret_cast<coherent\(device\) device const (uchar|ushort|uint)\*>\(wb',
                   r'reinterpret_cast<device const \1*>(wb',src)

    return f'namespace s{i} {{\n'+src+'\n}\n',pars

def _tile_tasks(p,sgs,workers,attention_task_tiles):
    """Expose projection tile teams and bounded attention tile groups as tasks.

    This changes ownership, not the reduction order within a tile. Parameter
    records and kernel specs are private per op, including shared slab kernels.
    """
    p=copy.deepcopy(p)
    for i,o in enumerate(p.ops):
        k=copy.deepcopy(p.kernels[o.kernel])
        key=f'{o.kernel}.task{i}';p.kernels[key]=k;o.kernel=key
        if k.function=='gemm_tile':
            split=int(k.macros['KSPLIT'].rstrip('u'))
            if sgs%split:raise ValueError('task tile split must divide worker SIMD groups')
            name=next(n for slot,n,_ in o.bindings if slot==4)
            param=bytearray(p.buffers[name].init)
            tiles=struct.unpack_from('<I',param,4)[0]
            teams=sgs//split
            if tiles%teams:raise ValueError('task tiles require complete SIMD teams')
            groups=tiles//teams
            struct.pack_into('<I',param,8,groups*sgs)
            new=f'{name}.task{i}'
            p.buffers[new]=BufferSpec(len(param),bytes(param),'params')
            o.bindings=[(slot,new if slot==4 else n,off) for slot,n,off in o.bindings]
            k.macros['STATIC_GEMM_P_N_SG']=f'{groups*sgs}u'
            o.grid=(groups,1,1)
        elif k.function=='gqa_decode_mma':
            if k.macros.get('STEP_STATE')!='1' or k.macros.get('LM_MODE','0')!='0' or k.macros.get('DIRECT_KV','0')!='0' or k.macros.get('ADAPTIVE_CHUNK','0')!='0':
                raise ValueError('attention task tiles require ordinary staged StepState attention')
            # gqa_source also carries the unused ADAPTIVE_CHUNK entry first.
            start=k.source.rindex('kernel void gqa_decode_mma(')
            tail,count=re.subn(r'for \(uint block = tgid; block < (.*?); block \+= (?:p\.n_sg|STATIC_GQA_P_N_SG)\)',
                              r'const uint task_tiles=tiles_per_task(\1);\n  for (uint block = tgid*task_tiles; block < min(\1, (tgid+1u)*task_tiles); block++)',
                              k.source[start:],count=1)
            if count!=1:raise ValueError('attention task loop not found')
            helper=f'''static inline uint tiles_per_task(uint blocks) {{
  return min({attention_task_tiles}u, max(1u, blocks / {workers*2}u));
}}
'''
            k.source=k.source[:start]+helper+tail
            k.source+='''
static inline uint task_count(constant GqaParams& p, device const StepState* st) {
  if (st->done || st->t_this_step == 0u) return 0u;
  const uint rows = st->t_this_step * (p.heads / p.kv_heads);
  const uint chunks = (st->position + st->t_this_step + KN - 1u) / KN;
  const uint blocks = p.kv_heads * chunks * ((rows + QM - 1u) / QM);
  const uint tiles = tiles_per_task(blocks);
  return (blocks + tiles - 1u) / tiles;
}
'''
            o.meta['dynamic_task_count']=True
    p.kernels={o.kernel:p.kernels[o.kernel] for o in p.ops}
    return p


def merge(p,workers,sgs, *, barrier="serial", task_barrier=True, noinline=False, schedule="stages",
          task_grain="group", task_batch=1, task_stats=False, attention_task_tiles=1, task_seed=False):
    if not isinstance(workers,int) or not 1<=workers<=256:
        raise ValueError('worker count must be between 1 and 256')
    if barrier not in ('serial','simd','leader'):
        raise ValueError('unsupported global barrier')
    if schedule not in ('stages','interleave','queue'):
        raise ValueError('unsupported sibling task schedule')
    if task_grain not in ('group','tile'):
        raise ValueError('unsupported task granularity')
    if type(task_batch) is not int or task_batch not in (1,2,4,8,16,32):
        raise ValueError('unsupported task claim batch')
    if task_stats and schedule!='queue':
        raise ValueError('task distribution counters require the queue schedule')
    if task_seed and schedule!='queue':
        raise ValueError('initial task assignment requires the queue schedule')
    if type(attention_task_tiles) is not int or attention_task_tiles not in (1,2,3,4,6,8,12,16,24,32):
        raise ValueError('unsupported attention task tile count')
    if task_grain=='tile':p=_tile_tasks(p,sgs,workers,attention_task_tiles)
    src='#include <metal_stdlib>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal;\n'
    # Parameter records can share one constant binding. This also leaves room
    # for a fused producer's normalization outputs at a decoder-half boundary.
    p=copy.deepcopy(p)
    records=list(dict.fromkeys(n for o in p.ops for _,n,_ in o.bindings if p.buffers[n].role=='params'))
    packed=bytearray();offsets={}
    for n in records:
        spec=p.buffers[n]
        if spec.init is None: raise ValueError('static parameters must have initial data')
        packed.extend(bytes((-len(packed))%16));offsets[n]=len(packed)
        packed.extend(spec.init);packed.extend(bytes(spec.nbytes-len(spec.init)))
    if records:
        name='mega.params'
        if name in p.buffers: raise ValueError('parameter binding name already exists')
        p.buffers[name]=BufferSpec(len(packed),bytes(packed),'params')
        for o in p.ops:
            o.bindings=[(slot,name,off+offsets[n]) if n in offsets else (slot,n,off) for slot,n,off in o.bindings]
    names=list(dict.fromkeys(n for o in p.ops for _,n,_ in o.bindings));bi={n:i for i,n in enumerate(names)}
    if len(names)>=30: raise ValueError('too many Metal buffer bindings')
    arguments=[]
    for n,i in bi.items():
        typ='constant' if p.buffers[n].role=='params' else ('device' if p.buffers[n].role=='weights' else 'coherent(device) device')
        arguments.append(f'{typ} uchar* b{i} [[buffer({i})]]')
    arguments+= [f'coherent(device) device atomic_uint* flags [[buffer({len(names)})]]','uint tid [[thread_index_in_threadgroup]]','uint worker [[threadgroup_position_in_grid]]']
    if schedule=='queue':
        arguments.append(f'coherent(device) device atomic_uint* task_queue [[buffer({len(names)+1})]]')
    calls=[];sizes=[];task_calls=[];counts=[]
    for i,o in enumerate(p.ops):
        k=p.kernels[o.kernel]
        _,probe=stage(k,i)
        immutable=[name for typ,name,attr in probe if attr.startswith('buffer(') and
                                                    p.buffers[next(n for slot,n,off in o.bindings if slot==int(attr[7:-1]))].role=='weights']
        text,pars=stage(k,i,immutable)
        if noinline: text=text.replace('static inline void task(', 'static __attribute__((noinline)) void task(')
        src+=text;sizes.append(f'sizeof(s{i}::Scratch)')
        byslot={slot:(bi[n],off) for slot,n,off in o.bindings}
        args=[]
        for typ,name,attr in pars:
            if attr.startswith('buffer('):
                slot=int(attr[7:-1]);b,off=byslot[slot]
                ptr=f'(b{b}+{off}ul)'
                if name not in immutable: typ=re.sub(r'\bdevice\b','coherent(device) device',typ)
                args.append(f'*({typ.replace("&","*")}){ptr}' if '&' in typ else f'({typ}){ptr}')
            else:
                value={'thread_position_in_grid':f'task_id*{32*sgs}u+tid','thread_index_in_simdgroup':'tid%32u','threads_per_simdgroup':'32u','threadgroup_position_in_grid':'task_id','thread_index_in_threadgroup':'tid','simdgroup_index_in_threadgroup':'tid/32u'}.get(attr)
                assert value,(typ,name,attr)
                args.append(f'uint3({value},0,0)' if typ=='uint3' else value)
        args.append(f'*(threadgroup s{i}::Scratch*)scratch')
        task_calls.append(f's{i}::task('+','.join(args)+');')
        count=f'{o.grid[0]}u'
        if o.meta.get('dynamic_task_count'):
            byname={name:arg for (_,name,_),arg in zip(pars,args)}
            count=f's{i}::task_count({byname["p"]},{byname["st"]})'
            count=re.sub(r'\b(GqaParams|StepState)\b',lambda m:f's{i}::{m[1]}',count)
        counts.append(count)
        sync='if (!stage_barrier(flags, worker, tid, ok)) return;' if i and o.barrier_before else 'threadgroup_barrier(mem_flags::mem_threadgroup);'
        after='threadgroup_barrier(mem_flags::mem_threadgroup);'
        if not task_barrier: after=f'if (task_id + {workers}u < ({count})) '+after
        calls.append(f'{{ using namespace s{i};\n{sync}\nfor (uint task_id=worker;task_id<({count});task_id+={workers}u) {{ task('+','.join(args)+'); '+after+' }\n}\n')
    if schedule in ('interleave','queue'):
        groups=[]
        for i,o in enumerate(p.ops):
            if not groups or o.barrier_before:groups.append([])
            groups[-1].append(i)
        interleaved=[]
        for group in groups:
            if schedule=='queue' and (group[0] or p.kernels[p.ops[group[0]].kernel].function in ('gemm_tile','gqa_decode_mma')):
                # Each readiness stage has its own counter. Worker zero clears
                # them at entry; the first existing device barrier publishes
                # the resets before any claims. Never reset an active queue.
                body='if (!stage_barrier(flags, worker, tid, ok)) return;\n'
                for i in group:body+=f'const uint count{i}={counts[i]}; uint done{i}=0u;\n'
                body+='const uint total='+ '+'.join(f'count{i}' for i in group)+';\n'
                body+=f'for(uint claim=0;claim<(total+{task_batch-1}u)/{task_batch}u;claim++) {{\n'
                fetch=f'atomic_fetch_add_explicit(task_queue+{group[0]}u,{task_batch}u,memory_order_relaxed)'
                if task_seed:fetch=f'claim==0u?worker*{task_batch}u:{fetch}'
                body+=f'if(tid==0u) queue_job={fetch};\n'
                body+='threadgroup_barrier(mem_flags::mem_threadgroup);\nconst uint first=queue_job;\nif(first>=total) break;\n'
                body+=f'for(uint job=first;job<min(first+{task_batch}u,total);job++) {{\n'
                # Interleave ready siblings without holes when task counts
                # differ. Current compiler readiness groups have at most two.
                if len(group)>2:raise ValueError('queue supports at most two ready sibling operations')
                if len(group)==2:
                    a,b=group
                    body+=f'const uint paired=min(count{a},count{b});\nconst uint kind=job<paired*2u?job%2u:uint(count{b}>count{a});\nconst uint task_id=job<paired*2u?job/2u:job-paired;\n'
                else:body+='const uint kind=0u, task_id=job;\n'
                body+='switch(kind) {\n'
                for case,i in enumerate(group):
                    body+=f'case {case}u: {{ using namespace s{i}; {task_calls[i]} done{i}++; break; }}\n'
                body+='}\nthreadgroup_barrier(mem_flags::mem_threadgroup);\n}\n}\n'
                if task_stats:
                    for i in group:
                        body+=f'if(tid==0u) atomic_store_explicit(task_queue+{len(p.ops)+i*workers}u+worker,done{i},memory_order_relaxed);\n'
                interleaved.append('{\n'+body+'}\n');continue
            if len(group)==1:
                interleaved.append(calls[group[0]]);continue
            sync=('if (!stage_barrier(flags, worker, tid, ok)) return;' if group[0]
                  else 'threadgroup_barrier(mem_flags::mem_threadgroup);')
            limit=counts[group[0]]
            for i in group[1:]:limit=f'max({limit},{counts[i]})'
            body=f'{sync}\nfor(uint job=worker;job<({limit})*{len(group)}u;job+={workers}u) {{\nuint task_id=job/{len(group)}u;\nswitch(job%{len(group)}u) {{\n'
            for case,i in enumerate(group):
                body+=f'case {case}u: {{ using namespace s{i}; if(task_id<({counts[i]})) {{ {task_calls[i]} }} break; }}\n'
            body+='}\nthreadgroup_barrier(mem_flags::mem_threadgroup);\n}\n'
            interleaved.append(body)
        calls=interleaved
    if schedule=='queue':
        setup='threadgroup uint queue_job;\nif(worker==0u && tid==0u) {\n'
        initial=workers*task_batch if task_seed else 0
        setup+=''.join(f'atomic_store_explicit(task_queue+{i}u,{initial}u,memory_order_relaxed);\n' for i in range(len(p.ops)))+'}\n'
        if task_stats:
            setup+='if(tid==0u) {\n'+''.join(f'atomic_store_explicit(task_queue+{len(p.ops)+i*workers}u+worker,0u,memory_order_relaxed);\n' for i in range(len(p.ops)))+'}\n'
        calls.insert(0,setup)
    barrier_src=(KERNELS_DIR / 'static_barrier_serial.metal').read_text()
    if barrier == 'simd':
        barrier_src=(KERNELS_DIR / 'static_barrier_simd.metal').read_text()
    elif barrier == 'leader':
        barrier_src=(KERNELS_DIR / 'static_barrier_leader.metal').read_text()
    src+=f'\n#define WORKERS {workers}u\n'+barrier_src
    src+='\nkernel void full_gdn('+','.join(arguments)+') {\nthreadgroup uint ok;\nthreadgroup uchar scratch['+('max('+','.join(sizes)+')' if len(sizes)==2 else 'max({'+','.join(sizes)+'})')+'];\n'+''.join(calls)+'}\n'
    # MSL max is binary, not an initializer-list overload.
    size=sizes[0]
    for x in sizes[1:]:size=f'(({size})>({x})?({size}):({x}))'
    src=re.sub(r'threadgroup uchar scratch\[.*?\];',f'threadgroup uchar scratch[{size}];',src)
    out=copy.deepcopy(p);out.kernels={'mega':KernelSpec(src,'full_gdn',{},4<<16)}
    out.buffers['mega.flags']=BufferSpec((workers+(2 if barrier=='leader' else 1))*4)
    out.ops=[OpSpec('mega',[(i,n,0) for n,i in bi.items()]+[(len(names),'mega.flags',0)],(workers,1,1),(32*sgs,1,1))]
    if schedule=='queue':
        out.buffers['mega.tasks']=BufferSpec(len(p.ops)*(1+(workers if task_stats else 0))*4)
        out.ops[0].bindings.append((len(names)+1,'mega.tasks',0))
        out.ops[0].meta.update(task_workers=workers,task_stages=len(p.ops),task_stats=task_stats,
                               task_functions=[p.kernels[o.kernel].function for o in p.ops])
    src=src.replace('threadgroup uint ok;','')
    src=re.sub(r'(threadgroup uchar scratch\[.*?\];)',
               r'\1\nthreadgroup uint& ok=*((threadgroup uint*)scratch);',src,count=1)
    out.kernels['mega'].source=src
    return out


_MERGE_OPTIONS=('barrier','task_barrier','noinline','schedule','task_grain','task_batch','task_stats','attention_task_tiles','task_seed')


def compile_config(p, cfg):
    """Build a control and megakernel from a recorded experiment configuration."""
    sync={k:v for k,v in cfg.items() if k in _MERGE_OPTIONS}
    normalized=normalize(p,cfg['sgs'],groups=cfg['workers'],
                         **{k:v for k,v in cfg.items() if k not in ('workers','sgs',*sync)})
    return normalized,merge(normalized,cfg['workers'],cfg['sgs'],**sync)


def fuse_mixer_prefix(p, cfg):
    """Fuse the mixer while keeping the original two MLP projection kernels.

    Start from the complete layer so its fused residual/norm/permute producer
    is retained. Its NORM_TK belongs to the unchanged MLP consumer.
    """
    tail=p.ops[-2:]
    if [p.kernels[o.kernel].function for o in tail]!=['gemm_tile','gemm_tile'] or p.kernels[tail[0].kernel].macros.get('EPILOGUE')!='2':
        raise ValueError('expected the two fused MLP projections at the layer tail')
    if p.kernels[p.ops[-3].kernel].macros.get('NORM_OUT')!='1':
        raise ValueError('mixer-prefix fusion requires the producer normalization boundary')
    prefix=copy.deepcopy(p);prefix.ops=prefix.ops[:-2]
    control=normalize(prefix,cfg['sgs'],groups=cfg['workers'],
        **{k:v for k,v in cfg.items() if k not in ('workers','sgs',*_MERGE_OPTIONS)})
    for old,new in zip(prefix.ops,control.ops):
        old_kernel=prefix.kernels[old.kernel];new_kernel=control.kernels[new.kernel]
        if old_kernel.macros.get('NORM_OUT')=='1':
            new_kernel.macros['NORM_TK']=old_kernel.macros['NORM_TK']
    sync={k:v for k,v in cfg.items() if k in _MERGE_OPTIONS}
    fused=merge(control,cfg['workers'],cfg['sgs'],**sync)
    for result in (control,fused):
        for o in tail:
            key='native_tail.'+o.kernel
            result.kernels[key]=copy.deepcopy(p.kernels[o.kernel])
            op=copy.deepcopy(o);op.kernel=key;result.ops.append(op)
        result.kernels={o.kernel:result.kernels[o.kernel] for o in result.ops}
    return control,fused
