"""Full projection-inclusive static block: compare with its split control."""
import numpy as np
import pytest

from monolith.formats.fp import f32_to_bf16
from monolith.runtime import Engine, _native as nt
from tools.bench.gdn_block_bench import fixture, program, initialize, checked_run, snapshot
from tools.bench.gdn_block_static import normalize, merge


@pytest.fixture(scope='module')
def block(tmp_path_factory):
    pytest.importorskip('torch')
    pytest.importorskip('safetensors')
    dev = nt.Device()
    root = tmp_path_factory.mktemp('gdn-block')
    fixture(root, hidden=1024, hk=8, hv=16)
    # Reopening an existing fixture must restore the mixed FP8/BF16 slabs.
    module, pack = fixture(root, hidden=1024, hk=8, hv=16)
    return dev, module, program(dev, module, pack)


@pytest.mark.parametrize('sgs,workers,tn,split,extra,sync', [
    (4,4,16,False,{},{}), (16,8,16,False,{},{}),
    (8,8,32,True,{},{}), (16,8,32,True,{},{}),
    (16,8,32,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','task_barrier':False}),
    (16,8,16,True,{'compact':True,'gdn_sl':8},{'barrier':'leader','task_barrier':False}),
    (16,8,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','task_barrier':False,'schedule':'interleave'}),
    (16,8,32,True,{'compact':True,'scalar_sgs':1},{'barrier':'simd','task_barrier':False}),
    (16,8,16,True,{'short_decode':True},{'barrier':'simd','task_barrier':False}),
    (16,8,16,True,{'compact':True,'narrow_weights':True},{'barrier':'simd','task_barrier':False}),
    (16,8,16,True,{'ksplit':8,'compact':True},{'barrier':'simd','task_barrier':False}),
    (16,8,16,True,{'ksplit':2,'compact':True,'ragged_teams':True},{'barrier':'simd','task_barrier':False}),
    (16,8,16,True,{'ksplit':2,'compact':True,'ragged_teams':True},{'barrier':'simd','schedule':'queue','task_grain':'tile','task_seed':True}),
    (16,8,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','dual_permute':True}),
    (16,8,16,True,{'compact':True,'gdn_sl':8},{'barrier':'simd','dual_permute':True,'gdn_fused_norm':True,'schedule':'queue','task_grain':'tile','task_seed':True}),
    (16,8,16,True,{'compact':True,'gdn_sl':4,'gdn_tp':4},{'barrier':'simd'}),
    (16,8,16,True,{'compact':True,'gdn_sl':8,'gdn_tp':2},{'barrier':'simd','gdn_fused_norm':True}),
    (16,8,16,True,{'compact':True,'gdn_sl':8},{'barrier':'simd','gdn_fused_norm':True}),
    (32,4,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','gdn_fused_norm':True}),
    (8,8,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','gdn_prepare':'global'}),
    (16,8,16,True,{'compact':True,'gdn_sl':8},{'barrier':'simd','gdn_fused_norm':True,'gdn_prepare':'global'}),
    (16,8,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','gdn_vector':2,'gdn_unroll':2}),
    (16,8,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','gdn_vector':4,'gdn_unroll':4}),
    (16,8,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','gdn_unroll':8}),
    (4,8,32,True,{'compact':True,'gdn_sl':32},{'barrier':'simd','gdn_fused_norm':True}),
    (8,8,32,True,{'compact':True,'gdn_sl':16},{'barrier':'simd','gdn_fused_norm':True}),
    (2,8,16,True,{'compact':True,'gdn_sl':8,'scalar_sgs':1},{'barrier':'simd'}),
    (1,8,16,True,{'compact':True,'gdn_sl':8,'scalar_sgs':1},{'barrier':'simd'}),
    (8,8,32,True,{'compact':True,'gdn_sl':8,'tk':16},{'barrier':'simd'}),
    (16,8,16,True,{'compact':True,'gdn_sl':4,'perm_sgs':4},{'barrier':'simd','direct_norm':True}),
    (16,8,16,True,{'compact':True,'gdn_sl':4,'perm_sgs':8},{'barrier':'simd','direct_norm':True,'dual_permute':True}),
    (16,8,16,True,{'compact':True,'gdn_sl':4,'ksplit':1},{'barrier':'simd','schedule':'queue','task_grain':'tile'}),
    (8,8,16,True,{'compact':True,'gdn_sl':4},{'barrier':'simd','schedule':'queue','task_grain':'tile','task_seed':True})])
def test_full_block_fusion_preserves_control_and_state(block, sgs, workers, tn, split, extra, sync):
    dev, module, p = block
    control = normalize(p, sgs, mode='coop', groups=workers, tn=tn, split=split,**extra)
    fused = merge(control, workers, sgs,**sync)
    assert len(fused.ops) == 1
    engines = [Engine(pr, dev) for pr in (control, fused)]
    for e in engines:
        initialize(e, module)
    rng = np.random.default_rng(100)
    for step in range(4):
        x = f32_to_bf16(rng.normal(0,.1,(8,1024)).astype(np.float32)).tobytes()
        for e in engines:
            e.buffers['hidden'].write(x,0)
            e.buffers[e.program.step_state].write(e.program.layout.pack({'step':step,'t_this_step':8}),0)
            checked_run(e,1)
        assert snapshot(engines[0],1024) == snapshot(engines[1],1024)
    for e in engines:
        checked_run(e,64)
    assert snapshot(engines[0],1024) == snapshot(engines[1],1024)


def test_ragged_multi_team_projection_is_rejected(block):
    _,_,p=block
    with pytest.raises(ValueError,match='ragged multi-team'):
        normalize(p,16,groups=8,tn=16,ksplit=2,compact=True)


@pytest.mark.parametrize('tk',[64,128,256])
def test_staged_reduction_tiles_preserve_state(block,tk):
    dev,module,p=block
    control=normalize(p,4,mode='staged',groups=8,tn=16,split=True,compact=True,staged_tk=tk)
    engines=[Engine(pr,dev) for pr in (control,merge(control,8,4,barrier='simd'))]
    for e in engines:
        initialize(e,module)
        checked_run(e,64)
    assert snapshot(engines[0],1024)==snapshot(engines[1],1024)
