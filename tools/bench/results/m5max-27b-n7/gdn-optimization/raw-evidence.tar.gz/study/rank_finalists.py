"""Independent finalist ranking, keeping fusion and packed controls separate."""
import json, statistics, math
from pathlib import Path
root=Path(__file__).resolve().parent
configs=json.loads((root/'finalists-configs.json').read_text())
rows=[]
for i in [0,1,30,62]:
 path=root/f'finalists-{i}.jsonl'
 if path.exists():rows.extend(json.loads(l) for l in path.read_text().splitlines())
def describe(good,engine,other,metric):
 ratios=[r['results'][engine][metric]/r['results'][other][metric] for r in good]
 paired=[r['samples'][engine][j][metric]/r['samples'][other][j][metric] for r in good for j in range(r['reps'])]
 return dict(geomean=math.exp(statistics.mean(math.log(x) for x in ratios)),min=min(ratios),max=max(ratios),
             paired_wins=sum(x<1 for x in paired),pairs=len(paired),paired_median=statistics.median(paired),
             layer_ratios={str(r['layer']):v for r,v in zip(good,ratios)})
def rank_engine(engine):
 rank=[]
 for index,c in enumerate(configs):
  rs=[r for r in rows if r['config']==c]
  good=[r for r in rs if 'results' in r]
  assert len({r['layer'] for r in good})==len(good),'duplicate finalist layer/config'
  rec=dict(index=index,config=c,layers=[r.get('layer') for r in good],rejections=[r['error'] for r in rs if 'error' in r])
  if good:
   for metric in ['gpu_us','wall_us']:
    for other in ['production','previous_geometry','matched_control']:
     rec[f'{metric}_over_{other}']=describe(good,engine,other,metric)
   rec['min_cosine']=min(r['check']['cosine'] for r in good)
  rank.append(rec)
 rank.sort(key=lambda r:r.get('wall_us_over_previous_geometry',{}).get('geomean',math.inf))
 return rank
for name,engine in [('finalists','single_kernel'),('control-finalists','matched_control')]:
 rank=rank_engine(engine)
 (root/(name+'-ranking.json')).write_text(json.dumps(rank,indent=2)+'\n')
 print(name)
 for r in rank:print(r['index'],r['layers'],r.get('wall_us_over_previous_geometry'),r['config'])
