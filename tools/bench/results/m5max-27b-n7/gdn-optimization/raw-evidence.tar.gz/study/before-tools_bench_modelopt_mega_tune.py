"""Paired fixed-T geometry search on real ModelOpt decoder halves (#141)."""
from __future__ import annotations
import argparse
import gc
import itertools
import json
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from tools.bench.modelopt_layer_bench import build, inputs, initialize, run_engine, metrics
from tools.bench.layer_vs_mlx import our_model
from tools.bench.gdn_block_static import compile_config, fuse_mixer_prefix
from monolith.generate import Session
from monolith.runtime import Engine
from monolith.formats.fp import bf16_to_f32


def task_distribution(engine):
    """Optional task-count instrumentation, never a per-core timing claim."""
    op=engine.program.ops[0]
    if not op.meta.get('task_stats'):return None
    workers,stages=op.meta['task_workers'],op.meta['task_stages']
    values=np.frombuffer(engine.read('mega.tasks'),np.uint32)
    counts=values[stages:].reshape(stages,workers)
    return [dict(stage=i,function=fn,total=int(c.sum()),active_workers=int(np.count_nonzero(c)),
                 min_tasks=int(c.min()),max_tasks=int(c.max()),per_worker=c.tolist())
            for i,(fn,c) in enumerate(zip(op.meta['task_functions'],counts))]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--model', required=True)
    ap.add_argument('--pack', required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--reps', type=int, default=5)
    ap.add_argument('--steps', type=int, default=8)
    ap.add_argument('--kind', choices=('all','gdn','mlp','attention','gdn-prefix','attention-prefix'), default='all')
    ap.add_argument('--configs', type=Path, help='JSON list of explicit configurations')
    ap.add_argument('--ctx', default='128,8192', help='attention context lengths for the paired screen')
    a = ap.parse_args()
    if min(a.steps,a.reps)<1: ap.error('steps and repetitions must be positive')
    a.out.parent.mkdir(parents=True,exist_ok=True)
    ctxs=list(map(int,a.ctx.split(',')))
    if not ctxs or min(ctxs)<0: ap.error('context lengths must be nonnegative')
    sess = Session(our_model(a.model,None,max(8704,max(ctxs)+256)),a.pack,attention='auto')
    cores = sess.dev.info().gpu_cores
    cases=[('gdn',0,'mixer'),('mlp',0,'mlp'),('attention',3,'mixer')]
    if a.kind.endswith('-prefix'): cases=[(a.kind,0 if a.kind=='gdn-prefix' else 3,'layer')]
    for kind,index,part in cases:
        if a.kind not in ('all',kind): continue
        p,output = build(sess,index,part)
        layer = sess.model.layers()[index]
        base = Engine(p,sess.dev)
        shared = {n:b for n,b in base.buffers.items() if p.buffers[n].role=='weights'}
        sglist = (4,8) if kind.startswith('attention') else (8,16)
        configs = list(itertools.product((cores,3*cores//2,2*cores),sglist,(16,32),(False,True)))
        if not kind.startswith('attention'):
            configs += [(cores,32,tn,split) for tn,split in itertools.product((16,32),(False,True))]
            configs += [(cores//2,16,16,False)]
        configs = (json.loads(a.configs.read_text()) if a.configs else
                   [dict(workers=w,sgs=s,tn=t,split=k) for w,s,t,k in configs])
        for cfg in configs:
            workers,sgs=cfg['workers'],cfg['sgs']
            engines = {'production':base}
            try:
                control,fused=(fuse_mixer_prefix if kind.endswith('-prefix') else compile_config)(p,cfg)
                engines['matched_control'] = Engine(control,sess.dev,buffers=shared)
                engines['single_kernel'] = Engine(fused,sess.dev,buffers=shared)
                for ctx in (ctxs if kind.startswith('attention') else (128,)):
                    x,state = inputs(layer,index,ctx)
                    for e in engines.values():
                        initialize(e,layer,x,state,ctx,part);run_engine(e,1)
                    snap = {n:e.read(output,x.size*2) for n,e in engines.items()}
                    assert snap['matched_control']==snap['single_kernel'],'control/fusion hidden mismatch'
                    for name,spec in p.buffers.items():
                        if spec.role=='state':
                            assert engines['matched_control'].read(name)==engines['single_kernel'].read(name),name
                    check = metrics(bf16_to_f32(np.frombuffer(snap['single_kernel'],np.uint16)),
                                    bf16_to_f32(np.frombuffer(snap['production'],np.uint16)))
                    assert check['finite'] and check['cosine']>=.9999 and check['relative_l2']<.005,check
                    for e in engines.values():
                        warm=0
                        while warm<30000: warm+=run_engine(e,a.steps)['gpu_us']*a.steps
                    samples={n:[] for n in engines}
                    rng=np.random.default_rng(141)
                    for rep in range(a.reps):
                        for n in rng.permutation(list(engines)):
                            samples[n].append(run_engine(engines[n],a.steps))
                    results={n:{metric:min(s[metric] for s in ss) for metric in ('gpu_us','wall_us')}
                             for n,ss in samples.items()}
                    row=dict(kind=kind,layer=index,ctx=ctx,config=cfg,check=check,control_bit_exact=True,
                             results=results,samples=samples,reps=a.reps,steps=a.steps,
                             dispatches={n:len(e.program.ops) for n,e in engines.items()},
                             task_distribution=task_distribution(engines['single_kernel']),
                             chip=sess.dev.info().name,cores=cores)
                    with a.out.open('a') as f: f.write(json.dumps(row)+'\n')
                    print(kind,ctx,cfg,{n:round(r['gpu_us'],2) for n,r in results.items()},flush=True)
            except (RuntimeError,ValueError,AssertionError) as err:
                # A timeout is a rejected configuration, never a timing sample.
                row=dict(kind=kind,config=cfg,error=str(err))
                with a.out.open('a') as f: f.write(json.dumps(row)+'\n')
                print('REJECTED',kind,cfg,str(err)[:400],flush=True)
            del engines
            gc.collect()
    return 0


if __name__=='__main__':
    raise SystemExit(main())
