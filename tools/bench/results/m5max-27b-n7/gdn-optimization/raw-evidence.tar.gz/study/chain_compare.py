"""Fixed-input decoder chain audit/timing; no tokens, sampling or speculation."""
import argparse,copy,json,sys,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from monolith.core import Graph,DType,T
from monolith.nn import LowerContext,state_shape
from monolith.compiler import emit_program
from monolith.compiler.passes import DEFAULT_PASSES
from monolith.generate import Session
from monolith.runtime import Engine
from monolith.formats.fp import bf16_to_f32, f32_to_bf16
from tools.bench.layer_vs_mlx import our_model
from tools.bench.modelopt_layer_bench import initialize,inputs,metrics,run_engine,source_digest

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--config',type=Path,required=True)
ap.add_argument('--reference',type=Path,required=True)
ap.add_argument('--layers',type=int,default=5)
ap.add_argument('--out',type=Path,required=True)
ap.add_argument('--reps',type=int,default=9)
ap.add_argument('--steps',type=int,default=16)
ap.add_argument('--real-inputs',action='store_true',help='Use real prompt embeddings and zero initial model state')
a=ap.parse_args()
sess=Session(our_model('/tmp/monolith-models/Qwen3.8-27B-NVFP4',None,512),'/tmp/monolith-m5max/target-pack')
g=Graph('fixed_decoder_chain');lc=LowerContext(t=T)
for name,(dtype,arr) in sess.model.tables().items():lc.consts[name]=g.const(name,tuple(arr.shape),DType.parse(dtype.lower()))
h=g.input('hidden',(T,5120),DType.BF16);outputs=[]
for layer in sess.model.layers()[:a.layers]:
 for entry in layer.mixer.state_entries():lc.states[entry.name]=g.state(entry.name,state_shape(entry),entry.dtype)
 h=layer.mixer.lower(g,h,layer.input_norm.lower(g,h),lc)
 h=layer.mlp.lower(g,h,layer.post_norm.lower(g,h),lc)
 outputs.append(h.name)
g.check()
for ps in DEFAULT_PASSES:ps(g)
configs={'original':None,'previous':json.loads(a.reference.read_text()),'candidate':json.loads(a.config.read_text())}
programs={};engines={};shared={}
for name,cfg in configs.items():
 profile=copy.deepcopy(sess.profile)
 if cfg:profile.gdn_mixer_fusion=dict(cfg,shape=[5120,16,48,128,128,4])
 program=emit_program(g,pack=sess.pack,profile=profile,t=8,tuner=sess.tuner,tail=None,gdn_mixer_fusion=cfg is not None)
 programs[name]=program;engines[name]=Engine(program,sess.dev,buffers=shared)
 shared.update({n:b for n,b in engines[name].buffers.items() if program.buffers[n].role=='weights'})
 expected=sum(i%4!=3 for i in range(a.layers))
 assert sum(o.name=='gdn_mixer_megakernel' for o in program.ops)==(expected if cfg else 0)
for i,layer in enumerate(sess.model.layers()[:a.layers]):
 x,state=inputs(layer,i,128)
 for e in engines.values():initialize(e,layer,x,state,128,'layer')
real_inputs=None
if a.real_inputs:
 from tokenizers import Tokenizer
 from monolith.formats.safetensors_reader import SafetensorsDir
 tokenizer=Tokenizer.from_file('/tmp/monolith-models/Qwen3.8-27B-NVFP4/tokenizer.json')
 text='The scientific method begins with a question, develops a testable hypothesis, and compares predictions with careful observations. Measurements should be repeated and uncertainty reported. Explain how controlled experiments help separate cause from correlation.'
 ids=tokenizer.encode(text,add_special_tokens=False).ids[:32]
 assert len(ids)==32
 ck=SafetensorsDir('/tmp/monolith-models/Qwen3.8-27B-NVFP4')
 embedding=ck.get('model.language_model.embed_tokens.weight')
 assert embedding.dtype==np.uint16,embedding.dtype
 real_inputs=[np.array(embedding[ids[i:i+8]],copy=True).tobytes() for i in range(0,32,8)]
 del embedding;ck.close()
 for e in engines.values():
  for name,spec in e.program.buffers.items():
   if spec.role=='state':e.buffers[name].fill(0)
checks=[]
for step in range(4):
 x=real_inputs[step] if real_inputs else f32_to_bf16(np.random.default_rng(2000+step).normal(0,.1,(8,5120)).astype(np.float32)).tobytes()
 for e in engines.values():
  e.buffers['hidden'].write(x,0)
  e.buffers[e.program.step_state].write(e.program.layout.pack({'step':step,'position':(0 if real_inputs else 128)+8*step,'t_this_step':8}),0)
  e.run(1,steps_per_cb=1,in_flight=2)
 for name in outputs:
  values={key:bf16_to_f32(np.frombuffer(e.read(name,8*5120*2),np.uint16)) for key,e in engines.items()}
  for key in ['previous','candidate']:checks.append(dict(step=step,buffer=name,engine=key,**metrics(values[key],values['original'])))
 for name,spec in programs['original'].buffers.items():
  if spec.role!='state':continue
  dtype=np.float32 if name.endswith('rec_state') else np.uint16
  values={key:np.frombuffer(e.read(name),dtype) for key,e in engines.items()}
  if dtype==np.uint16:values={key:bf16_to_f32(v) for key,v in values.items()}
  for key in ['previous','candidate']:checks.append(dict(step=step,buffer=name,engine=key,**metrics(values[key],values['original'])))
correct=all(c['finite'] and c['cosine']>.999 for c in checks)
audit=dict(layers=a.layers,real_inputs=bool(real_inputs),token_ids=ids if real_inputs else None,passed=correct,checks=checks)
a.out.with_suffix('.checks.json').write_text(json.dumps(audit,indent=2)+'\n')
assert correct,sorted(checks,key=lambda c:c['cosine'])[:3]
before={key:e.read(outputs[-1]) for key,e in engines.items()}
state_before={key:{n:hashlib.sha256(e.read(n)).hexdigest() for n,spec in programs['original'].buffers.items() if spec.role=='state'} for key,e in engines.items()}
for e in engines.values():
 for _ in range(3):run_engine(e,a.steps)
samples={key:[] for key in engines};rng=np.random.default_rng(141)
for _ in range(a.reps):
 for key in rng.permutation(list(engines)):samples[key].append(run_engine(engines[key],a.steps))
for key,e in engines.items():
 assert before[key]==e.read(outputs[-1])
 for name,digest in state_before[key].items():assert hashlib.sha256(e.read(name)).hexdigest()==digest, (key,name,'fixed replay state changed')
summary={key:{field:min(r[field] for r in values) for field in ['gpu_us','wall_us']} for key,values in samples.items()}
row=dict(layers=a.layers,reps=a.reps,steps=a.steps,rows=8,configs=configs,dispatches={key:len(p.ops) for key,p in programs.items()},
         results=summary,samples=samples,input_seeds=None if real_inputs else [2000+i for i in range(4)],real_inputs=bool(real_inputs),token_ids=ids if real_inputs else None,
         generated_source_sha256={key:source_digest(p) for key,p in programs.items()},min_cosine=min(c['cosine'] for c in checks),checks=checks,replay_bit_exact=True,
         unique_weight_bytes=sum(b.nbytes for b in shared.values()),recommended_working_set=sess.dev.info().recommended_working_set,
         bound_weight_bytes={key:sum(p.buffers[n].nbytes for n in {n for op in p.ops for _,n,_ in op.bindings} if p.buffers[n].role=='weights') for key,p in programs.items()})
a.out.write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps({k:v for k,v in row.items() if k not in ['samples','checks']},indent=2))
