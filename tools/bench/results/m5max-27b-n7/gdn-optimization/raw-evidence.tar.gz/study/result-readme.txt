GDN mixer optimization evidence — M5 Max, 40 cores, fixed T=8 (N=7)

The report is docs/research/m5max-gdn-mixer-optimization.md.
all48.csv and all48.summary.json compare complete GDN layers, with native MLPs.
production disables fusion; previous_geometry is the previous recipe;
default is the actual automatic profile; megakernel is explicit fusion;
matched_control uses the same packing and projection geometry without merging;
packed_control is a separately selected control; mlx/mlx_bf16 are both MLX paths.
Wall time is the cross-engine comparison. Shader-audit timings are not performance results.

coverage.json counts screening trials only, including invalid proposals as rejections.
The nine-finalist repeats, all48 comparisons, mixer repeats and chain runs are separate.
chain5/chain64-real are consecutive decoder layers, without embeddings or language-model head.
Original model state and hidden output must remain bit-identical on fixed-input replay.

raw-evidence.tar.gz contains study scripts, configs, paired samples, logs,
source snapshots, pack metadata and source-manifest.json. It contains no weights.
Extract into a temporary directory. Reproduction scripts use local absolute paths;
adjust model, original pack and repository paths before running. Keep GPU runs serial.
run_final_validation.sh refuses existing outputs to prevent duplicate measurements.
The profile in source/profiles is the selected measured recipe.

The 64-layer synthetic stress failed the unchanged full-chain cosine gate; chain64.log preserves it. chain64-real.json uses actual prompt embeddings and zero initial state and passes. The first two local diagnostics (*-stale-scratch.* and *-layout-mismatch.*) are invalid because they copied native normalized operands without translating the producer layout. The corrected chain_diagnostic.py captures inputs before each layer, translates TK=256 to TK=32 at47boundaries, and reports local and accumulated gates separately. make_chain_diagnostic.py is a historical generator; use the corrected chain_diagnostic.py directly. Its results are diagnostic, never timing evidence.
