"""Select a small diverse shortlist; selection is followed by independent repeats."""
import json, subprocess, sys, shutil
from pathlib import Path
root=Path(__file__).resolve().parent
# One final finite combination pass uses the completed interaction evidence.
# The parent shell calls this only after that GPU process has exited.
polish_result=root/'refine-polish.jsonl'
polish_plan=root/'refine-polish-configs.json'
if not polish_result.exists():
 subprocess.run([sys.executable,str(root/'build_refinement.py'),'--stage','polish'],check=True)
 proposed=json.loads(polish_plan.read_text());known=set()
 for path in root.glob('*.jsonl'):
  if any(s in path.stem for s in ('smoke','audit','finalist','validation')):continue
  for line in path.read_text().splitlines():
   row=json.loads(line)
   if row.get('kind')=='gdn-prefix':known.add(json.dumps(row['config'],sort_keys=True))
 pending=[c for c in proposed if json.dumps(c,sort_keys=True) not in known]
 (root/'refine-polish-proposals.json').write_text(json.dumps(proposed,indent=2)+'\n')
 polish_plan.write_text(json.dumps(pending,indent=2)+'\n')
 print('Final combination pass:',len(pending),'new configs;',len(proposed)-len(pending),'already measured',flush=True)
 shutil.copyfile(Path.cwd()/'monolith/compiler/static_fusion.py',root/'refine-polish-compiler.py')
 if pending:
  command=[sys.executable,'tools/bench/modelopt_mega_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4',
           '--pack','/tmp/monolith-m5max/target-pack','--kind','gdn-prefix','--configs',str(polish_plan),
           '--reference-config',str(root/'baseline.json'),'--reps','5','--steps','16','--out',str(polish_result)]
  with (root/'refine-polish.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 else:polish_result.write_text('')
assert len(polish_result.read_text().splitlines())==len(json.loads(polish_plan.read_text())), 'incomplete final combination pass'
rows=[]
for path in root.glob('*.jsonl'):
 if any(s in path.stem for s in ('smoke','audit','finalist','validation')):continue
 for line in path.read_text().splitlines():
  r=json.loads(line)
  if r.get('kind')=='gdn-prefix' and 'results' in r and 'previous_geometry' in r['results']:rows.append(r)
ratio=lambda r:r['results']['single_kernel']['gpu_us']/r['results']['previous_geometry']['gpu_us']
rows.sort(key=ratio)
out=[];seen=set();seen_sources=set()
def add(cfg):
 key=json.dumps(cfg,sort_keys=True)
 source=next((r.get('generated_source_sha256',{}).get('single_kernel') for r in rows if r['config']==cfg),None)
 if key not in seen and (source is None or source not in seen_sources):
  seen.add(key);seen_sources.add(source);out.append(cfg)
add(json.loads((root/'packing-winner.json').read_text()))
for sg in (16,8,4):
 candidates=[r for r in rows if r['config']['sgs']==sg and r['config'].get('fp8_layout')=='tile']
 if candidates:add(candidates[0]['config'])
for r in rows:
 add(r['config'])
 if len(out)>=8:break
control_rows=sorted(rows,key=lambda r:r['results']['matched_control']['gpu_us']/r['results']['previous_geometry']['gpu_us'])
control_seen=set();control_configs=[]
for r in control_rows:
 source=r.get('generated_source_sha256',{}).get('matched_control')
 if source is not None and source in control_seen:continue
 control_seen.add(source);control_configs.append(r['config']);add(r['config'])
 if len(control_configs)==3:break
(root/'control-finalists-configs.json').write_text(json.dumps(control_configs,indent=2)+'\n')
(root/'finalists-configs.json').write_text(json.dumps(out,indent=2)+'\n')
print(len(out),'finalists selected for independent layer 0/1/30/62 repeats')
