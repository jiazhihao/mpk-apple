"""Summarize measured domains, rejections and evidence without counting plans."""
import json,collections,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
phases=['geometry','structural','scheduler','fp8','projection','packing','packing-geometry','packing-wide','half-operand','extended','occupancy','nonpower','codegen','traversal','prefetch','interleave','predecoded','independent-grid','polling','refine-knobs','refine-workers','refine-projections','refine-projection-families','refine-interactions','refine-polish','refinement']
report={};all_rows=[]
for phase in phases:
 path=root/(phase+'.jsonl');plan=root/(phase+'-configs.json')
 if not path.exists():continue
 rows=[json.loads(l) for l in path.read_text().splitlines()]
 accepted=[r for r in rows if 'results' in r]
 report[phase]=dict(measured=len(rows),accepted=len(accepted),rejected=len(rows)-len(accepted),
  proposed=len(json.loads(plan.read_text())) if plan.exists() else None,
  rejection_reasons=dict(collections.Counter(r['error'].splitlines()[0] for r in rows if 'error' in r)),
  raw_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 all_rows.extend(rows)
domains=collections.defaultdict(set)
for r in all_rows:
 for k,v in r['config'].items():domains[k].add(json.dumps(v,sort_keys=True))
accepted=[r for r in all_rows if 'results' in r]
source_rows=[r for r in accepted if r.get('generated_source_sha256',{}).get('single_kernel')]
summary=dict(total_measured=len(all_rows),total_accepted=len(accepted),
 accepted_unique_configs=len({json.dumps(r['config'],sort_keys=True) for r in accepted}),
 source_hash_rows=len(source_rows),
 post_timing_replay_rows=sum(r.get("replay_bit_exact",False) for r in accepted),
 accepted_unique_kernel_sources=len({r['generated_source_sha256']['single_kernel'] for r in source_rows}),
 baseline_shader_sources={name:dict(collections.Counter(r.get('generated_source_sha256',{}).get(name) for r in source_rows)) for name in ('production','previous_geometry')},
 total_rejected=sum('error' in r for r in all_rows),phases=report,
 domains={k:[json.loads(s) for s in sorted(v)] for k,v in sorted(domains.items()) if k!='gemm_overrides'},
 limit='Finite adaptive domains, not the Cartesian product of every knob or all possible kernel algorithms. Instrumented audits are excluded from performance counts.')
(root/'coverage.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['domains','phases']},indent=2))
