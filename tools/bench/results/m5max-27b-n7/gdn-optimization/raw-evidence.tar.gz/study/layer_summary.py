import argparse,csv,json,statistics
from pathlib import Path
ap=argparse.ArgumentParser()
ap.add_argument('input',type=Path)
ap.add_argument('--prefix',type=Path,required=True)
a=ap.parse_args()
rows=[json.loads(l) for l in a.input.read_text().splitlines()]
assert rows and all(r['oracle_pass'] for r in rows)
assert len({r['layer'] for r in rows})==len(rows),'duplicate layer measurements'
engines=list(rows[0]['results'])
comparators=['production','previous_geometry','mlx_best']
if 'matched_control' in engines:comparators.append('matched_control')
if 'packed_control' in engines:comparators.append('packed_control')
selected='default' if 'default' in engines else 'megakernel'
records=[]
for r in rows:
 out={k:r[k] for k in ['layer','ctx','reps','steps']}
 out['min_cosine']=min(c['cosine'] for c in r['checks'].values() if isinstance(c,dict))
 for name,v in r['results'].items():
  out[name+'_wall_us']=v['min_wall_us']
  if 'min_gpu_us' in v:out[name+'_gpu_us']=v['min_gpu_us']
 refs=[n for n in engines if n.startswith('mlx')]
 out['mlx_best_wall_us']=min(r['results'][n]['min_wall_us'] for n in refs)
 for other in comparators:
  out[selected+'_over_'+other]=out[selected+'_wall_us']/out[other+'_wall_us']
  comparison=lambda i:min(r['samples'][n][i]['wall_us'] for n in refs) if other=='mlx_best' else r['samples'][other][i]['wall_us']
  out['wins_over_'+other]=sum(r['samples'][selected][i]['wall_us']<comparison(i) for i in range(r['reps']))
 out['default_bit_exact']=r['checks'].get('default_matches_explicit_fusion')
 records.append(out)
a.prefix.parent.mkdir(parents=True,exist_ok=True)
with a.prefix.with_suffix('.csv').open('w') as f:
 w=csv.DictWriter(f,list(records[0]));w.writeheader();w.writerows(records)
summary=dict(layers=len(rows),selected=selected,total_pairs=sum(r['reps'] for r in rows),min_cosine=min(r['min_cosine'] for r in records),
 mean_min_wall_us={name:statistics.mean(r[name+'_wall_us'] for r in records) for name in engines+['mlx_best']},
 comparisons={other:dict(mean_ratio=statistics.mean(r[selected+'_over_'+other] for r in records),
                        min_ratio=min(r[selected+'_over_'+other] for r in records),max_ratio=max(r[selected+'_over_'+other] for r in records),
                        layers_faster=sum(r[selected+'_over_'+other]<1 for r in records),
                        layers_over_3pct=sum(r[selected+'_over_'+other]<.97 for r in records),
                        paired_wins=sum(r['wins_over_'+other] for r in records)) for other in comparators})
a.prefix.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
