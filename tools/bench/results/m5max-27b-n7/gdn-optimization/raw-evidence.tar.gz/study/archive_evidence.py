"""Archive completed GDN evidence only; never model or derived weight binaries."""
import argparse, datetime, gzip, hashlib, io, json, shutil, subprocess, tarfile
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
root=Path(__file__).resolve().parent;repo=Path.cwd();a.out.mkdir(parents=True,exist_ok=True)
required=['all48.jsonl','all48.csv','all48.summary.json','all48-shader.jsonl','chain5-shader.json','chain5.json',
          'selected.json','selected-control-layer.json','coverage.json','final-regressions.log',
          'chain64-real.json','chain64-diagnostic.json','chain-finalists-ranking.json','final-validation.json']
for name in required:assert (root/name).exists(),name
rows=[json.loads(x) for x in (root/'all48.jsonl').read_text().splitlines()]
assert {r['layer'] for r in rows}=={i for i in range(64) if i%4!=3}
assert len(rows)==48 and all(r['oracle_pass'] for r in rows)
coverage=json.loads((root/'coverage.json').read_text())
assert all(v['proposed'] is None or v['measured']==v['proposed'] for v in coverage['phases'].values())
source_paths=['monolith/compiler/static_fusion.py','monolith/compiler/fp8_tiles.py','monolith/compiler/gdn_fusion.py',
 'monolith/compiler/emit.py','monolith/core/profile.py','monolith/core/step_state.py','monolith/generate.py','monolith/runtime/engine.py',
 'profiles/apple-m5-max-40c.json','kernels/static_barrier_simd.metal','kernels/static_barrier_serial.metal',
 'kernels/static_barrier_leader.metal','kernels/static_barrier_wide.metal','kernels/gemm_tile.metal','kernels/gdn_mixer.metal',
 'tests/contract/test_static_geometry.py','tests/contract/test_fp8_tiles.py','tests/contract/test_profiles.py',
 'tests/kernels/test_gdn_block_static.py','tests/kernels/test_gdn_default.py','tests/kernels/test_attention_static.py','tests/kernels/test_mlp_block_static.py',
 'tools/bench/modelopt_mega_tune.py','tools/bench/modelopt_layer_bench.py','tools/bench/modelopt_mlx.py','tools/bench/gdn_block_static.py',
 'docs/research/m5max-gdn-mixer-optimization.md','profiles/README.md','tools/bench/README.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 git_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
 checkpoint='nvidia/Qwen3.8-27B-NVFP4',revision='482ca0f3832238542f8f5295dde86b5f22711d80',
 source_sha256={name:sha(repo/name) for name in source_paths},
 pack_metadata_sha256={name:sha(Path('/tmp/monolith-m5max/target-pack')/name) for name in ['manifest.json','autotune.apple-m5-max.json']})
(a.out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['all48.csv','all48.summary.json','coverage.json','selected.json','selected-control-layer.json',
             'chain5.json','chain64-real.json','chain64-diagnostic.json','chain-finalists-ranking.json','final-validation.json']:
 shutil.copyfile(root/name,a.out/name)
archive=a.out/'raw-evidence.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as compressed, tarfile.open(fileobj=compressed,mode='w') as tar:
 def add(path,arcname):
  info=tar.gettarinfo(str(path),arcname);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with path.open('rb') as data:tar.addfile(info,data)
 for path in sorted(root.iterdir()):
  if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.metal','.csv','.sh','.txt'}:
   add(path,'study/'+path.name)
 for name in source_paths:add(repo/name,'source/'+name)
 for name in ['manifest.json','autotune.apple-m5-max.json']:
  add(Path('/tmp/monolith-m5max/target-pack')/name,'pack-metadata/'+name)
 add(a.out/'source-manifest.json','source-manifest.json')
(a.out/'raw-evidence.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
print(archive,archive.stat().st_size,'bytes')
