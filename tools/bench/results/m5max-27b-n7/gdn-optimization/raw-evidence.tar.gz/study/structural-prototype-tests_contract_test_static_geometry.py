"""Distinct slab segments can reuse one compiled projection kernel."""
import struct
import pytest
from monolith.runtime.program import Program, KernelSpec, BufferSpec, OpSpec
from tools.bench.gdn_block_static import normalize, merge


def test_wider_tile_updates_each_parameter_record_for_shared_kernel():
    p=Program(kernels={'shared':KernelSpec('', 'gemm_tile', {'TN':'16u','KSPLIT':'1u'})},
              buffers={name:BufferSpec(32,struct.pack('<IIIIfIII',rows,rows//16,320,8,1.,tile0,1024,0),'params')
                       for name,rows,tile0 in [('core',8192,0),('gate',6144,512)]},
              ops=[OpSpec('shared',[(4,name,0)],(40,1,1),(256,1,1)) for name in ('core','gate')])
    got=normalize(p,8,groups=80,tn=32,split=True)
    core,gate=[struct.unpack('<IIIIfIII',got.buffers[n].init) for n in ('core','gate')]
    assert (core[1],core[5])==(256,0)
    assert (gate[1],gate[5])==(192,256)
    assert core[2]==gate[2]==640
    assert struct.unpack('<IIIIfIII',p.buffers['gate'].init)[5]==512


@pytest.mark.parametrize('workers',[0,-1,257])
def test_invalid_worker_stride_is_rejected_before_shader_emission(workers):
    with pytest.raises(ValueError,match='worker count'):
        merge(Program({}, {}, []),workers,16)


def test_zero_projection_stride_is_rejected():
    with pytest.raises(ValueError,match='projection task groups'):
        normalize(Program({}, {}, []),16,groups=0)


@pytest.mark.parametrize('kw', [{'attention_groups':0},{'attention_groups':4097},
                               {'attention_qm':32},{'merge_sgs':16},{'merge_unroll':3}])
def test_invalid_attention_geometry_is_rejected(kw):
    with pytest.raises(ValueError):
        normalize(Program({}, {}, []),8,**kw)


def test_attention_merge_unroll_changes_the_preprocessed_task():
    from monolith import kernels
    from monolith.compiler.static_fusion import stage
    p=Program(kernels={'merge':KernelSpec(kernels.gqa_source(),'gqa_merge',kernels.gqa_macros(256))},
              buffers={},ops=[OpSpec('merge',[],(192,1,1),(32,1,1))])
    got=normalize(p,8,merge_sgs=2,merge_unroll=16)
    source,_=stage(got.kernels['merge'],0)
    assert 'm_c[16u]' in source and 'c0 += 16u' in source
    assert got.ops[0].grid==(96,1,1)
    assert '#define MERGE_UNROLL 4u' in p.kernels['merge'].source


def test_attention_stride_updates_specialization_and_parameter_record():
    from monolith import kernels
    record=bytearray(80)
    struct.pack_into('<I',record,16,160)
    p=Program(kernels={'core':KernelSpec(kernels.gqa_source(mma=True),'gqa_decode_mma',
              dict(kernels.gqa_macros(256),STATIC_GQA_P_N_SG='160u'))},
              buffers={'params':BufferSpec(80,bytes(record),'params')},
              ops=[OpSpec('core',[(9,'params',0)],(160,1,1),(256,1,1))])
    got=normalize(p,4,attention_groups=320,attention_qm=8)
    assert got.ops[0].grid==(320,1,1) and got.ops[0].threadgroup==(128,1,1)
    assert got.kernels['core'].macros['STATIC_GQA_P_N_SG']=='320u'
    assert struct.unpack_from('<I',got.buffers['params'].init,16)[0]==320
    assert '#define QM 8' in got.kernels['core'].source
    assert struct.unpack_from('<I',p.buffers['params'].init,16)[0]==160


@pytest.mark.parametrize('kw',[{'task_grain':'unknown'},{'task_batch':0},{'task_batch':3},
                              {'task_batch':True},{'task_stats':True},{'attention_task_tiles':0}])
def test_invalid_task_schedule_is_rejected(kw):
    with pytest.raises(ValueError):merge(Program({}, {}, []),80,8,**kw)


@pytest.mark.parametrize('kw',[{'gdn_prepare':'unknown'},{'gdn_unroll':3},
                              {'gdn_unroll':True},{'gdn_vector':3},{'gdn_vector':True}])
def test_invalid_recurrence_schedule_is_rejected(kw):
    with pytest.raises(ValueError):merge(Program({}, {}, []),80,8,**kw)


@pytest.mark.parametrize('kw',[{'tk':16},{'tk':64,'short_decode':True},
                              {'tk':64,'narrow_scales':True},{'tk':64,'mode':'staged'}])
def test_invalid_reduction_tile_is_rejected(kw):
    with pytest.raises(ValueError):normalize(Program({}, {}, []),8,**kw)


def test_tile_tasks_privatize_shared_projection_strides():
    from monolith.compiler.static_fusion import _tile_tasks
    p=Program(kernels={'shared':KernelSpec('', 'gemm_tile', {'KSPLIT':'8u'})},
              buffers={n:BufferSpec(32,struct.pack('<IIIIfIII',rows,rows//16,640,8,1.,0,1024,0),'params')
                       for n,rows in [('core',8192),('gate',6144)]},
              ops=[OpSpec('shared',[(4,n,0)],(80,1,1),(256,1,1)) for n in ('core','gate')])
    got=_tile_tasks(p,8,80,1)
    assert [o.grid[0] for o in got.ops]==[512,384]
    assert len({o.kernel for o in got.ops})==2
    for o in got.ops:
        n=o.bindings[0][1]
        assert struct.unpack_from('<I',got.buffers[n].init,8)[0]==o.grid[0]*8
        assert got.kernels[o.kernel].macros['STATIC_GEMM_P_N_SG']==f'{o.grid[0]*8}u'
    assert struct.unpack_from('<I',p.buffers['core'].init,8)[0]==640
