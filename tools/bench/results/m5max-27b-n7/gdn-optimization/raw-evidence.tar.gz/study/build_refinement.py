"""Adaptive, finite refinement domains; preserves every proposed configuration."""
import json, itertools, argparse, subprocess, sys, shutil
from pathlib import Path
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['knobs','workers','projections','interactions','polish'],default='knobs');a=ap.parse_args()
read=lambda n:json.loads((root/n).read_text())
rows=[]
for path in root.glob('*.jsonl'):
 if 'smoke' in path.stem or 'audit' in path.stem or 'validation' in path.stem:continue
 for line in path.read_text().splitlines():
  r=json.loads(line)
  if r.get('kind')=='gdn-prefix' and 'results' in r and 'previous_geometry' in r['results']:
   rows.append(r)
ratio=lambda r:r['results']['single_kernel']['gpu_us']/r['results']['previous_geometry']['gpu_us']
ordered=sorted(rows,key=ratio)
# The interaction pass first completes projection checks for the other
# competitive families. The shell invokes this after the SG16 projection
# process exits, so GPU measurements stay strictly serial.
if a.stage=='interactions':
 name='refine-projection-families'
 configs_path=root/(name+'-configs.json');results_path=root/(name+'.jsonl')
 if not results_path.exists():
  proposals=[];keys=set()
  def propose(c):
   key=json.dumps(c,sort_keys=True)
   if key not in keys:keys.add(key);proposals.append(c)
  for groups in (8,4):
   choices=[r for r in ordered if r['config']['sgs']==groups and r['config'].get('fp8_layout')=='tile']
   if not choices:continue
   family=choices[0]['config']
   for stage,tn,ks,grid in itertools.product(range(4),(16,32),[k for k in (1,2,4,8) if groups%k==0],(40,80,120,160,240)):
    overrides=dict(family.get('gemm_overrides',{}))
    overrides[str(stage)]=dict(tn=tn,ksplit=ks,groups=grid,ragged_teams=True)
    propose(dict(family,gemm_overrides=overrides))
   for stage in range(4):
    decoders=('standard',) if stage==1 else ('standard','half','bits','lut','subtract','vector','half_operand')
    for outer,decoder in itertools.product((0,1),decoders):
     if family.get('tk',32)!=32 and decoder=='vector':continue
     overrides=dict(family.get('gemm_overrides',{}))
     overrides[str(stage)]=dict(q_outer=outer,fp8_decode=decoder)
     propose(dict(family,gemm_overrides=overrides))
  configs_path.write_text(json.dumps(proposals,indent=2)+'\n')
  shutil.copyfile(Path.cwd()/'monolith/compiler/static_fusion.py',root/(name+'-compiler.py'))
  print(name,len(proposals),'configurations; serial prerequisite for interactions',flush=True)
  command=[sys.executable,'tools/bench/modelopt_mega_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4',
           '--pack','/tmp/monolith-m5max/target-pack','--kind','gdn-prefix','--configs',str(configs_path),
           '--reference-config',str(root/'baseline.json'),'--reps','5','--steps','16','--out',str(results_path)]
  with (root/(name+'.log')).open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
  family_rows=[json.loads(l) for l in results_path.read_text().splitlines()]
  rows.extend(r for r in family_rows if 'results' in r)
  ordered=sorted(rows,key=ratio)
 # An interrupted prerequisite needs explicit recovery, never silent duplicate
 # samples or an incomplete domain being treated as finished.
 assert len(results_path.read_text().splitlines())==len(read(configs_path.name)), 'incomplete family projection study'
base=read('packing-winner.json')
# Distinct execution geometries survive to refinement, even when an unusually
# good single sample ranks another knob setting ahead of the simple baseline.
seeds=[base]
for groups in (8,4):
 choices=[r for r in ordered if r['config']['sgs']==groups and r['config'].get('fp8_layout')=='tile']
 if choices:seeds.append(choices[0]['config'])
# Carry a materially better new family discovered by the broad occupancy search.
for r in ordered:
 if ratio(r)<ratio(ordered[0])*1.015 and r['config']['sgs'] not in {s['sgs'] for s in seeds}:
  seeds.append(r['config'])
  if len(seeds)>=5:break
out=[];seen=set()
def add(s,**kw):
 c=dict(s,**kw);key=json.dumps(c,sort_keys=True)
 if key not in seen:seen.add(key);out.append(c)
if a.stage=='knobs':
 for s in seeds:
  add(s)
  for w,tn,tk in itertools.product((40,80,120,160),(16,32),(16,32)):
   add(s,workers=w,tn=tn,tk=tk,tm=32)
  for dec,ku,au in itertools.product(('standard','half','bits','lut','subtract','vector','half_operand'),(1,2,4,8),(False,True)):
   if s.get('tk',32)!=32 and dec=='vector':continue
   add(s,fp8_decode=dec,k_unroll=ku,unroll=au)
  for schedule,grain in itertools.product(('stages','interleave','queue'),('group','tile')):
   clean={k:v for k,v in s.items() if k not in ('task_seed','task_batch','task_grain','schedule')}
   for batch,seed in itertools.product((1,2,4,8,16,32),(False,True)) if schedule=='queue' else [(1,False)]:
    add(clean,schedule=schedule,task_grain=grain,task_batch=batch,task_seed=seed)
  for barrier,poll in [('serial',1),('leader',1)]+[('simd',p) for p in (1,2,4,8) if p<=s['sgs']]:
   for stride,arrival in itertools.product((1,2,4,8,16,32,64),('rmw','store','register')):
    add(s,barrier=barrier,poll_sgs=poll,flag_stride=stride,arrival=arrival)
  for scalar,restrict in itertools.product([v for v in (1,2,4,8,16,32) if v<=s['sgs']],(False,True)):
   add(s,scalar_sgs=scalar,restrict_weights=restrict)
  for tp,sl in itertools.product((1,2,4,8),(1,2,4,8,16,32)):
   add(s,gdn_tp=tp,gdn_sl=sl)
  for u,v,fn in itertools.product((0,1,2,4,8),(1,2,4),(False,True)):
   if fn:
    if 128%s['sgs'] or s.get('gdn_global') or s.get('gdn_prepare','local')!='local':continue
    add(s,gdn_unroll=u,gdn_vector=v,gdn_fused_norm=True,gdn_sl=128//s['sgs'])
   elif s.get('gdn_sl',4)%v==0:add(s,gdn_unroll=u,gdn_vector=v,gdn_fused_norm=False)
 # Fill SG4 occupancy coverage missing from the broad SG8/16/32 sweep.
 s=next((s for s in seeds if s['sgs']==4),None)
 if s:
  for w,tn,ks,prep in itertools.product((120,160,192,224,256),(16,32),(1,2,4),('local','global','shared_qk')):
   clean={k:v for k,v in s.items() if k not in ('gdn_prepare','gdn_global','gdn_tp','ksplit')}
   if prep=='local':add(clean,workers=w,tn=tn,ksplit=ks,ragged_teams=True,gdn_tp=2)
   else:add(clean,workers=w,tn=tn,ksplit=ks,ragged_teams=True,gdn_global=prep)
elif a.stage=='workers':
 # Rank again after knob refinement; fine worker sweeps retain the three main
 # competitive geometries. Every integer in each recorded neighbourhood runs.
 selected=[]
 for groups in sorted({s['sgs'] for s in seeds}):
  cs=[r for r in ordered if r['config']['sgs']==groups and r['config'].get('fp8_layout')=='tile']
  if cs:selected.append(cs[0]['config'])
 seeds=selected
 for s in seeds:
  center=s['workers'];lo=max(1,center-32);hi=min(256,center+32)
  for w in range(lo,hi+1):add(s,workers=w)
elif a.stage=='projections':
 # Repeat the per-projection geometry domain after changing the weight layout.
 # The original-layout sweep alone cannot rule out an interaction with packing.
 seeds=[base]
 best=ordered[0]['config']
 if best['sgs']!=base['sgs']:seeds.append(best)
 for s in seeds:
  for stage,tn,ks,groups in itertools.product(range(4),(16,32),[k for k in (1,2,4,8,16,32) if s['sgs']%k==0],(40,80,120,160,240)):
   overrides=dict(s.get('gemm_overrides',{}))
   overrides[str(stage)]=dict(tn=tn,ksplit=ks,groups=groups,ragged_teams=True)
   add(s,gemm_overrides=overrides)
  for stage in range(4):
   modes=('standard',) if stage==1 else ('standard','half','bits','lut','subtract','vector','half_operand')
   for outer,decoder in itertools.product((0,1),modes):
    overrides=dict(s.get('gemm_overrides',{}))
    overrides[str(stage)]=dict(q_outer=outer,fp8_decode=decoder)
    add(s,gemm_overrides=overrides)
else:
 # Interactions are generated only after worker and knob measurements exist.
 # Take the best complete recipes rather than transplanting unrelated winners.
 keys=set();seeds=[]
 for r in ordered:
  s=r['config'];key=json.dumps(s,sort_keys=True)
  if key in keys:continue
  keys.add(key);seeds.append(s)
  if len(seeds)==8:break
 projection_rows=[r for r in ordered if r['config'].get('gemm_overrides') and r['config']['sgs']==base['sgs']]
 overrides={}
 for stage in range(4):
  candidates=[r for r in projection_rows if str(stage) in r['config']['gemm_overrides']]
  if candidates:overrides[str(stage)]=candidates[0]['config']['gemm_overrides'][str(stage)]
 if overrides:add(base,gemm_overrides=overrides)
 for s in seeds:
  add(s)
  for block,restrict in itertools.product((1,8,32,128,256,512),(False,True)):
   add(s,fp8_tile_block=block,restrict_weights=restrict)
  for perm,direct,dual in itertools.product((4,16,64),(False,True),(False,True)):
   add(s,perm_sgs=perm,direct_norm=direct,dual_permute=dual)
 # Test cross-stage combinations around each family's best full recipe.
 # Categories are copied as complete blocks (including recurrence slice/prep),
 # so an absent option restores its default instead of inheriting a stale knob.
 categories=[
  ({'barrier','poll_sgs','flag_stride','arrival'}, {'poll_sgs','flag_stride','arrival'}),
  ({'fp8_decode','q_outer','k_unroll','unroll'}, {'k_unroll','unroll'}),
  ({'gdn_sl','gdn_tp','gdn_unroll','gdn_vector','gdn_fused_norm','gdn_prepare','gdn_global'},
   {'gdn_tp','gdn_unroll','gdn_vector','gdn_fused_norm','gdn_prepare','gdn_global'}),
 ]
 for groups in (16,8,4):
  family=[r for r in ordered if r['config']['sgs']==groups and r['config'].get('fp8_layout')=='tile']
  if not family:continue
  s=family[0]['config'];choices=[]
  stage_choices=[]
  for stage in range(4):
   candidates=[r for r in family if str(stage) in r['config'].get('gemm_overrides',{})]
   if candidates:stage_choices.append((str(stage),candidates[0]['config']['gemm_overrides'][str(stage)]))
  for mask in itertools.product((False,True),repeat=len(stage_choices)):
   overrides=dict(s.get('gemm_overrides',{}))
   for enabled,(stage,override) in zip(mask,stage_choices):
    if enabled:overrides[stage]=override
   if overrides:add(s,gemm_overrides=overrides)
  for fields,trigger in categories:
   blocks=[{k:v for k,v in s.items() if k in fields}]
   candidates=[r for r in family if trigger.intersection(r['config'])]
   if candidates:
    block={k:v for k,v in candidates[0]['config'].items() if k in fields}
    if block not in blocks:blocks.append(block)
   choices.append(blocks)
  for blocks,restrict in itertools.product(itertools.product(*choices),(False,True)):
   c=dict(s)
   for (fields,_),block in zip(categories,blocks):
    for field in fields:c.pop(field,None)
    c.update(block)
   add(c,restrict_weights=restrict)
path=root/('refine-'+a.stage+'-configs.json')
path.write_text(json.dumps(out,indent=2)+'\n')
(root/('refine-'+a.stage+'-seeds.json')).write_text(json.dumps(seeds,indent=2)+'\n')
print(a.stage,len(out),'configurations;',len(seeds),'seeds')
