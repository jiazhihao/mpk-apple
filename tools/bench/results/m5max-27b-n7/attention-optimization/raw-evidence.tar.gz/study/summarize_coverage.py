"""Count actual screened points; do not imply a Cartesian-product search."""
import collections,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
status=json.loads((p/'pipeline-status.json').read_text());assert status['status']=='complete'
phases=[];allrows=[];domains=collections.defaultdict(set)
key=lambda c:json.dumps(c,sort_keys=True)
for name in status['sources']:
 path=p/name;rows=[json.loads(s)for s in path.read_text().splitlines()]
 errors=collections.Counter(r['error'].splitlines()[0]for r in rows if 'error'in r)
 phases.append(dict(file=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),points=len(rows),accepted=sum('results'in r for r in rows),rejected=sum('error'in r for r in rows),configurations=len({key(r['config'])for r in rows}),contexts=sorted({r['ctx']for r in rows if r['ctx']is not None}),errors=dict(errors)))
 allrows+=rows
 for r in rows:
  for k,v in r['config'].items():domains[k].add(json.dumps(v,sort_keys=True))
coverage=dict(scope='Finite adaptive search; full Cartesian product of all knobs was not evaluated.',phases=phases,total_points=len(allrows),accepted=sum('results'in r for r in allrows),rejected=sum('error'in r for r in allrows),unique_configurations=len({key(r['config'])for r in allrows}),explicit_values={k:[json.loads(s)for s in sorted(v)]for k,v in sorted(domains.items())},measurement_exclusions=json.loads((p/'measurement-exclusions.json').read_text()),selection=json.loads((p/'selection-policy.json').read_text()))
final_files=sorted(p.glob('finalists-*-layer*.jsonl'))
if final_files:
 final_rows=[json.loads(s)for f in final_files for s in f.read_text().splitlines()]
 coverage['finalist_confirmation']=dict(points=len(final_rows),accepted=sum('results'in r for r in final_rows),rejected=sum('error'in r for r in final_rows),file_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in final_files})
(p/'coverage.json').write_text(json.dumps(coverage,indent=2))
print({k:v for k,v in coverage.items()if k not in ['phases','explicit_values','measurement_exclusions','selection']})
for r in phases:print(r['file'],r['points'],r['accepted'],r['rejected'])
