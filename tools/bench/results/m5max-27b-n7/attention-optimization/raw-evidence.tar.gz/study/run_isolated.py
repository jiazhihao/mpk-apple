"""Isolated mixer latency at the selected context recipes; no generation."""
import json,subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
selected=json.loads((p/'selected-contexts.json').read_text())
for ctx in [128,4096,8192,16384,32768]:
 cfg=json.loads((p/selected[str(ctx)]).read_text())['attention'];config=p/f'isolated-{ctx}-configs.json';config.write_text(json.dumps([cfg],indent=2))
 for layer in [3,31,63]:
  label=f'isolated-{ctx}-layer{layer}';out=p/(label+'.jsonl')
  if out.exists():raise RuntimeError('refusing duplicate output '+str(out))
  cmd=[sys.executable,str(repo/'tools/bench/modelopt_mega_tune.py'),'--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--kind','attention','--ctx',str(ctx),'--capacity','33024','--layer',str(layer),'--configs',str(config),'--reference-config',str(p/('baseline-short.json'if ctx==128 else'baseline-long.json')),'--reps','9','--steps','32','--out',str(out)]
  with(p/(label+'.log')).open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=repo)
  print(time.strftime('%H:%M:%S'),'completed',label,flush=True)
