from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text().replace('attention_key_tile not in (32,64,128)', 'attention_key_tile not in (16,32,64,128)',1)
s=s.replace("    if attention_style=='staged' and attention_key_tile!=32:\n        raise ValueError('staged attention uses 32-key matrix tiles')", "    if attention_style=='staged' and attention_key_tile not in (16,32):\n        raise ValueError('staged attention uses 16- or 32-key matrix tiles')\n    if attention_style=='cooperative' and attention_key_tile==16:\n        raise ValueError('cooperative attention requires at least 32 keys per partition')")
s=s.replace("    if attention_qm not in (8,16):\n        raise ValueError('attention query tile must be 8 or 16')", "    if attention_qm not in (8,16,32) or (attention_qm==32 and attention_style=='staged' and attention_key_tile!=16):\n        raise ValueError('32 query rows require 16-key staged or cooperative attention')")
s=s.replace('or attention_alias_scratch:\n        from .attention_fusion', 'or attention_alias_scratch or attention_key_tile!=32:\n        from .attention_fusion',1)
p.write_text(s)
p=Path('monolith/compiler/attention_fusion.py');s=p.read_text().replace('def _group_tiles(source):', 'def _group_tiles(source,key_tile=32):',1).replace("source = _replace(source, '#define KN CH', '#define KN 32u')", "source = _replace(source, '#define KN CH', f'#define KN {key_tile}u')",1)
s=s.replace("    body = body.replace('c * KN +', 'key_base +')", "    body = body.replace('c * KN +', 'key_base +')\n    if key_tile==16:\n        body=body.replace('KN / 32','((KN + 31u) / 32u)')\n        body=body.replace('row < rows && key < ctx && key <= position + t ?', 'row < rows && lane + u * 32 < KN && key < ctx && key <= position + t ?')\n        body=body.replace('prob[r * KN + lane + u * 32] = bfloat(pr);', 'if (lane + u * 32 < KN) prob[r * KN + lane + u * 32] = bfloat(pr);')",1)
s=s.replace('        if chunk_tiles > 1:\n            k.source = _group_tiles(k.source)', "        if chunk_tiles > 1 or (style=='staged' and key_tile==16):\n            k.source = _group_tiles(k.source,key_tile)",1)
p.write_text(s)
p=Path('kernels/gqa_decode_cooperative.metal');s=p.read_text().replace('#define CK 32u','#define AQ ((QM < 16) ? 16 : QM)\n#define CK 32u',1).replace('matmul2d_descriptor(16, 32, CK,','matmul2d_descriptor(AQ, 32, CK,').replace('matmul2d_descriptor(16, VN, 32,','matmul2d_descriptor(AQ, VN, 32,');p.write_text(s)
p=Path('tests/kernels/test_attention_static.py');s=p.read_text().replace("chunk=cfg.get('attention_key_tile',32)*cfg.get('attention_chunk_tiles',1)", "chunk=(cfg.get('attention_key_tile',32) if cfg.get('attention_style')=='cooperative' else 32)*cfg.get('attention_chunk_tiles',1)")
s+='''

@pytest.mark.parametrize('style,sgs,keys,tiles',[
    ('staged',4,16,1),('staged',8,16,8),('staged',16,16,32),
    ('cooperative',4,32,1),('cooperative',8,32,1),('cooperative',4,64,1)])
def test_wide_query_attention(attention,style,sgs,keys,tiles):
    test_attention_geometry_preserves_causal_cache_and_replay(
        attention,sgs,32,80,2,4,
        dict(schedule='queue',task_grain='tile',task_batch=1,task_seed=True,task_stats=True),
        dict(attention_prepare=True,attention_style=style,attention_key_tile=keys,attention_chunk_tiles=tiles,
             attention_alias_scratch=style=='staged'))
''';p.write_text(s)
