from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text().replace('attention_cached_prefix=False):','attention_cached_prefix=False, attention_alias_scratch=False):',1)
s=s.replace("    if type(attention_cached_prefix) is not bool", "    if type(attention_alias_scratch) is not bool or (attention_alias_scratch and attention_style!='staged'):\n        raise ValueError('KV/score scratch aliasing requires staged attention')\n    if type(attention_cached_prefix) is not bool",1)
s=s.replace('attention_key_tile=attention_key_tile,attention_cached_prefix=attention_cached_prefix)', 'attention_key_tile=attention_key_tile,attention_cached_prefix=attention_cached_prefix,\n                    attention_alias_scratch=attention_alias_scratch)',1)
s=s.replace('if attention_prepare or attention_chunk_tiles != 1 or attention_cached_prefix:', 'if attention_prepare or attention_chunk_tiles != 1 or attention_cached_prefix or attention_alias_scratch:',1)
s=s.replace('attention_style,attention_key_tile,attention_cached_prefix)', 'attention_style,attention_key_tile,attention_cached_prefix,attention_alias_scratch)',1);p.write_text(s)
p=Path('monolith/compiler/attention_fusion.py');s=p.read_text().replace("key_tile=32, cached_prefix=False):", "key_tile=32, cached_prefix=False, alias_scratch=False):",1)
s=s.replace('        if not prepare:\n', '        if not prepare:\n            if alias_scratch:k.source=_alias_scratch(k.source)\n',1)
s=s.replace('        if cached_prefix:_cache_prefix(p,op,k,True)', '        if alias_scratch:k.source=_alias_scratch(k.source)\n        if cached_prefix:_cache_prefix(p,op,k,True)',1)
s+='''

def _alias_scratch(source):
    """Release staged K after scoring; its storage then holds scores and V.

    The extra threadgroup barrier protects all score readers before V overwrites
    the union. Query rows persist across local partitions in separate storage.
    """
    pattern=r'(?:union|struct) GqaTileScratch \\{ bfloat query\\[QM \\* D\\]; float score\\[QM \\* KN\\]; \\};'
    source,count=re.subn(pattern,
        'struct GqaTileScratch { bfloat query[QM * D]; };\\nunion GqaKVTileScratch { bfloat kv[KN * D]; float score[QM * KN]; };',source)
    if count!=1:raise ValueError('attention scratch declaration changed')
    source=_replace(source,'  threadgroup bfloat kv_tile[KN * D];',
        '  threadgroup GqaKVTileScratch kv_scratch;\\n  threadgroup bfloat* kv_tile=kv_scratch.kv;')
    source=source.replace('scratch.score','kv_scratch.score')
    start=source.rindex('kernel void gqa_decode_mma(')
    value=source.index('      float v[DL];',start)
    at=source.rindex('#if !DIRECT_KV',start,value)
    source=source[:at]+'    threadgroup_barrier(mem_flags::mem_threadgroup);\\n'+source[at:]
    return source
''';p.write_text(s)
p=Path('tests/kernels/test_attention_static.py');s=p.read_text()+'''

@pytest.mark.parametrize('sgs,qm,prepare,tiles',[(4,8,False,1),(4,16,True,16),(8,8,False,8),(8,16,True,32)])
def test_reused_attention_scratch(attention,sgs,qm,prepare,tiles):
    test_attention_geometry_preserves_causal_cache_and_replay(
        attention,sgs,qm,80,2,4,
        dict(schedule='queue',task_grain='tile',task_batch=1,task_seed=True,task_stats=True),
        dict(attention_prepare=prepare,attention_chunk_tiles=tiles,attention_cached_prefix=True,attention_alias_scratch=True))
''';p.write_text(s)
