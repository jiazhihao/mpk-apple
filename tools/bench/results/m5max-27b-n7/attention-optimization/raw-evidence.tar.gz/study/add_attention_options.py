from pathlib import Path
p=Path('monolith/compiler/static_fusion.py')
s=p.read_text().replace("fp8_storage='fp8', tm=16):","fp8_storage='fp8', tm=16, attention_prepare=False, attention_chunk_tiles=1):",1)
s=s.replace("    if attention_qm not in (8,16):", "    if type(attention_prepare) is not bool or type(attention_chunk_tiles) is not int or attention_chunk_tiles not in (1,2,4,8,16,32):\n        raise ValueError('unsupported attention preparation or chunk grouping')\n    if attention_qm not in (8,16):",1)
s=s.replace("fp8_tile_block=fp8_tile_block,fp8_storage=fp8_storage,tm=tm)","fp8_tile_block=fp8_tile_block,fp8_storage=fp8_storage,tm=tm,\n                    attention_prepare=attention_prepare,attention_chunk_tiles=attention_chunk_tiles)",1)
s=s.replace("sgs not in (4,8) or k.macros.get('DIRECT_KV')", "sgs not in (1,2,4,8,16,32) or k.macros.get('DIRECT_KV')",1).replace("requires staged MMA with 4 or 8 SIMD groups", "requires staged MMA with power-of-two SIMD groups",1)
s=s.replace("    return p\n\ndef stage", "    if attention_prepare or attention_chunk_tiles != 1:\n        from .attention_fusion import specialize_attention\n        p=specialize_attention(p,sgs,attention_prepare,attention_chunk_tiles)\n    return p\n\ndef stage",1)
s=s.replace("const uint chunks = (st->position + st->t_this_step + KN - 1u) / KN;", "const uint chunks = (st->position + st->t_this_step + CH - 1u) / CH;",1)
p.write_text(s)
