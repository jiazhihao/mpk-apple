import subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(p/'run_refinement.py'),'q24'],check=True)
subprocess.run([sys.executable,str(p/'next_phases.py')],check=True)
