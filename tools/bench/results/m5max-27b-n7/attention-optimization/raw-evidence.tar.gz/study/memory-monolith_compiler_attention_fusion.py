"""Optional staged attention preparation and locally reduced key partitions.

The matrix tile remains 32 keys wide. Larger partitions combine those tiles in
FP32 before writing one global partial; they do not grow the KV staging buffer.
All cache accesses remain ordinary coherent loads in the fused program.
"""
import copy
import re
import struct

from monolith.runtime.program import BufferSpec, OpSpec
from monolith.kernels import KERNELS_DIR


def _replace(source, old, new):
    if source.count(old) != 1:
        raise ValueError('attention specialization source shape changed: '+old[:60])
    return source.replace(old, new, 1)


def _group_tiles(source,key_tile=32):
    source = _replace(source, '#define KN CH', f'#define KN {key_tile}u')
    source = _replace(source,
        'union GqaTileScratch { bfloat query[QM * D]; float score[QM * KN]; };',
        'struct GqaTileScratch { bfloat query[QM * D]; float score[QM * KN]; };')
    start = source.rindex('kernel void gqa_decode_mma(')
    end = source.index('\n#if DIRECT_KV\n// Prepare', start)
    body = source[start:end]
    body = _replace(body, 'chunks = (ctx + KN - 1u) / KN;', 'chunks = (ctx + CH - 1u) / CH;')
    body = _replace(body, '  threadgroup bfloat prob[QM * KN];',
        '  threadgroup bfloat prob[QM * KN];\n  threadgroup float row_md[QM * 2];\n  threadgroup float carry[QM * 2];')
    begin = '''#if !DIRECT_KV
    for (uint kk = sgi; kk < KN; kk += MMA_SG) {'''
    if body.count(begin)!=2:
        raise ValueError('attention staging loops changed')
    body = body.replace(begin, '''
    matmul2d<value_desc, execution_simdgroups<MMA_SG>> value_op;
    GqaTG vt(kv_tile, dextents<int, 2>(D, KN));
    auto accum = value_op.get_destination_cooperative_tensor<GqaTG, GqaTG, float>();
    for (uint16_t i=0; i<accum.get_capacity(); i++) if (accum.is_valid_element(i)) accum[i]=0.0f;
    for (uint r=sgi; r<QM; r+=MMA_SG) if (lane==0) { row_md[2*r]=-INFINITY; row_md[2*r+1]=0.0f; }
    for (uint sub=0; sub<CH/KN && c*CH+sub*KN<ctx; sub++) {
    const uint key_base=c*CH+sub*KN;
#if !DIRECT_KV
    for (uint kk = sgi; kk < KN; kk += MMA_SG) {''',1)
    body = body.replace('c * KN +', 'key_base +')
    if key_tile==16:
        body=body.replace('KN / 32','((KN + 31u) / 32u)')
        body=body.replace('row < rows && key < ctx && key <= position + t ?', 'row < rows && lane + u * 32 < KN && key < ctx && key <= position + t ?')
        body=body.replace('prob[r * KN + lane + u * 32] = bfloat(pr);', 'if (lane + u * 32 < KN) prob[r * KN + lane + u * 32] = bfloat(pr);')
    begin = body.index('      if (lane == 0 && row < rows) {')
    endmd = body.index('\n    }\n#if !DIRECT_KV', begin)
    body = body[:begin]+'''      if (lane == 0) {
        const float old_m=row_md[2*r], new_m=max(old_m,m);
        const float a=old_m == -INFINITY ? 0.0f : exp(old_m-new_m);
        const float b=m == -INFINITY ? 0.0f : exp(m-new_m);
        row_md[2*r]=new_m;
        row_md[2*r+1]=a*row_md[2*r+1]+b*den;
        carry[2*r]=a; carry[2*r+1]=b;
      }'''+body[endmd:]
    # The value operation and staged view live outside the bounded inner loop.
    body = _replace(body, '    matmul2d<value_desc, execution_simdgroups<MMA_SG>> value_op;\n    GqaTG pt', '    GqaTG pt')
    body = _replace(body, '#else\n    GqaTG vt(kv_tile, dextents<int, 2>(D, KN));\n#endif', '#endif')
    begin = body.index('    for (uint16_t i = 0; i < out.get_capacity(); i++) if (out.is_valid_element(i)) {')
    body = body[:begin]+'''    for (uint16_t i=0; i<out.get_capacity(); i++) if (out.is_valid_element(i)) {
      const uint r=out.get_multidimensional_index(i)[1];
      accum[i]=carry[2*r]*accum[i]+carry[2*r+1]*out[i];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    } // bounded local key partitions
    for (uint16_t i=0; i<accum.get_capacity(); i++) if (accum.is_valid_element(i)) {
      auto idx=accum.get_multidimensional_index(i);
      const uint row=r0+idx[1], dim=idx[0];
      if (row<rows) part_o[((j*p.n_chunks_max+c)*p.rows_max+row)*D+dim]=accum[i];
    }
    for (uint r=sgi; r<QM; r+=MMA_SG) if (lane==0 && r0+r<rows) {
      const uint base=((j*p.n_chunks_max+c)*p.rows_max+r0+r)*2;
      part_md[base]=row_md[2*r]; part_md[base+1]=row_md[2*r+1];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
  }
}
'''
    return source[:start]+body+source[end:]


def specialize_attention(program, sgs, prepare, chunk_tiles, style='staged', key_tile=32, cached_prefix=False, alias_scratch=False):
    p = copy.deepcopy(program)
    cores = [o for o in p.ops if p.kernels[o.kernel].function == 'gqa_decode_mma']
    if not cores:
        return p  # A per-projection override normalizes a one-op program.
    for ordinal, op in enumerate(cores):
        k = p.kernels[op.kernel]
        if (k.macros.get('STEP_STATE') != '1' or k.macros.get('LM_MODE', '0') != '0'
                or k.macros.get('DIRECT_KV', '0') != '0'
                or k.macros.get('ADAPTIVE_CHUNK', '0') != '0'
                or int(k.macros['CH'].rstrip('u')) != 32):
            raise ValueError('attention preparation requires fixed 32-key staged target attention')
        constants={n:'p.'+n.removeprefix('STATIC_GQA_P_').lower() for n in k.macros if n.startswith('STATIC_GQA_P_')}
        for macro,field in constants.items():
            k.source=re.sub(r'\b'+macro+r'\b',field,k.source)
        cb = {slot:(name,off) for slot,name,off in op.bindings}
        if chunk_tiles > 1 or (style=='staged' and key_tile==16):
            k.source = _group_tiles(k.source,key_tile)
            k.macros['CH'] = f'{32*chunk_tiles}u'
            for fold in p.ops:
                fk = p.kernels[fold.kernel]
                if fk.function == 'gqa_merge' and any(n == cb[7][0] for _,n,_ in fold.bindings):
                    fk.macros['CH'] = k.macros['CH']
        if not prepare:
            if alias_scratch:k.source=_alias_scratch(k.source)
            if cached_prefix:_cache_prefix(p,op,k,False)
            for macro,field in constants.items():k.source=re.sub(r'\b'+re.escape(field)+r'\b',macro,k.source)
            continue
        # A separate Q buffer preserves the input projection for fixed replay,
        # the gate consumer, and independent core/merge correctness tests.
        qname = f'{cb[0][0]}.prepared_q{ordinal}'
        p.buffers[qname] = BufferSpec(p.buffers[cb[0][0]].nbytes)
        prep = copy.deepcopy(k)
        prep.function = 'gqa_prepare_mma'
        prep.source = _replace(prep.source, '#if DIRECT_KV\n// Prepare', '#if 1\n// Prepare')
        prep.source = _replace(prep.source, 'kernel void gqa_prepare_mma(device ushort* qkvg',
                             'kernel void gqa_prepare_mma(device const ushort* qkvg')
        prep.source = _replace(prep.source, 'constant GqaParams& p [[buffer(9)]], device const StepState* st [[buffer(15)]],',
            'constant GqaParams& p [[buffer(9)]], device ushort* prepared_q [[buffer(10)]], device const StepState* st [[buffer(15)]],')
        prep.source = _replace(prep.source, 'const uint idx = group * 4 + sg,', f'const uint idx = group * {sgs}u + sg,')
        prep.source = _replace(prep.source, '    device ushort* row = qkvg', '    device const ushort* row = qkvg')
        prep.source = _replace(prep.source, '    store_dl(row, q);',
            '    store_dl(prepared_q + t*p.in_stride+p.q_off+h*D+lane*DL, q);')
        key = op.kernel+f'.prepare{ordinal}'
        p.kernels[key] = prep
        params = p.buffers[cb[9][0]].init
        kv = struct.unpack_from('<I',params,cb[9][1]+4)[0]
        rows = struct.unpack_from('<I',params,cb[9][1]+64)[0]
        bindings = [(slot,*cb[slot]) for slot in (0,1,2,3,4,5,6,9,15)]+[(10,qname,0)]
        p.ops.insert(p.ops.index(op),OpSpec(key,bindings,((rows*kv+sgs-1)//sgs,1,1),(32*sgs,1,1)))
        op.barrier_before = True
        op.bindings = [(slot,qname if slot==0 else n,off) for slot,n,off in op.bindings]
        start = k.source.rindex('kernel void gqa_decode_mma(')
        end = k.source.index('\n#if DIRECT_KV\n// Prepare',start)
        body = k.source[start:end]
        body = _replace(body, '        norm_rope(q, q_norm, cos_t + (position + t) * D, sin_t + (position + t) * D, p.eps, lane);', '')
        a = body.index('      if (key < position) {')
        b = body.index('      for (uint e = 0; e < DL; e++) kv_tile',a)
        body = body[:a]+'''      if (key < ctx) load_dl(k_cache + (key*p.kv_heads+j)*D+lane*DL,k);
'''+body[b:]
        a = body.index('      if (key < position) load_dl(v_cache')
        b = body.index('      for (uint e = 0; e < DL; e++) kv_tile',a)
        body = body[:a]+'''      if (key < ctx) load_dl(v_cache + (key*p.kv_heads+j)*D+lane*DL,v);
'''+body[b:]
        k.source = k.source[:start]+body+k.source[end:]
        if alias_scratch:k.source=_alias_scratch(k.source)
        if cached_prefix:_cache_prefix(p,op,k,True)
        if style=='cooperative':
            qm=int(re.search(r'#define QM (\d+)',k.source)[1])
            k.source=k.source[:k.source.index('// Matrix-accelerator attention:')]+(KERNELS_DIR/'gqa_decode_cooperative.metal').read_text()+'\n#endif\n'
            k.macros.update(CH=f'{key_tile}u',QM=str(qm),ATTENTION_SG=str(sgs),COOPERATIVE_ATTN='1')
            for fold in p.ops:
                fk=p.kernels[fold.kernel]
                if fk.function=='gqa_merge' and any(n==cb[7][0] for _,n,_ in fold.bindings):fk.macros['CH']=k.macros['CH']
        for target in (k,prep):
            for macro,field in constants.items():target.source=re.sub(r'\b'+re.escape(field)+r'\b',macro,target.source)
    return p


def _cache_prefix(program,op,k,prepared):
    """Ordinary reads are confined to the cache range this dispatch never writes.

    Kernel boundaries order earlier appends. This dispatch only writes
    [position, position+T), whose loads continue to use coherent accesses.
    The aliases deliberately carry no restrict qualifier.
    """
    bindings={slot:(n,off)for slot,n,off in op.bindings}
    cache_names={bindings[1][0],bindings[2][0]}
    if any(program.buffers[n].role!='state' for n in cache_names):
        raise ValueError('immutable KV prefixes require dedicated state buffers')
    if any(n in cache_names for slot,n,_ in op.bindings if slot not in (1,2)):
        raise ValueError('KV cache aliases an attention input or workspace')
    for other in program.ops:
        if other is not op and any(n in cache_names for _,n,_ in other.bindings):
            if program.kernels[other.kernel].function!='gqa_prepare_mma':
                raise ValueError('another task can modify the KV prefix')
    source=k.source
    a=source.index('static inline void load_dl(')
    b=source.index('static inline uint pack_bf16x2_bits',a)
    helper=source[a:b].replace('load_dl(', 'prefix_load_dl(',1)
    start=source.rindex('kernel void gqa_decode_mma(')
    end=source.index('\n#if DIRECT_KV\n// Prepare',start)
    body=source[start:end]
    body=_replace(body,'device float* part_o [[buffer(7)]],',
        'device const ushort* prefix_k [[buffer(11)]], device const ushort* prefix_v [[buffer(12)]], device float* part_o [[buffer(7)]],')
    for name in ('k','v'):
        if prepared:
            target=f'      if (key < ctx) load_dl({name}_cache + (key*p.kv_heads+j)*D+lane*DL,{name});'
            new=f'      if (key < position) prefix_load_dl(prefix_{name} + (key*p.kv_heads+j)*D+lane*DL,{name});\n      else if (key < ctx) load_dl({name}_cache + (key*p.kv_heads+j)*D+lane*DL,{name});'
            body=_replace(body,target,new)
        else:
            body=_replace(body,f'load_dl({name}_cache +',f'prefix_load_dl(prefix_{name} +')
    k.source=source[:start]+helper+body+source[end:]
    bindings={slot:(n,off)for slot,n,off in op.bindings}
    op.bindings.extend([(11,*bindings[1]),(12,*bindings[2])])
    k.macros['ATTENTION_CACHED_PREFIX']='1'


def _alias_scratch(source):
    """Release staged K after scoring; its storage then holds scores and V.

    The extra threadgroup barrier protects all score readers before V overwrites
    the union. Query rows persist across local partitions in separate storage.
    """
    pattern=r'(?:union|struct) GqaTileScratch \{ bfloat query\[QM \* D\]; float score\[QM \* KN\]; \};'
    source,count=re.subn(pattern,
        'struct GqaTileScratch { bfloat query[QM * D]; };\nunion GqaKVTileScratch { bfloat kv[KN * D]; float score[QM * KN]; };',source)
    if count!=1:raise ValueError('attention scratch declaration changed')
    source=_replace(source,'  threadgroup bfloat kv_tile[KN * D];',
        '  threadgroup GqaKVTileScratch kv_scratch;\n  threadgroup bfloat* kv_tile=kv_scratch.kv;')
    source=source.replace('scratch.score','kv_scratch.score')
    start=source.rindex('kernel void gqa_decode_mma(')
    value=source.index('      float v[DL];',start)
    at=source.rindex('#if !DIRECT_KV',start,value)
    source=source[:at]+'    threadgroup_barrier(mem_flags::mem_threadgroup);\n'+source[at:]
    return source
