"""Run remaining adaptive searches serially. Invoke only after projection exits."""
import json,subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent
sources=['packing.jsonl','partition.jsonl']+[f'{phase}-refine-{ctx}.jsonl'for phase in ['architecture','memory','projection']for ctx in [128,8192,32768]]
if all((p/f'q24-refine-{ctx}.jsonl').exists()for ctx in [128,8192,32768]):
 sources += [f'q24-refine-{ctx}.jsonl'for ctx in [128,8192,32768]]
def run(args):
 print(time.strftime('%Y-%m-%d %H:%M:%S'), ' '.join(args),flush=True)
 subprocess.run([sys.executable,*args],check=True)
for phase in ['stage','combination','schedule','worker']:
 if phase=='stage':run([str(p/'make_stage_search.py'),'--sources',*sources])
 elif phase=='combination':run([str(p/'make_stage_combinations.py')])
 elif phase=='schedule':run([str(p/'make_refinement.py'),'schedule','--sources',*sources])
 else:run([str(p/'make_worker_search.py'),'--sources',*sources])
 (p/'pipeline-status.json').write_text(json.dumps(dict(phase=phase,status='running',started=time.time(),sources=sources),indent=2))
 run([str(p/'run_refinement.py'),phase,'--reps','5'if phase=='combination'else'3','--steps','16'if phase=='combination'else'8'])
 sources += [f'{phase}-refine-{ctx}.jsonl'for ctx in [128,8192,32768]]
(p/'pipeline-status.json').write_text(json.dumps(dict(phase='screens_complete',status='complete',finished=time.time(),sources=sources),indent=2))
print('All adaptive screens complete.',flush=True)
