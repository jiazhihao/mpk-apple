"""Serial GPU screens with context-specific candidate lists and paired baselines."""
import argparse,json,subprocess,time
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('phase');ap.add_argument('--reps',default='3');ap.add_argument('--steps',default='8');a=ap.parse_args()
root=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
for ctx in (128,8192,32768):
 label=f'{a.phase}-refine-{ctx}'
 out=root/(label+'.jsonl')
 if out.exists():raise RuntimeError('Refusing duplicate results: '+str(out))
 cmd=[str(repo/'.venv/bin/python'),str(repo/'tools/bench/modelopt_mega_tune.py'),
 '--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k',
 '--kind','attention-prefix','--ctx',str(ctx),'--capacity','33024','--configs',str(root/(label+'-configs.json')),
 '--reference-config',str(root/('baseline-short.json'if ctx==128 else 'baseline-long.json')),
 '--reps',a.reps,'--steps',a.steps,'--out',str(out)]
 with (root/(label+'.log')).open('w')as log:subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('completed',label,flush=True)
