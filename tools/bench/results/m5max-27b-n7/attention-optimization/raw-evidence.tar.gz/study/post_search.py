"""Run only after the geometry pipeline exits; GPU work is strictly serial."""
import json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
def run(label,args,shader=False):
 env=dict(os.environ)
 if shader:env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1')
 else:
  env.pop('MTL_SHADER_VALIDATION',None);env.pop('MTL_SHADER_VALIDATION_REPORT_TO_STDERR',None)
 print(time.strftime('%H:%M:%S'),'starting',label,flush=True)
 with(p/(label+'.log')).open('w')as log:subprocess.run([sys.executable,*args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(time.strftime('%H:%M:%S'),'completed',label,flush=True)
status=json.loads((p/'pipeline-status.json').read_text());assert status['status']=='complete'
run('compact-and-range-shader-tests',['-m','pytest','tests/kernels/test_attention_static.py','-k','compact or score_ranges or seeded_queue_exact','-o','addopts=','-q','--junitxml='+str(p/'compact-and-range-shader-tests.xml')],True)
if '--resume-audit' not in sys.argv:
 run('cache-evaluation-audit',[str(p/'cache_evaluation_audit.py')])
else:
 audit=[json.loads(line)for line in(p/'cache-evaluation-audit.jsonl').read_text().splitlines()]
 assert len(audit)==6 and all(r['output_bit_exact']for r in audit)
run('make-compact-search',[str(p/'make_compact_search.py')])
for ctx in [128,8192,32768]:
 configs=json.loads((p/f'compact-refine-{ctx}-configs.json').read_text())
 configs=[c for c in configs if c['attention_compact_partials']]
 cfgpath=p/f'compact-smoke-{ctx}-configs.json';cfgpath.write_text(json.dumps(configs,indent=2));out=p/f'compact-smoke-{ctx}.jsonl'
 if out.exists():raise RuntimeError('refusing duplicate output '+str(out))
 run(f'compact-smoke-{ctx}',[str(repo/'tools/bench/modelopt_mega_tune.py'),'--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--kind','attention-prefix','--ctx',str(ctx),'--capacity','33024','--configs',str(cfgpath),'--reps','1','--steps','1','--out',str(out)],True)
 rows=[json.loads(s)for s in out.read_text().splitlines()]
 assert len(rows)==len(configs)and all('results'in r for r in rows),(ctx,rows)
run('compact-refinement',[str(p/'run_refinement.py'),'compact','--reps','7','--steps','24'])
status['sources'] += [f'compact-refine-{ctx}.jsonl'for ctx in [128,8192,32768]]
(p/'pipeline-status.json').write_text(json.dumps(status,indent=2))
run('make-bridge-search',[str(p/'make_bridge_search.py')])
bridge=p/'bridge.jsonl'
if bridge.exists():raise RuntimeError('refusing duplicate output '+str(bridge))
run('bridge',[str(repo/'tools/bench/modelopt_mega_tune.py'),'--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--kind','attention-prefix','--ctx','4096,16384','--capacity','33024','--configs',str(p/'bridge-configs.json'),'--reference-config',str(p/'baseline-long.json'),'--reps','3','--steps','8','--out',str(bridge)])
status['sources'].append('bridge.jsonl')
(p/'pipeline-status.json').write_text(json.dumps(status,indent=2))
run('make-finalists',[str(p/'make_finalists.py')])
run('finalists',[str(p/'run_finalists.py')])
print('Finalists complete; review before selecting recipes.',flush=True)
