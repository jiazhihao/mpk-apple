"""A/B workspace compaction on the finalists from completed geometry screens."""
import copy,itertools,json
from pathlib import Path
p=Path(__file__).resolve().parent
status=json.loads((p/'pipeline-status.json').read_text());assert status['status']=='complete'
rows=[json.loads(s)for name in status['sources']for s in(p/name).read_text().splitlines()]
key=lambda c:json.dumps(c,sort_keys=True)
bad={key(r['config'])for r in rows if 'error'in r}
rows=[r for r in rows if 'results'in r and key(r['config'])not in bad]
for ctx in [128,8192,32768]:
 rr=[r for r in rows if r['ctx']==ctx];configs={}
 for metric in [lambda r:r['results']['single_kernel']['gpu_us'],lambda r:r['results']['single_kernel']['gpu_us']/r['results']['production']['gpu_us']]:
  unique={}
  for r in sorted(rr,key=metric):unique.setdefault(key(r['config']),r['config'])
  for base in list(unique.values())[:2]:
   for compact,seed_bound in itertools.product([False,True],[False,True]):
    if seed_bound and (base.get('schedule')!='queue' or not base.get('task_seed')):continue
    c=dict(base,attention_compact_partials=compact,task_seed_bound=seed_bound);configs[key(c)]=c
 (p/f'compact-refine-{ctx}-configs.json').write_text(json.dumps(list(configs.values()),indent=2));print(ctx,len(configs))
