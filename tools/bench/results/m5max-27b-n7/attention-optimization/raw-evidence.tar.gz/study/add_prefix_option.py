from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text()
s=s.replace("attention_style='staged', attention_key_tile=32):", "attention_style='staged', attention_key_tile=32, attention_cached_prefix=False):",1)
s=s.replace("    if attention_style not in ('staged','cooperative')", "    if type(attention_cached_prefix) is not bool or (attention_cached_prefix and attention_style!='staged'):\n        raise ValueError('cached prefix reads require staged attention')\n    if attention_style not in ('staged','cooperative')",1)
s=s.replace('attention_style=attention_style,attention_key_tile=attention_key_tile)', 'attention_style=attention_style,attention_key_tile=attention_key_tile,attention_cached_prefix=attention_cached_prefix)',1)
s=s.replace('if attention_prepare or attention_chunk_tiles != 1:', 'if attention_prepare or attention_chunk_tiles != 1 or attention_cached_prefix:',1)
s=s.replace('attention_chunk_tiles,attention_style,attention_key_tile)', 'attention_chunk_tiles,attention_style,attention_key_tile,attention_cached_prefix)',1)
s=s.replace("    src=re.sub(r'\\bdevice\\b','coherent(device) device',src)", '''    prefix_helper=None
    if k.function=='gqa_decode_mma' and k.macros.get('ATTENTION_CACHED_PREFIX')=='1':
        # This helper only reads keys strictly before the current position.
        # No stage in this dispatch writes that range. Tail loads/stores and
        # every cross-task intermediate retain coherent device accesses.
        match=re.search(r'static inline void prefix_load_dl\\(.*?\\n\\}',src,re.S)
        if match is None:raise ValueError('immutable attention prefix helper missing')
        prefix_helper=match[0]
        src=src[:match.start()]+'__READ_ONLY_KV_PREFIX_HELPER__'+src[match.end():]
        immutable=(*immutable,'prefix_k','prefix_v')
    src=re.sub(r'\\bdevice\\b','coherent(device) device',src)
    if prefix_helper is not None:src=src.replace('__READ_ONLY_KV_PREFIX_HELPER__',prefix_helper)''',1)
p.write_text(s)
p=Path('monolith/compiler/attention_fusion.py');s=p.read_text()
s=s.replace("def specialize_attention(program, sgs, prepare, chunk_tiles, style='staged', key_tile=32):", "def specialize_attention(program, sgs, prepare, chunk_tiles, style='staged', key_tile=32, cached_prefix=False):")
s=s.replace('        if not prepare:\n', '        if not prepare:\n            if cached_prefix:_cache_prefix(op,k,False)\n',1)
s=s.replace("        if style=='cooperative':", "        if cached_prefix:_cache_prefix(op,k,True)\n        if style=='cooperative':",1)
s+='''

def _cache_prefix(op,k,prepared):
    """Ordinary reads are confined to the cache range this dispatch never writes.

    Kernel boundaries order earlier appends. This dispatch only writes
    [position, position+T), whose loads continue to use coherent accesses.
    The aliases deliberately carry no restrict qualifier.
    """
    source=k.source
    a=source.index('static inline void load_dl(')
    b=source.index('static inline uint pack_bf16x2_bits',a)
    helper=source[a:b].replace('load_dl(', 'prefix_load_dl(',1)
    start=source.rindex('kernel void gqa_decode_mma(')
    end=source.index('\\n#if DIRECT_KV\\n// Prepare',start)
    body=source[start:end]
    body=_replace(body,'device float* part_o [[buffer(7)]],',
        'device const ushort* prefix_k [[buffer(11)]], device const ushort* prefix_v [[buffer(12)]], device float* part_o [[buffer(7)]],')
    for name in ('k','v'):
        if prepared:
            target=f'      if (key < ctx) load_dl({name}_cache + (key*p.kv_heads+j)*D+lane*DL,{name});'
            new=f'      if (key < position) prefix_load_dl(prefix_{name} + (key*p.kv_heads+j)*D+lane*DL,{name});\\n      else if (key < ctx) load_dl({name}_cache + (key*p.kv_heads+j)*D+lane*DL,{name});'
            body=_replace(body,target,new)
        else:
            body=_replace(body,f'load_dl({name}_cache +',f'prefix_load_dl(prefix_{name} +')
    k.source=source[:start]+helper+body+source[end:]
    bindings={slot:(n,off)for slot,n,off in op.bindings}
    op.bindings.extend([(11,*bindings[1]),(12,*bindings[2])])
    k.macros['ATTENTION_CACHED_PREFIX']='1'
'''
p.write_text(s)
p=Path('tests/kernels/test_attention_static.py');s=p.read_text()+'''

@pytest.mark.parametrize('prepare,tiles',[(False,1),(True,1),(False,8),(True,8)])
def test_attention_readonly_prefix(attention,prepare,tiles):
    test_attention_geometry_preserves_causal_cache_and_replay(
        attention,8,16,80,4,4,
        dict(schedule='queue',task_grain='tile',task_batch=1,task_seed=True,task_stats=True),
        dict(attention_prepare=prepare,attention_chunk_tiles=tiles,attention_cached_prefix=True))
''';p.write_text(s)
