"""Serial repeated finalist comparisons on screening and held-out layers."""
import subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
for ctx in [128,4096,8192,16384,32768]:
 for layer in [3,15,31,63]:
  label=f'finalists-{ctx}-layer{layer}';out=p/(label+'.jsonl')
  if out.exists():raise RuntimeError('refusing duplicate output '+str(out))
  cmd=[sys.executable,str(repo/'tools/bench/modelopt_mega_tune.py'),'--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--kind','attention-prefix','--ctx',str(ctx),'--capacity','33024','--layer',str(layer),'--configs',str(p/f'finalists-{ctx}-configs.json'),'--reference-config',str(p/('baseline-short.json'if ctx==128 else'baseline-long.json')),'--reps','9','--steps','32','--out',str(out)]
  with(p/(label+'.log')).open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=repo)
  print(time.strftime('%H:%M:%S'),'completed',label,flush=True)
