import copy,itertools,json
from pathlib import Path
p=Path(__file__).resolve().parent
files=['packing.jsonl','partition.jsonl']+[f'architecture-refine-{c}.jsonl'for c in (128,8192,32768)]
raw=[json.loads(s)for f in files for s in(p/f).read_text().splitlines()]
bad={json.dumps(r['config'],sort_keys=True)for r in raw if 'error'in r}
rows=[r for r in raw if 'results'in r and json.dumps(r['config'],sort_keys=True)not in bad]
for ctx in (128,8192,32768):
 base=copy.deepcopy(min((r for r in rows if r['ctx']==ctx),key=lambda r:r['results']['single_kernel']['gpu_us']/r['results']['production']['gpu_us'])['config'])
 base.pop('attention_cached_prefix',None)
 out={}
 def add(c):out[json.dumps(c,sort_keys=True)]=c
 add(base)
 for w in (80,100,120,140,160,180,200,240):add(dict(base,workers=w,attention_alias_scratch=True))
 for sg,qm,w,tiles in itertools.product((4,8,16),(8,16,32),(80,160),(4,16)):
  add(dict(base,sgs=sg,scalar_sgs=2,workers=w,attention_qm=qm,attention_key_tile=16,attention_chunk_tiles=tiles,attention_style='staged',attention_prepare=True,attention_alias_scratch=True))
 for w,tiles in itertools.product((40,80),(4,16)):
  add(dict(base,sgs=32,scalar_sgs=2,workers=w,attention_qm=32,attention_key_tile=16,attention_chunk_tiles=tiles,attention_style='staged',attention_prepare=True,attention_alias_scratch=True))
 for sg,key,w in itertools.product((1,2,4,8),(32,64,128),(20,40,60,80)):
  if sg*32*key*2>32000:continue
  add(dict(base,sgs=sg,scalar_sgs=min(sg,2),workers=w,attention_qm=32,attention_key_tile=key,attention_chunk_tiles=1,attention_style='cooperative',attention_prepare=True,attention_alias_scratch=False))
 (p/f'memory-refine-{ctx}-configs.json').write_text(json.dumps(list(out.values()),indent=2));print(ctx,len(out))
