"""Select both absolute/relative leaders; test on held-out contexts and layers."""
import copy,itertools,json,statistics
from pathlib import Path
p=Path(__file__).resolve().parent
status=json.loads((p/'pipeline-status.json').read_text());assert status['status']=='complete'
rows=[json.loads(s) for name in status['sources']for s in(p/name).read_text().splitlines()]
key=lambda c:json.dumps(c,sort_keys=True)
bad={key(r['config'])for r in rows if 'error'in r}
rows=[r for r in rows if 'results'in r and key(r['config'])not in bad]
def absolute(r):return r['results']['single_kernel']['gpu_us']
def ratio(r):return absolute(r)/r['results']['production']['gpu_us']
for ctx,training in [(128,[128]),(4096,[4096]),(8192,[8192]),(16384,[16384]),(32768,[32768])]:
 configs={}
 def add(c):configs.setdefault(key(c),copy.deepcopy(c))
 for source_ctx in training:
  rr=[r for r in rows if r['ctx']==source_ctx]
  for score in [absolute,ratio,lambda r:statistics.median(s['wall_us']for s in r['samples']['single_kernel']),lambda r:max(s['wall_us']for s in r['samples']['single_kernel'])]:
   unique={}
   for r in sorted(rr,key=score):unique.setdefault(key(r['config']),r['config'])
   for c in list(unique.values())[:2]:add(c)
  # Independently optimized multi-dispatch challengers distinguish algorithm
  # improvements from the effect of fusion itself.
  for score in [lambda r:r['results']['matched_control']['gpu_us'],lambda r:r['results']['matched_control']['gpu_us']/r['results']['production']['gpu_us']]:
   add(min(rr,key=score)['config'])
  # Retain the leading alternative SIMD family; it can differ at held-out contexts.
  best=min(rr,key=absolute);alternative=[r for r in rr if r['config']['sgs']!=best['config']['sgs']]
  if alternative:add(min(alternative,key=absolute)['config'])
  # Strip optional scratch/cache tweaks and round workers for an interpretable
  # near-equivalent challenger. It must win the same validation and timing gates.
  simple=copy.deepcopy(best['config'])
  for name in ['attention_alias_scratch','attention_cached_prefix','noinline','restrict_weights','gemm_overrides']:
   if name=='attention_alias_scratch' and simple.get('attention_qm')==24 and simple.get('attention_key_tile',32)==32:continue
   simple.pop(name,None)
  simple['workers']=max(20,round(simple['workers']/20)*20);add(simple)
 # At 32K the 160-worker minimum can hide intermittent long-latency runs.
 # Confirm stable worker-sweep leaders with both optional layout/queue changes.
 if ctx==32768:
  worker_rows=[json.loads(s)for s in(p/'worker-refine-32768.jsonl').read_text().splitlines()]
  worker_rows=[r for r in worker_rows if 'results'in r and key(r['config'])not in bad]
  stable=sorted(worker_rows,key=lambda r:max(s['wall_us']for s in r['samples']['single_kernel']))[:2]
  for r in stable:
   for compact,bound in itertools.product([False,True],[False,True]):add(dict(r['config'],attention_compact_partials=compact,task_seed_bound=bound))
 (p/f'finalists-{ctx}-configs.json').write_text(json.dumps(list(configs.values()),indent=2));print(ctx,len(configs))
