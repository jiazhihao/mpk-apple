"""Choose robust full-layer recipes and deduplicate context configuration files."""
import collections,hashlib,json,math,statistics
from pathlib import Path
p=Path(__file__).resolve().parent;selected={};controls={};rankings={}
key=lambda c:json.dumps(c,sort_keys=True)
def simplicity(c):
 optional=[k for k in c if k not in ['workers','sgs','tn','split','compact','schedule','task_grain','task_batch','task_seed','task_barrier','attention_groups','attention_task_tiles','attention_qm','attention_chunk_tiles','attention_prepare','barrier','fp8_layout','fp8_tile_block','fp8_decode','q_outer','merge_unroll']]
 return (c.get('schedule')!='queue',c['workers']%20!=0,len(c.get('gemm_overrides',{}))*2+len(optional),len(key(c)))
for ctx in [128,4096,8192,16384,32768]:
 rows=[json.loads(s)for layer in [3,15,31,63]for s in(p/f'finalists-{ctx}-layer{layer}.jsonl').read_text().splitlines()]
 bad={key(r['config'])for r in rows if 'error'in r};groups=collections.defaultdict(list)
 for r in rows:
  if 'results'in r and key(r['config'])not in bad:groups[key(r['config'])].append(r)
 candidates=[]
 for k,rr in groups.items():
  if {r['layer']for r in rr}!={3,15,31,63}:continue
  ratios={name:math.exp(sum(math.log(r['results'][name]['wall_us']/r['results']['production']['wall_us'])for r in rr)/len(rr))for name in ['single_kernel','matched_control']}
  paired=[r['samples']['single_kernel'][i]['wall_us']/r['samples']['production'][i]['wall_us']for r in rr for i in range(r['reps'])]
  candidates.append(dict(config=json.loads(k),ratios=ratios,paired_median_ratio=statistics.median(paired),paired_max_ratio=max(paired),every_original_pair=all(v<1 for v in paired),simplicity=simplicity(json.loads(k)),layers=[r['layer']for r in rr],min_wall_us={name:[r['results'][name]['wall_us']for r in rr]for name in ['production','single_kernel','matched_control']}))
 assert candidates,ctx
 candidates.sort(key=lambda r:r['ratios']['single_kernel'])
 eligible=[r for r in candidates if r['every_original_pair']]
 if not eligible:raise RuntimeError(f'No consistent original-Monolith winner at {ctx}; inspect finalists')
 best=min(r['ratios']['single_kernel']for r in eligible)
 # Compare latency consistency within the 3% minimum-time band, then retain
 # the fastest confirmed stable recipe; complexity only breaks an exact tie.
 near=[r for r in eligible if r['ratios']['single_kernel']<=best*1.03]
 best_tail=min(r['paired_max_ratio']for r in near)
 stable=[r for r in near if r['paired_max_ratio']<=best_tail*1.05]
 chosen=min(stable,key=lambda r:(r['ratios']['single_kernel'],r['simplicity']))
 control=min(candidates,key=lambda r:r['ratios']['matched_control'])
 for dest,prefix,row in [(selected,'selected',chosen),(controls,'control',control)]:
  config={k:v for k,v in row['config'].items()if not (v is False and k in ['attention_compact_partials','task_seed_bound','attention_cached_prefix','attention_alias_scratch'])}
  digest=hashlib.sha256(key(config).encode()).hexdigest()[:10];name=f'attention-{digest}.json';(p/name).write_text(json.dumps({'attention':config},indent=2));dest[str(ctx)]=name
 rankings[str(ctx)]=dict(candidates=candidates,selected=chosen,control=control,noise_band=0.03,tail_band=0.05,eligibility='faster than original in every paired confirmation sample')
 print(ctx,'selected ratio',round(chosen['ratios']['single_kernel'],4),'best',round(best,4),selected[str(ctx)])
(p/'selected-contexts.json').write_text(json.dumps(selected,indent=2));(p/'selected-controls.json').write_text(json.dumps(controls,indent=2));(p/'finalists-ranking.json').write_text(json.dumps(rankings,indent=2))
