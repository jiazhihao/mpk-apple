"""Retune partition/worker combinations at the intermediate 4K and 16K tiers."""
import copy,itertools,json
from pathlib import Path
p=Path(__file__).resolve().parent
status=json.loads((p/'pipeline-status.json').read_text());assert status['status']=='complete'
rows=[json.loads(s)for name in status['sources']for s in(p/name).read_text().splitlines()]
key=lambda c:json.dumps(c,sort_keys=True)
bad={key(r['config'])for r in rows if 'error'in r}
rows=[r for r in rows if 'results'in r and key(r['config'])not in bad]
configs={}
for sg,ctx in [(4,128),(8,8192)]:
 base=copy.deepcopy(min((r for r in rows if r['ctx']==ctx and r['config']['sgs']==sg and r['config'].get('attention_style','staged')=='staged' and r['config'].get('attention_key_tile',32)==32),key=lambda r:r['results']['single_kernel']['gpu_us'])['config'])
 for workers,qm,tiles,prepare in itertools.product([80,120,160],[8,16],[4,8,12,16,24,32],[False,True]):
  c=dict(base,workers=workers,attention_qm=qm,attention_chunk_tiles=tiles,attention_prepare=prepare)
  configs[key(c)]=c
# Carry endpoint winners unchanged so a long-context projection recipe can
# compete at 16K even when it differs from the grid's two seed families.
for ctx in [128,8192,32768]:
 rr=[r for r in rows if r['ctx']==ctx]
 for score in [lambda r:r['results']['single_kernel']['gpu_us'],lambda r:r['results']['single_kernel']['gpu_us']/r['results']['production']['gpu_us']]:
  c=copy.deepcopy(min(rr,key=score)['config']);configs[key(c)]=c
(p/'bridge-configs.json').write_text(json.dumps(list(configs.values()),indent=2));print(len(configs),'configs x2 contexts')
