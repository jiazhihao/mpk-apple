"""Archive text evidence and exact source snapshots, never model/pack binaries."""
import datetime,gzip,hashlib,importlib.metadata,json,platform,shutil,subprocess,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
out=repo/'tools/bench/results/m5max-27b-n7/attention-optimization';out.mkdir(parents=True,exist_ok=True)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
previous=json.loads((repo/'tools/bench/results/m5max-27b-n7/gdn-optimization/source-manifest.json').read_text())
sources=set(previous['source_sha256'])|{'monolith/compiler/attention_fusion.py','kernels/gqa_decode_cooperative.metal','kernels/gqa_decode_mma.metal','tests/kernels/test_modelopt_mlx.py','docs/research/m5max-27b-attention-optimization.md','docs/research/m5max-27b-attention-tasks.md','monolith/kernels.py','kernels/gqa_common.metal'}
sources=[name for name in sorted(sources)if (repo/name).exists()]
pack=Path('/tmp/monolith-m5max/attention-tasks/pack-33k')
metadata={name:sha(pack/name)for name in ['manifest.json','autotune.apple-m5-max.json']if(pack/name).exists()}
manifest=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),git_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),branch=subprocess.check_output(['git','branch','--show-current'],cwd=repo,text=True).strip(),checkpoint=previous['checkpoint'],revision=previous['revision'],platform=platform.platform(),python=platform.python_version(),packages={name:importlib.metadata.version(name)for name in ['mlx','mlx-lm','numpy','torch','transformers']},source_sha256={name:sha(repo/name)for name in sources},pack_metadata_sha256=metadata)
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
for name in ['selected-contexts.json','selected-controls.json','all16.csv','all16.summary.json','coverage.json','finalists-ranking.json','final-validation.json','isolated.summary.json','task-audit.summary.json','measurement-exclusions.json','cache-evaluation-audit.jsonl']:
 assert (p/name).exists(),name
 shutil.copy2(p/name,out/name)
for name in set(json.loads((p/'selected-contexts.json').read_text()).values())|set(json.loads((p/'selected-controls.json').read_text()).values()):shutil.copy2(p/name,out/name)
allowed={'.py','.json','.jsonl','.log','.xml','.md','.metal','.txt','.csv'}
archive=out/'raw-evidence.tar.gz'
with archive.open('wb')as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for file in sorted(p.iterdir()):
    if file.is_file()and file.suffix in allowed:tar.add(file,arcname='study/'+file.name)
   for name in sources:tar.add(repo/name,arcname='source/'+name)
   tar.add(out/'source-manifest.json',arcname='source-manifest.json')
(out/'raw-evidence.tar.gz.sha256').write_text(sha(archive)+'  raw-evidence.tar.gz\n')
print(out,archive.stat().st_size,'bytes',len(sources),'source snapshots')
