"""Summarize complete, uninstrumented full-layer confirmations without cherry-picking."""
import csv,json,statistics,math
from pathlib import Path
p=Path(__file__).resolve().parent
contexts=[128,4096,8192,16384,32768];layers=list(range(3,64,4))
summary={};records=[]
for ctx in contexts:
 rows=[json.loads(s)for s in(p/f'all16-{ctx}.jsonl').read_text().splitlines()]
 assert len(rows)==16 and sorted(r['layer']for r in rows)==layers,(ctx,len(rows))
 assert all(r['oracle_pass']and r['checks']['replay_bit_exact']and r['checks']['control_bit_exact']for r in rows),ctx
 assert all(r['n']==7 and r['rows']==8 and r['capacity']==33024 and r['reps']==9 and r['steps']==32 for r in rows)
 names=[n for n in rows[0]['results']if not n.startswith('mlx')]
 times={n:[]for n in names};times['mlx_best']=[]
 ratio_native=[];wins_mlx=0;wins_native=0;minima_native=0;minima_mlx=0
 for r in rows:
  rr=r['results'];refs=[n for n in rr if n.startswith('mlx')];best=min(rr[n]['min_wall_us']for n in refs)
  for n in names:times[n].append(rr[n]['min_wall_us'])
  times['mlx_best'].append(best)
  ratio=rr['megakernel']['min_wall_us']/rr['production']['min_wall_us'];ratio_native.append(ratio)
  minima_native+=ratio<1;minima_mlx+=rr['megakernel']['min_wall_us']<best
  pair_mlx=sum(r['samples']['megakernel'][i]['wall_us']<min(r['samples'][n][i]['wall_us']for n in refs)for i in range(r['reps']))
  pair_native=sum(r['samples']['megakernel'][i]['wall_us']<r['samples']['production'][i]['wall_us']for i in range(r['reps']))
  wins_mlx+=pair_mlx;wins_native+=pair_native
  records.append(dict(ctx=ctx,layer=r['layer'],**{n:rr[n]['min_wall_us']for n in names},mlx_best=best,ratio_native=ratio,ratio_mlx=rr['megakernel']['min_wall_us']/best,pairs_mlx_won=pair_mlx,pairs_native_won=pair_native,pairs=r['reps'],oracle_pass=True))
 summary[str(ctx)]=dict(layers=16,median_min_wall_us={n:statistics.median(v)for n,v in times.items()},median_ratio_native=statistics.median(ratio_native),range_ratio_native=[min(ratio_native),max(ratio_native)],minima_native_won=minima_native,minima_mlx_won=minima_mlx,pairs_native_won=wins_native,pairs_mlx_won=wins_mlx,pairs=144,oracle_pass=True,
  median_ratio_previous=statistics.median(r['results']['megakernel']['min_wall_us']/r['results']['previous_geometry']['min_wall_us']for r in rows),
  median_ratio_matched_control=statistics.median(r['results']['megakernel']['min_wall_us']/r['results']['matched_control']['min_wall_us']for r in rows),
  median_ratio_optimized_control=statistics.median(r['results']['megakernel']['min_wall_us']/r['results'].get('packed_control',r['results']['matched_control'])['min_wall_us']for r in rows))
(p/'all16.summary.json').write_text(json.dumps(summary,indent=2))
with(p/'all16.csv').open('w')as f:
 writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
for ctx,r in summary.items():print(ctx,r['median_min_wall_us'],'ratio native',round(r['median_ratio_native'],4),'MLX pairs',r['pairs_mlx_won'],'/',r['pairs'])
