"""Screen the additional 24-row geometry after shader validation."""
import copy,itertools,json
from pathlib import Path
p=Path(__file__).resolve().parent
rows=[json.loads(s)for phase in ['architecture','memory','projection']for ctx in [128,8192,32768]for s in(p/f'{phase}-refine-{ctx}.jsonl').read_text().splitlines()]
rows=[r for r in rows if 'results'in r]
for ctx in [128,8192,32768]:
 base=copy.deepcopy(min((r for r in rows if r['ctx']==ctx),key=lambda r:r['results']['single_kernel']['gpu_us'])['config'])
 base.pop('gemm_overrides',None);base.pop('ksplit',None);base.pop('scalar_sgs',None)
 configs={}
 for sg,w,tiles in itertools.product([4,8],[40,80,120,160],[8,16,32]):
  c=dict(base,sgs=sg,workers=w,attention_qm=24,attention_alias_scratch=True,attention_prepare=True,attention_chunk_tiles=tiles,scalar_sgs=2)
  configs[json.dumps(c,sort_keys=True)]=c
 for sg,w in [(1,80),(2,80),(16,40),(16,80),(32,40),(32,80)]:
  c=dict(base,sgs=sg,workers=w,attention_qm=24,attention_alias_scratch=True,attention_prepare=True,attention_chunk_tiles=16,scalar_sgs=min(2,sg))
  configs[json.dumps(c,sort_keys=True)]=c
 (p/f'q24-refine-{ctx}-configs.json').write_text(json.dumps(list(configs.values()),indent=2));print(ctx,len(configs))
