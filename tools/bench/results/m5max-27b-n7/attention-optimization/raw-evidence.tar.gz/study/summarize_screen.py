import argparse,json,math,collections
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('files',nargs='+');ap.add_argument('--keep',type=int,default=3);a=ap.parse_args()
rows=[]
for name in a.files:
 p=Path(name);v=[json.loads(s) for s in p.read_text().splitlines()]
 print(p.name,'points',len(v),'accepted',sum('results' in x for x in v),'rejected',sum('error'in x for x in v))
 for msg,n in collections.Counter(x['error'].splitlines()[0][:100] for x in v if 'error'in x).most_common(5):print(' ',n,msg)
 rows.extend(x for x in v if 'results'in x)
for ctx in sorted({x['ctx']for x in rows}):
 v=sorted((x for x in rows if x['ctx']==ctx),key=lambda x:x['results']['single_kernel']['gpu_us']/x['results']['production']['gpu_us'])
 print('context',ctx)
 for x in v[:a.keep]:
  r=x['results']; print(round(r['single_kernel']['gpu_us'],2),'native ratio',round(r['single_kernel']['gpu_us']/r['production']['gpu_us'],4),json.dumps(x['config'],sort_keys=True))
