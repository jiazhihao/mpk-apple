"""Reproducible adaptive domains; consume completed screens, deduplicate recipes."""
import argparse,copy,itertools,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['architecture','projection','schedule']);ap.add_argument('--sources',nargs='+',required=True);ap.add_argument('--cooperative',action='store_true');a=ap.parse_args()
root=Path(__file__).resolve().parent
raw=[json.loads(s) for name in a.sources for s in (root/name).read_text().splitlines()]
bad={json.dumps(r['config'],sort_keys=True) for r in raw if 'error'in r}
rows=[r for r in raw if 'results'in r and json.dumps(r['config'],sort_keys=True) not in bad]
def ratio(r):return r['results']['single_kernel']['gpu_us']/r['results']['production']['gpu_us']
def best(ctx,sg=None):return copy.deepcopy(min((r for r in rows if r['ctx']==ctx and (sg is None or r['config']['sgs']==sg)),key=ratio)['config'])
seeds=[best(ctx) for ctx in (128,8192,32768)]
configs={};targets={};active_contexts=[128,8192,32768]
def add(c):
 key=json.dumps(c,sort_keys=True);configs[key]=c
 targets.setdefault(key,set()).update(active_contexts)
for c in seeds:add(c)
if a.phase=='architecture':
 for ctx,base in zip((128,8192,32768),seeds):
  active_contexts=[ctx]
  for tiles in (1,2,3,4,6,8,12,16,24,32,48,64,128,256,512,1024):add(dict(base,attention_chunk_tiles=tiles))
  for prep,tiles in itertools.product((False,True),(base.get('attention_chunk_tiles',1),8,16,32)):
   add(dict(base,attention_cached_prefix=True,attention_prepare=prep,attention_chunk_tiles=tiles))
  for workers in (100,140,150,170,180,190):add(dict(base,workers=workers))
 active_contexts=[128,8192,32768]
 for sg in (16,32):
  base=best(32768,sg)
  for w,qm,tiles in itertools.product((40,80,120,160),(8,16),(2,8,32,128)):
   add(dict(base,workers=w,attention_qm=qm,attention_prepare=True,attention_chunk_tiles=tiles))
  for w in (20,40,60,80):add(dict(base,workers=w,attention_qm=8,attention_prepare=False,attention_chunk_tiles=1))
 if a.cooperative:
  base=best(32768)
  for sg,qm,key,w in itertools.product((1,2,4,8,16),(8,16),(32,64,128),(40,80,160)):
   if sg*qm*key*2>32000:continue
   c=dict(base,sgs=sg,scalar_sgs=min(sg,2),workers=w,attention_qm=qm,attention_prepare=True,attention_chunk_tiles=1,attention_style='cooperative',attention_key_tile=key)
   c.pop('attention_cached_prefix',None);add(c)
elif a.phase=='projection':
 for ctx,base in zip((128,8192,32768),seeds):
  active_contexts=[ctx]
  for block,q in itertools.product((1,2,4,8,16,32,64,128,256,512),(0,1)):add(dict(base,fp8_tile_block=block,q_outer=q))
  for decoder in ('standard','half','bits','lut','subtract','vector','half_operand'):add(dict(base,fp8_decode=decoder))
  for storage in ('bf16','half'):add(dict(base,fp8_decode='standard',fp8_storage=storage,weight_prefetch=0))
  for prefetch in (1,2,4):add(dict(base,weight_prefetch=prefetch))
  for direct,perm in itertools.product((False,True),(1,2,4,8,16,32,64,128)):add(dict(base,direct_norm=direct,perm_sgs=perm))
  for ks,tn in itertools.product((k for k in (1,2,4,8,16,32) if k<=base['sgs']),(16,32)):
   add(dict(base,ksplit=ks,tn=tn))
  for tm,tk,tn in ((16,16,32),(32,16,16),(32,16,32),(32,32,16),(32,32,32)):
   add(dict(base,tm=tm,tk=tk,tn=tn,weight_prefetch=0))
  for unroll,k_unroll in itertools.product((False,True),(1,2,4,8)):add(dict(base,unroll=unroll,k_unroll=k_unroll))
  for compact,short in itertools.product((False,True),(False,True)):add(dict(base,compact=compact,short_decode=short))
  for layout,q,tn,narrow in itertools.product(('blm',),(0,1),(16,32),(False,True)):
   add(dict(base,fp8_layout=layout,q_outer=q,tn=tn,narrow_weights=narrow,fp8_tile_block=1,weight_prefetch=0))
  if base['sgs']<=8:
   for tk,tn,q in itertools.product((64,128,256),(16,32),(0,1)):
    add(dict(base,mode='staged',staged_tk=tk,tn=tn,q_outer=q,fp8_decode='standard',weight_prefetch=0,tk=32,tm=16))
elif a.phase=='schedule':
 for ctx,base in zip((128,8192,32768),seeds):
  active_contexts=[ctx]
  for scalar,merge,unroll in itertools.product((s for s in (1,2,4,8,16,32) if s<=base['sgs']),(1,2),(1,2,4,8,16,32)):
   add(dict(base,scalar_sgs=scalar,merge_sgs=merge,merge_unroll=unroll))
  for batch,tiles,seed in itertools.product((1,2,4,8,16,32),(1,2,3,4,6,8,12,16,24,32),(False,True)):
   add(dict(base,task_batch=batch,attention_task_tiles=tiles,task_seed=seed))
  for schedule,grain,groups in itertools.product(('stages','interleave','queue'),('group','tile'),(40,80,160,320,640)):
   add(dict(base,schedule=schedule,task_grain=grain,attention_groups=groups,task_seed=base.get('task_seed',False) if schedule=='queue' else False))
  for barrier,task,noinline in itertools.product(('serial','simd','leader'),(False,True),(False,True)):
   add(dict(base,barrier=barrier,task_barrier=task,noinline=noinline,poll_sgs=1))
  for poll,stride,arrival in itertools.product((s for s in (1,2,4,8) if s<=base['sgs']),(1,4,16,64),('rmw','store','register')):
   add(dict(base,poll_sgs=poll,flag_stride=stride,arrival=arrival,barrier='simd'))
  add(dict(base,restrict_weights=True))
out=root/(a.phase+'-refine-configs.json');out.write_text(json.dumps(list(configs.values()),indent=2));print(out,len(configs))
(root/(a.phase+'-refine-seeds.json')).write_text(json.dumps(seeds,indent=2))

for ctx in (128,8192,32768):
 subset=[c for k,c in configs.items() if ctx in targets[k]]
 (root/f'{a.phase}-refine-{ctx}-configs.json').write_text(json.dumps(subset,indent=2))
 print('context',ctx,'configurations',len(subset))
