"""Instrument logical worker assignments; never use these timings as perf evidence."""
import json,os,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
selected=json.loads((p/'selected-contexts.json').read_text())
assert os.environ.get('MTL_SHADER_VALIDATION')=='1'
for ctx in [128,4096,8192,16384,32768]:
 cfg=json.loads((p/selected[str(ctx)]).read_text())['attention']
 if cfg.get('schedule')!='queue':print('no queue instrumentation:',ctx,flush=True);continue
 cfg['task_stats']=True;config=p/f'task-audit-{ctx}-configs.json';config.write_text(json.dumps([cfg],indent=2));out=p/f'task-audit-{ctx}.jsonl'
 if out.exists():raise RuntimeError('refusing duplicate output '+str(out))
 cmd=[sys.executable,str(repo/'tools/bench/modelopt_mega_tune.py'),'--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--kind','attention-prefix','--ctx',str(ctx),'--capacity','33024','--configs',str(config),'--reps','1','--steps','1','--out',str(out)]
 with(p/f'task-audit-{ctx}.log').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=repo)
