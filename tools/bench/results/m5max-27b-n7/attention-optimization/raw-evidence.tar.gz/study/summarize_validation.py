"""Require every final numerical and performance point, and summarize audits."""
import collections,hashlib,json,statistics,xml.etree.ElementTree as ET
from pathlib import Path
p=Path(__file__).resolve().parent;contexts=[128,4096,8192,16384,32768]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
isolated={};audit={};validation={};evidence=[]
for ctx in contexts:
 rows=[]
 for layer in [3,31,63]:
  file=p/f'isolated-{ctx}-layer{layer}.jsonl';rr=[json.loads(s)for s in file.read_text().splitlines()];assert len(rr)==1 and 'results'in rr[0],file
  r=rr[0];assert r['control_bit_exact']and r['replay_bit_exact']and r['check']['cosine']>=.9999 and r['check']['relative_l2']<.005,file
  assert r['dispatches']['single_kernel']==1 and r['reps']==9 and r['steps']==32
  rows+=rr;evidence.append(file)
 isolated[str(ctx)]={'layers':[r['layer']for r in rows],'median_min_wall_us':{n:statistics.median(r['results'][n]['wall_us']for r in rows)for n in rows[0]['results']},'median_ratio_original':statistics.median(r['results']['single_kernel']['wall_us']/r['results']['production']['wall_us']for r in rows),'median_ratio_matched':statistics.median(r['results']['single_kernel']['wall_us']/r['results']['matched_control']['wall_us']for r in rows)}
 file=p/f'task-audit-{ctx}.jsonl';rr=[json.loads(s)for s in file.read_text().splitlines()];assert len(rr)==1 and 'results'in rr[0],file
 r=rr[0];assert r['control_bit_exact']and r['replay_bit_exact'];assert r['task_distribution']
 audit[str(ctx)]=dict(config=r['config'],stages=r['task_distribution'],instrumented=True,scope='Counters cover queued stages; an initial nonqueued norm/permute stage can show zero and still execute.',performance_evidence=False);evidence.append(file)
 file=p/f'all16-{ctx}-shader.jsonl';rr=[json.loads(s)for s in file.read_text().splitlines()];assert len(rr)==16 and all(r['oracle_pass']and r['checks']['replay_bit_exact']and r['checks']['control_bit_exact']for r in rr),file
 validation[str(ctx)]=dict(shader_layers=len(rr),oracle_pass=True,replay_bit_exact=True,control_bit_exact=True);evidence.append(file)
 file=p/f'all16-{ctx}.jsonl';rr=[json.loads(s)for s in file.read_text().splitlines()];assert len(rr)==16 and all(r['oracle_pass']and r['every_pair_vs_mlx_best']['megakernel']for r in rr),file
 validation[str(ctx)].update(performance_layers=16,mlx_pairs_won=144,mlx_pairs=144);evidence.append(file)
xml=p/'shared-shader-regressions.xml';tree=ET.parse(xml);suites=tree.findall('testsuite')
counts={k:sum(int(s.get(k,'0'))for s in suites)for k in ['tests','failures','errors','skipped']};assert counts['tests']>500 and not counts['failures']and not counts['errors'],counts
evidence.append(xml)
(p/'isolated.summary.json').write_text(json.dumps(isolated,indent=2));(p/'task-audit.summary.json').write_text(json.dumps(audit,indent=2));(p/'final-validation.json').write_text(json.dumps(dict(contexts=validation,shared_shader_regressions=counts,evidence_sha256={f.name:sha(f)for f in evidence},instrumented_timings_excluded=True),indent=2))
print(counts)
for ctx,r in isolated.items():print(ctx,r)
