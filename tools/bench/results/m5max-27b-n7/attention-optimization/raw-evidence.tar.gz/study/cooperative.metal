
#include <metal_stdlib>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
namespace s0 {
using namespace metal;
struct StepState {
  uint step;
  uint position;
  uint kv_len;
  uint t_this_step;
  int pending_tokens[8];
  uint rng_lo;
  uint rng_hi;
  int anchor;
  uint gamma;
  int draft_tokens[7];
  float confidence[7];
  uint verify_len;
  uint accepted;
  uint checkpoint_index;
  uint drafter_ctx_len;
  uint done;
  uint error;
  uint ring_head;
  uint ring_tail;
  uint prefill_left;
  uint n_inject;
  uint stop_at;
  uint n_chain;
  uint _pad[2];
};
static inline uint pick_chunk(uint ctx, uint kv_heads, uint rep, uint n_sg, uint n_chunks_max) {
  return 32u;
  const uint n_rg1 = (rep + 16u - 1u) / 16u;
  uint ch = 32u;
  while (ch > 16u) {
    const uint ch2 = ch / 2u, n_half = (ctx + ch2 - 1u) / ch2;
    if (kv_heads * n_rg1 * n_half > n_sg || n_half > n_chunks_max) break;
    ch = ch2;
  }
  return ch;
}
struct GqaParams {
  uint heads; uint kv_heads; uint t_active; uint position;
  uint n_sg; uint q_off; uint gate_off; uint k_off;
  uint v_off; uint in_stride; uint out_stride; uint ctx_max;
  float eps; float scaling; uint has_gate; uint n_chunks_max;
  uint rows_max; uint pad0; uint pad1; uint nominal_sg;
};
static inline float bf16f(ushort u) { return as_type<float>(uint(u) << 16); }
static inline float round_bf16(float v) { uint u = as_type<uint>(v); u += 0x7FFFu + ((u >> 16) & 1u); return as_type<float>(u & 0xFFFF0000u); }
static inline ushort bf16bits(float v) { return ushort(as_type<uint>(round_bf16(v)) >> 16); }
static inline float bf16lo(uint u) { return as_type<float>(u << 16); }
static inline float bf16hi(uint u) { return as_type<float>(u & 0xFFFF0000u); }
static inline void load_dl(coherent(device) device const ushort* p, thread float* f) {
  const uint4 q = *(coherent(device) device const uint4*)p;
  f[0] = bf16lo(q.x); f[1] = bf16hi(q.x); f[2] = bf16lo(q.y); f[3] = bf16hi(q.y);
  f[4] = bf16lo(q.z); f[5] = bf16hi(q.z); f[6] = bf16lo(q.w); f[7] = bf16hi(q.w);
}
static inline uint pack_bf16x2_bits(float lo, float hi) { return uint(bf16bits(lo)) | (uint(bf16bits(hi)) << 16); }
static inline void store_dl(coherent(device) device ushort* p, const thread float* f) {
  *(coherent(device) device uint4*)p = uint4(pack_bf16x2_bits(f[0], f[1]), pack_bf16x2_bits(f[2], f[3]), pack_bf16x2_bits(f[4], f[5]), pack_bf16x2_bits(f[6], f[7]));
}
static inline void copy_dl(coherent(device) device ushort* dst, coherent(device) device const ushort* src) {
  *(coherent(device) device uint4*)dst = *(coherent(device) device const uint4*)src;
}
static inline void load_part(coherent(device) device const float* p, thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) { const float4 q = *(coherent(device) device const float4*)(p + e); f[e] = q.x; f[e + 1] = q.y; f[e + 2] = q.z; f[e + 3] = q.w; }
}
static inline void store_part(coherent(device) device float* p, const thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) *(coherent(device) device float4*)(p + e) = float4(f[e], f[e + 1], f[e + 2], f[e + 3]);
}
static inline void norm_rope(thread float* f, coherent(device) device const float* nw, coherent(device) device const ushort* cos_row, coherent(device) device const ushort* sin_row,
                             float eps, uint lane) {
  float ss = 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) ss = fma(f[e], f[e], ss);
  ss = simd_sum(ss);
  const float rstd = rsqrt(ss / float(256) + eps);
  for (uint e = 0; e < (256 / 32u); e++) f[e] = round_bf16(f[e] * rstd * nw[lane * (256 / 32u) + e]);
  const bool lo = lane < 16u;
  float r[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) {
    const float partner = simd_shuffle_xor(f[e], 16u);
    const float c = bf16f(cos_row[lane * (256 / 32u) + e]), s = bf16f(sin_row[lane * (256 / 32u) + e]);
    const float a = round_bf16(f[e] * c), b = round_bf16(partner * s);
    r[e] = round_bf16(lo ? a - b : a + b);
  }
  for (uint e = 0; e < (256 / 32u); e++) f[e] = r[e];
}
static inline uint chunk_of(uint ctx, uint kv, uint n_tg) {
  uint ch = 32u;
  if (kv * ((ctx + 12u * 64u - 1u) / (12u * 64u)) >= n_tg) ch = 64u;
  if (kv * ((ctx + 12u * 128u - 1u) / (12u * 128u)) >= n_tg) ch = 128u;
  return ch;
}


using namespace mpp::tensor_ops;
using GqaTG = tensor<threadgroup bfloat, dextents<int, 2>, tensor_inline>;
using GqaFloatTG = tensor<threadgroup float, dextents<int, 2>, tensor_inline>;
constexpr constant auto score_desc = matmul2d_descriptor(16, 32u, 256, false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
constexpr constant auto value_desc = matmul2d_descriptor(16, 256, 32u, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);
union GqaTileScratch { bfloat query[16 * 256]; float score[16 * 32u]; };



struct Scratch { uint unused; };
static inline void task(coherent(device) device const ushort* qkvg,coherent(device) device ushort* k_cache,coherent(device) device ushort* v_cache,device const ushort* cos_t,device const ushort* sin_t,device const float* q_norm,device const float* k_norm,constant GqaParams& p,coherent(device) device ushort* prepared_q,coherent(device) device const StepState* st,uint group,uint lane,uint sg, threadgroup Scratch& sm) {

  if (st->done) return;
  const uint idx = group * 4u + sg, T = st->t_this_step, position = st->position;
  if (idx < T * 12u) {
    const uint t = idx / 12u, h = idx % 12u;
    float q[(256 / 32u)];
    coherent(device) device const ushort* row = qkvg + t * 7168u + 0u + h * 256 + lane * (256 / 32u);
    load_dl(row, q);
    norm_rope(q, q_norm, cos_t + (position + t) * 256, sin_t + (position + t) * 256, 9.999999974752427e-07f, lane);
    store_dl(prepared_q + t*7168u +0u +h*256 +lane*(256 / 32u), q);
  }
  if (idx < T * 2u) {
    const uint t = idx / 2u, h = idx % 2u;
    float k[(256 / 32u)];
    load_dl(qkvg + t * 7168u + 3072u + h * 256 + lane * (256 / 32u), k);
    norm_rope(k, k_norm, cos_t + (position + t) * 256, sin_t + (position + t) * 256, 9.999999974752427e-07f, lane);
    store_dl(k_cache + ((position + t) * 2u + h) * 256 + lane * (256 / 32u), k);
    copy_dl(v_cache + ((position + t) * 2u + h) * 256 + lane * (256 / 32u),
            qkvg + t * 7168u + 3584u + h * 256 + lane * (256 / 32u));
  }

}

}
namespace s1 {
using namespace metal;
struct StepState {
  uint step;
  uint position;
  uint kv_len;
  uint t_this_step;
  int pending_tokens[8];
  uint rng_lo;
  uint rng_hi;
  int anchor;
  uint gamma;
  int draft_tokens[7];
  float confidence[7];
  uint verify_len;
  uint accepted;
  uint checkpoint_index;
  uint drafter_ctx_len;
  uint done;
  uint error;
  uint ring_head;
  uint ring_tail;
  uint prefill_left;
  uint n_inject;
  uint stop_at;
  uint n_chain;
  uint _pad[2];
};
static inline uint pick_chunk(uint ctx, uint kv_heads, uint rep, uint n_sg, uint n_chunks_max) {
  return 64u;
  const uint n_rg1 = (rep + 16u - 1u) / 16u;
  uint ch = 64u;
  while (ch > 16u) {
    const uint ch2 = ch / 2u, n_half = (ctx + ch2 - 1u) / ch2;
    if (kv_heads * n_rg1 * n_half > n_sg || n_half > n_chunks_max) break;
    ch = ch2;
  }
  return ch;
}
struct GqaParams {
  uint heads; uint kv_heads; uint t_active; uint position;
  uint n_sg; uint q_off; uint gate_off; uint k_off;
  uint v_off; uint in_stride; uint out_stride; uint ctx_max;
  float eps; float scaling; uint has_gate; uint n_chunks_max;
  uint rows_max; uint pad0; uint pad1; uint nominal_sg;
};
static inline float bf16f(ushort u) { return as_type<float>(uint(u) << 16); }
static inline float round_bf16(float v) { uint u = as_type<uint>(v); u += 0x7FFFu + ((u >> 16) & 1u); return as_type<float>(u & 0xFFFF0000u); }
static inline ushort bf16bits(float v) { return ushort(as_type<uint>(round_bf16(v)) >> 16); }
static inline float bf16lo(uint u) { return as_type<float>(u << 16); }
static inline float bf16hi(uint u) { return as_type<float>(u & 0xFFFF0000u); }
static inline void load_dl(coherent(device) device const ushort* p, thread float* f) {
  const uint4 q = *(coherent(device) device const uint4*)p;
  f[0] = bf16lo(q.x); f[1] = bf16hi(q.x); f[2] = bf16lo(q.y); f[3] = bf16hi(q.y);
  f[4] = bf16lo(q.z); f[5] = bf16hi(q.z); f[6] = bf16lo(q.w); f[7] = bf16hi(q.w);
}
static inline uint pack_bf16x2_bits(float lo, float hi) { return uint(bf16bits(lo)) | (uint(bf16bits(hi)) << 16); }
static inline void store_dl(coherent(device) device ushort* p, const thread float* f) {
  *(coherent(device) device uint4*)p = uint4(pack_bf16x2_bits(f[0], f[1]), pack_bf16x2_bits(f[2], f[3]), pack_bf16x2_bits(f[4], f[5]), pack_bf16x2_bits(f[6], f[7]));
}
static inline void copy_dl(coherent(device) device ushort* dst, coherent(device) device const ushort* src) {
  *(coherent(device) device uint4*)dst = *(coherent(device) device const uint4*)src;
}
static inline void load_part(coherent(device) device const float* p, thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) { const float4 q = *(coherent(device) device const float4*)(p + e); f[e] = q.x; f[e + 1] = q.y; f[e + 2] = q.z; f[e + 3] = q.w; }
}
static inline void store_part(coherent(device) device float* p, const thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) *(coherent(device) device float4*)(p + e) = float4(f[e], f[e + 1], f[e + 2], f[e + 3]);
}
static inline void norm_rope(thread float* f, coherent(device) device const float* nw, coherent(device) device const ushort* cos_row, coherent(device) device const ushort* sin_row,
                             float eps, uint lane) {
  float ss = 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) ss = fma(f[e], f[e], ss);
  ss = simd_sum(ss);
  const float rstd = rsqrt(ss / float(256) + eps);
  for (uint e = 0; e < (256 / 32u); e++) f[e] = round_bf16(f[e] * rstd * nw[lane * (256 / 32u) + e]);
  const bool lo = lane < 16u;
  float r[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) {
    const float partner = simd_shuffle_xor(f[e], 16u);
    const float c = bf16f(cos_row[lane * (256 / 32u) + e]), s = bf16f(sin_row[lane * (256 / 32u) + e]);
    const float a = round_bf16(f[e] * c), b = round_bf16(partner * s);
    r[e] = round_bf16(lo ? a - b : a + b);
  }
  for (uint e = 0; e < (256 / 32u); e++) f[e] = r[e];
}
static inline uint chunk_of(uint ctx, uint kv, uint n_tg) {
  uint ch = 32u;
  if (kv * ((ctx + 12u * 64u - 1u) / (12u * 64u)) >= n_tg) ch = 64u;
  if (kv * ((ctx + 12u * 128u - 1u) / (12u * 128u)) >= n_tg) ch = 128u;
  return ch;
}


using namespace mpp::tensor_ops;
constexpr constant auto score_desc = matmul2d_descriptor(16, 64u, 32u, false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
constexpr constant auto value_desc = matmul2d_descriptor(16, 64u, 64u, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);
static inline uint tiles_per_task(uint blocks) {
  return min(1u, max(1u, blocks / 16u));
}

static inline uint task_count(constant GqaParams& p, coherent(device) device const StepState* st) {
  if (st->done || st->t_this_step == 0u) return 0u;
  const uint rows = st->t_this_step * (p.heads / p.kv_heads);
  const uint chunks = (st->position + st->t_this_step + 64u - 1u) / 64u;
  const uint blocks = (p.kv_heads * chunks * ((rows + 16 - 1u) / 16) + 4 - 1u) / 4;
  const uint tiles = tiles_per_task(blocks);
  return (blocks + tiles - 1u) / tiles;
}

struct Scratch { float score_memory[4 * 16 * 64u]; };
static inline void task(coherent(device) device const ushort* qkvg,coherent(device) device ushort* k_cache,coherent(device) device ushort* v_cache,device const ushort* cos_t,device const ushort* sin_t,device const float* q_norm,device const float* k_norm,coherent(device) device float* part_o,coherent(device) device float* part_md,constant GqaParams& p,coherent(device) device const StepState* st,uint tgid,uint lane,uint sgi, threadgroup Scratch& sm) {

  
  if (st->done || st->t_this_step==0u) return;
  const uint T=st->t_this_step, position=st->position, ctx=position+T;
  const uint rep=12u/2u, rows=T*rep, chunks=(ctx+64u -1u)/64u;
  const uint groups=(rows+16 -1u)/16;
  const uint blocks=2u*chunks*groups, jobs=(blocks+4 -1u)/4;
  threadgroup float* score=sm.score_memory+sgi*16*64u;
  threadgroup bfloat* prob=reinterpret_cast<threadgroup bfloat*>(score);
  const uint task_tiles=tiles_per_task(jobs);
  for (uint block = tgid*task_tiles; block < min(jobs, (tgid+1u)*task_tiles); block++) {
    const uint tile=block*4 +sgi;
    if (tile>=blocks) continue;
    const uint j=tile/(chunks*groups), c=(tile/groups)%chunks, r0=(tile%groups)*16;
    matmul2d<score_desc,execution_simdgroup> score_op;
    auto q=score_op.get_left_input_cooperative_tensor<bfloat,bfloat,float>();
    auto k=score_op.get_right_input_cooperative_tensor<bfloat,bfloat,float>();
    auto sc=score_op.get_destination_cooperative_tensor<decltype(q),decltype(k),float>();
    for (uint16_t i=0;i<sc.get_capacity();i++) if(sc.is_valid_element(i)) sc[i]=0.0f;
    for (uint dk=0;dk<256;dk+=32u) {
      for (uint16_t i=0;i<q.get_capacity();i++) if(q.is_valid_element(i)) {
        auto x=q.get_multidimensional_index(i);
        const uint row=r0+x[1], t=row/rep, h=j*rep+row%rep;
        q[i]=row<rows ? bfloat(bf16f(qkvg[t*7168u +0u +h*256 +dk+x[0]])) : bfloat(0);
      }
      for (uint16_t i=0;i<k.get_capacity();i++) if(k.is_valid_element(i)) {
        auto x=k.get_multidimensional_index(i);
        const uint key=c*64u +x[1];
        k[i]=key<ctx ? bfloat(bf16f(k_cache[(key*2u +j)*256 +dk+x[0]])) : bfloat(0);
      }
      score_op.run(q,k,sc);
    }
    for (uint16_t i=0;i<sc.get_capacity();i++) if(sc.is_valid_element(i)) {
      auto x=sc.get_multidimensional_index(i); score[x[1]*64u +x[0]]=sc[i];
    }
    simdgroup_barrier(mem_flags::mem_threadgroup);
    for (uint r=0;r<16;r++) {
      const uint row=r0+r, t=row/rep;
      float values[64u/32];
      float m=-INFINITY;
      for(uint u=0;u<64u/32;u++) {
        const uint key=c*64u +lane+u*32;
        values[u]=row<rows && key<ctx && key<=position+t ? round_bf16(round_bf16(score[r*64u +lane+u*32])*0.0625f) : -INFINITY;
        m=max(m,values[u]);
      }
      m=simd_max(m); float den=0;
      simdgroup_barrier(mem_flags::mem_threadgroup);
      for(uint u=0;u<64u/32;u++) {
        const float v=values[u]==-INFINITY ? 0.0f : exp(values[u]-m);
        prob[r*64u +lane+u*32]=bfloat(v); den+=v;
      }
      den=simd_sum(den);
      if(lane==0 && row<rows) {
        const uint base=((j*1032u +c)*48u +row)*2;
        part_md[base]=m; part_md[base+1]=den;
      }
      simdgroup_barrier(mem_flags::mem_threadgroup);
    }
    matmul2d<value_desc,execution_simdgroup> value_op;
    auto pr=value_op.get_left_input_cooperative_tensor<bfloat,bfloat,float>();
    auto v=value_op.get_right_input_cooperative_tensor<bfloat,bfloat,float>();
    auto out=value_op.get_destination_cooperative_tensor<decltype(pr),decltype(v),float>();
    for(uint16_t i=0;i<pr.get_capacity();i++) if(pr.is_valid_element(i)) {
      auto x=pr.get_multidimensional_index(i); pr[i]=prob[x[1]*64u +x[0]];
    }
    for(uint d0=0;d0<256;d0+=64u) {
      for(uint16_t i=0;i<v.get_capacity();i++) if(v.is_valid_element(i)) {
        auto x=v.get_multidimensional_index(i); const uint key=c*64u +x[1];
        v[i]=key<ctx && d0+x[0]<256 ? bfloat(bf16f(v_cache[(key*2u +j)*256 +d0+x[0]])) : bfloat(0);
      }
      for(uint16_t i=0;i<out.get_capacity();i++) if(out.is_valid_element(i)) out[i]=0.0f;
      value_op.run(pr,v,out);
      for(uint16_t i=0;i<out.get_capacity();i++) if(out.is_valid_element(i)) {
        auto x=out.get_multidimensional_index(i);const uint row=r0+x[1],dim=d0+x[0];
        if(row<rows && dim<256) part_o[((j*1032u +c)*48u +row)*256 +dim]=out[i];
      }
    }
    simdgroup_barrier(mem_flags::mem_threadgroup);
  }

}

}
namespace s2 {
using namespace metal;
struct StepState {
  uint step;
  uint position;
  uint kv_len;
  uint t_this_step;
  int pending_tokens[8];
  uint rng_lo;
  uint rng_hi;
  int anchor;
  uint gamma;
  int draft_tokens[7];
  float confidence[7];
  uint verify_len;
  uint accepted;
  uint checkpoint_index;
  uint drafter_ctx_len;
  uint done;
  uint error;
  uint ring_head;
  uint ring_tail;
  uint prefill_left;
  uint n_inject;
  uint stop_at;
  uint n_chain;
  uint _pad[2];
};
static inline uint pick_chunk(uint ctx, uint kv_heads, uint rep, uint n_sg, uint n_chunks_max) {
  return 64u;
  const uint n_rg1 = (rep + 16u - 1u) / 16u;
  uint ch = 64u;
  while (ch > 16u) {
    const uint ch2 = ch / 2u, n_half = (ctx + ch2 - 1u) / ch2;
    if (kv_heads * n_rg1 * n_half > n_sg || n_half > n_chunks_max) break;
    ch = ch2;
  }
  return ch;
}
struct GqaParams {
  uint heads; uint kv_heads; uint t_active; uint position;
  uint n_sg; uint q_off; uint gate_off; uint k_off;
  uint v_off; uint in_stride; uint out_stride; uint ctx_max;
  float eps; float scaling; uint has_gate; uint n_chunks_max;
  uint rows_max; uint pad0; uint pad1; uint nominal_sg;
};
static inline float bf16f(ushort u) { return as_type<float>(uint(u) << 16); }
static inline float round_bf16(float v) { uint u = as_type<uint>(v); u += 0x7FFFu + ((u >> 16) & 1u); return as_type<float>(u & 0xFFFF0000u); }
static inline ushort bf16bits(float v) { return ushort(as_type<uint>(round_bf16(v)) >> 16); }
static inline float bf16lo(uint u) { return as_type<float>(u << 16); }
static inline float bf16hi(uint u) { return as_type<float>(u & 0xFFFF0000u); }
static inline void load_dl(coherent(device) device const ushort* p, thread float* f) {
  const uint4 q = *(coherent(device) device const uint4*)p;
  f[0] = bf16lo(q.x); f[1] = bf16hi(q.x); f[2] = bf16lo(q.y); f[3] = bf16hi(q.y);
  f[4] = bf16lo(q.z); f[5] = bf16hi(q.z); f[6] = bf16lo(q.w); f[7] = bf16hi(q.w);
}
static inline uint pack_bf16x2_bits(float lo, float hi) { return uint(bf16bits(lo)) | (uint(bf16bits(hi)) << 16); }
static inline void store_dl(coherent(device) device ushort* p, const thread float* f) {
  *(coherent(device) device uint4*)p = uint4(pack_bf16x2_bits(f[0], f[1]), pack_bf16x2_bits(f[2], f[3]), pack_bf16x2_bits(f[4], f[5]), pack_bf16x2_bits(f[6], f[7]));
}
static inline void copy_dl(coherent(device) device ushort* dst, coherent(device) device const ushort* src) {
  *(coherent(device) device uint4*)dst = *(coherent(device) device const uint4*)src;
}
static inline void load_part(coherent(device) device const float* p, thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) { const float4 q = *(coherent(device) device const float4*)(p + e); f[e] = q.x; f[e + 1] = q.y; f[e + 2] = q.z; f[e + 3] = q.w; }
}
static inline void store_part(coherent(device) device float* p, const thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) *(coherent(device) device float4*)(p + e) = float4(f[e], f[e + 1], f[e + 2], f[e + 3]);
}
static inline void norm_rope(thread float* f, coherent(device) device const float* nw, coherent(device) device const ushort* cos_row, coherent(device) device const ushort* sin_row,
                             float eps, uint lane) {
  float ss = 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) ss = fma(f[e], f[e], ss);
  ss = simd_sum(ss);
  const float rstd = rsqrt(ss / float(256) + eps);
  for (uint e = 0; e < (256 / 32u); e++) f[e] = round_bf16(f[e] * rstd * nw[lane * (256 / 32u) + e]);
  const bool lo = lane < 16u;
  float r[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) {
    const float partner = simd_shuffle_xor(f[e], 16u);
    const float c = bf16f(cos_row[lane * (256 / 32u) + e]), s = bf16f(sin_row[lane * (256 / 32u) + e]);
    const float a = round_bf16(f[e] * c), b = round_bf16(partner * s);
    r[e] = round_bf16(lo ? a - b : a + b);
  }
  for (uint e = 0; e < (256 / 32u); e++) f[e] = r[e];
}
static inline uint chunk_of(uint ctx, uint kv, uint n_tg) {
  uint ch = 32u;
  if (kv * ((ctx + 12u * 64u - 1u) / (12u * 64u)) >= n_tg) ch = 64u;
  if (kv * ((ctx + 12u * 128u - 1u) / (12u * 128u)) >= n_tg) ch = 128u;
  return ch;
}


using namespace mpp::tensor_ops;
using GqaTG = tensor<threadgroup bfloat, dextents<int, 2>, tensor_inline>;
using GqaFloatTG = tensor<threadgroup float, dextents<int, 2>, tensor_inline>;
constexpr constant auto score_desc = matmul2d_descriptor(16, 64u, 256, false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
constexpr constant auto value_desc = matmul2d_descriptor(16, 256, 64u, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);
union GqaTileScratch { bfloat query[16 * 256]; float score[16 * 64u]; };


struct Scratch { uint unused; };
static inline void task(coherent(device) device const float* part_o,coherent(device) device const float* part_md,coherent(device) device const ushort* qkvg,coherent(device) device ushort* out,constant GqaParams& p,coherent(device) device const StepState* st,uint gid,uint lane,uint sw, threadgroup Scratch& sm) {

  const uint sg = gid / sw;
  const uint t = sg / 12u, h = sg % 12u;
  if (st->done) return;
  const uint T = st->t_this_step, ctx = st->position + T;
  if (t >= T) return;
  const uint rep = 12u / 2u;
  const uint j = h / rep, row = t * rep + (h % rep);
  const uint ch = pick_chunk(ctx, 2u, rep, 80u, 1032u);
  const uint n_chunks = (ctx + ch - 1u) / ch;
  float m_g = -INFINITY;
  for (uint c = 0; c < n_chunks; c++) m_g = max(m_g, part_md[((j * 1032u + c) * 48u + row) * 2u]);
  float d_g = 0.0f, o[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) o[e] = 0.0f;
  for (uint c0 = 0; c0 < n_chunks; c0 += 4u) {
    float m_c[4u], d_c[4u], oc[4u][(256 / 32u)];
    for (uint u = 0; u < 4u; u++) {
      const uint base = (j * 1032u + min(c0 + u, n_chunks - 1u)) * 48u + row;
      m_c[u] = part_md[base * 2u]; d_c[u] = part_md[base * 2u + 1u];
      load_part(part_o + base * 256 + lane * (256 / 32u), oc[u]);
    }
    for (uint u = 0; u < 4u; u++) {
      if (c0 + u >= n_chunks) break;
      const bool live = m_c[u] != -INFINITY;
      const float w = live ? exp(m_c[u] - m_g) : 0.0f;
      d_g = live ? fma(d_c[u], w, d_g) : d_g;
      for (uint e = 0; e < (256 / 32u); e++) o[e] = live ? fma(w, oc[u][e], o[e]) : o[e];
    }
  }
  const float inv = d_g > 0.0f ? 1.0f / d_g : 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) {
    float y = round_bf16(o[e] * inv);
    if (1u) {
      const float g = bf16f(qkvg[t * 7168u + 4096u + h * 256 + lane * (256 / 32u) + e]);
      y = round_bf16(y * round_bf16(1.0f / (1.0f + exp(-g))));
    }
    out[t * 3072u + h * 256 + lane * (256 / 32u) + e] = bf16bits(y);
  }

}

}

#define WORKERS 8u
// Bounded, coherent all-worker barrier. One SIMD group polls the arrival flags
// in parallel; all threads still publish/observe through device-scope fences.
static inline bool stage_barrier(coherent(device) device atomic_uint* flags,
                                 uint worker, uint tid, threadgroup uint& ok) {
  atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst, thread_scope_device);
  threadgroup_barrier(mem_flags::mem_device | mem_flags::mem_threadgroup);
  if (tid == 0)
    ok = atomic_fetch_add_explicit(flags + worker, 1u, memory_order_relaxed) + 1u;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if (tid < 32u) {
    const uint epoch = ok;
    bool success = true;
    for (uint i = tid; i < WORKERS; i += 32u) {
      uint spins = 0;
      while (atomic_load_explicit(flags + i, memory_order_relaxed) < epoch) {
        if (++spins == 1000000u) { success = false; break; }
      }
    }
    success = simd_all(success);
    if (tid == 0) {
      ok = uint(success);
      if (!success) atomic_store_explicit(flags + WORKERS, 1u, memory_order_relaxed);
    }
  }
  threadgroup_barrier(mem_flags::mem_device | mem_flags::mem_threadgroup);
  atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst, thread_scope_device);
  return ok != 0;
}

kernel void full_gdn(coherent(device) device uchar* b0 [[buffer(0)]],coherent(device) device uchar* b1 [[buffer(1)]],coherent(device) device uchar* b2 [[buffer(2)]],device uchar* b3 [[buffer(3)]],device uchar* b4 [[buffer(4)]],device uchar* b5 [[buffer(5)]],device uchar* b6 [[buffer(6)]],constant uchar* b7 [[buffer(7)]],coherent(device) device uchar* b8 [[buffer(8)]],coherent(device) device uchar* b9 [[buffer(9)]],coherent(device) device uchar* b10 [[buffer(10)]],coherent(device) device uchar* b11 [[buffer(11)]],coherent(device) device uchar* b12 [[buffer(12)]],coherent(device) device atomic_uint* flags [[buffer(13)]],uint tid [[thread_index_in_threadgroup]],uint worker [[threadgroup_position_in_grid]],coherent(device) device atomic_uint* task_queue [[buffer(14)]]) {

threadgroup uchar scratch[((((sizeof(s0::Scratch))>(sizeof(s1::Scratch))?(sizeof(s0::Scratch)):(sizeof(s1::Scratch))))>(sizeof(s2::Scratch))?(((sizeof(s0::Scratch))>(sizeof(s1::Scratch))?(sizeof(s0::Scratch)):(sizeof(s1::Scratch)))):(sizeof(s2::Scratch)))];
threadgroup uint& ok=*((threadgroup uint*)scratch);
threadgroup uint queue_job;
if(worker==0u && tid==0u) {
atomic_store_explicit(task_queue+0u,0u,memory_order_relaxed);
atomic_store_explicit(task_queue+1u,0u,memory_order_relaxed);
atomic_store_explicit(task_queue+2u,0u,memory_order_relaxed);
}
{
if (!stage_barrier(flags, worker, tid, ok)) return;
const uint count0=24u; uint done0=0u;
const uint total=count0;
for(uint claim=0;claim<(total+0u)/1u;claim++) {
if(tid==0u) queue_job=atomic_fetch_add_explicit(task_queue+0u,1u,memory_order_relaxed);
threadgroup_barrier(mem_flags::mem_threadgroup);
const uint first=queue_job;
if(first>=total) break;
for(uint job=first;job<min(first+1u,total);job++) {
const uint kind=0u, task_id=job;
switch(kind) {
case 0u: { using namespace s0; s0::task((coherent(device) device const ushort*)(b0+0ul),(coherent(device) device ushort*)(b1+0ul),(coherent(device) device ushort*)(b2+0ul),(device const ushort*)(b3+0ul),(device const ushort*)(b4+0ul),(device const float*)(b5+0ul),(device const float*)(b6+0ul),*(constant GqaParams*)(b7+0ul),(coherent(device) device ushort*)(b9+0ul),(coherent(device) device const StepState*)(b8+0ul),task_id,tid%32u,tid/32u,*(threadgroup s0::Scratch*)scratch); done0++; break; }
}
threadgroup_barrier(mem_flags::mem_threadgroup);
}
}
}
{
if (!stage_barrier(flags, worker, tid, ok)) return;
const uint count1=s1::task_count(*(constant s1::GqaParams*)(b7+0ul),(coherent(device) device const s1::StepState*)(b8+0ul)); uint done1=0u;
const uint total=count1;
for(uint claim=0;claim<(total+0u)/1u;claim++) {
if(tid==0u) queue_job=atomic_fetch_add_explicit(task_queue+1u,1u,memory_order_relaxed);
threadgroup_barrier(mem_flags::mem_threadgroup);
const uint first=queue_job;
if(first>=total) break;
for(uint job=first;job<min(first+1u,total);job++) {
const uint kind=0u, task_id=job;
switch(kind) {
case 0u: { using namespace s1; s1::task((coherent(device) device const ushort*)(b9+0ul),(coherent(device) device ushort*)(b1+0ul),(coherent(device) device ushort*)(b2+0ul),(device const ushort*)(b3+0ul),(device const ushort*)(b4+0ul),(device const float*)(b5+0ul),(device const float*)(b6+0ul),(coherent(device) device float*)(b10+0ul),(coherent(device) device float*)(b11+0ul),*(constant GqaParams*)(b7+0ul),(coherent(device) device const StepState*)(b8+0ul),task_id,tid%32u,tid/32u,*(threadgroup s1::Scratch*)scratch); done1++; break; }
}
threadgroup_barrier(mem_flags::mem_threadgroup);
}
}
}
{
if (!stage_barrier(flags, worker, tid, ok)) return;
const uint count2=24u; uint done2=0u;
const uint total=count2;
for(uint claim=0;claim<(total+0u)/1u;claim++) {
if(tid==0u) queue_job=atomic_fetch_add_explicit(task_queue+2u,1u,memory_order_relaxed);
threadgroup_barrier(mem_flags::mem_threadgroup);
const uint first=queue_job;
if(first>=total) break;
for(uint job=first;job<min(first+1u,total);job++) {
const uint kind=0u, task_id=job;
switch(kind) {
case 0u: { using namespace s2; s2::task((coherent(device) device const float*)(b10+0ul),(coherent(device) device const float*)(b11+0ul),(coherent(device) device const ushort*)(b0+0ul),(coherent(device) device ushort*)(b12+0ul),*(constant GqaParams*)(b7+0ul),(coherent(device) device const StepState*)(b8+0ul),task_id*128u+tid,tid%32u,32u,*(threadgroup s2::Scratch*)scratch); done2++; break; }
}
threadgroup_barrier(mem_flags::mem_threadgroup);
}
}
}
}
