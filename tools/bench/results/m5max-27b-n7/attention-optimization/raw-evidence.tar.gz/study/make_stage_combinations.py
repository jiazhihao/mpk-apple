"""Combine the two strongest individual choices for each projection plus its base."""
import copy,itertools,json
from pathlib import Path
p=Path(__file__).resolve().parent
for ctx in (128,8192,32768):
 base=json.loads((p/f'stage-refine-{ctx}-seed.json').read_text())
 rows=[r for s in(p/f'stage-refine-{ctx}.jsonl').read_text().splitlines() if 'results'in(r:=json.loads(s))]
 options=[]
 for stage in ('0','1','2'):
  unique={}
  for r in sorted(rows,key=lambda r:r['results']['single_kernel']['gpu_us']):
   old=base.get('gemm_overrides',{});new=r['config'].get('gemm_overrides',{})
   changed=[k for k in set(old)|set(new) if old.get(k,{})!=new.get(k,{})]
   if changed==[stage]:unique.setdefault(json.dumps(new[stage],sort_keys=True),new[stage])
  options.append([None]+list(unique.values())[:2])
 configs={}
 for choice in itertools.product(*options):
  c=copy.deepcopy(base)
  for i,override in enumerate(choice):
   if override is not None:c.setdefault('gemm_overrides',{})[str(i)]=override
  configs[json.dumps(c,sort_keys=True)]=c
 (p/f'combination-refine-{ctx}-configs.json').write_text(json.dumps(list(configs.values()),indent=2));print(ctx,len(configs))
