"""Final full-layer comparisons. Context map reuses identical recipes."""
import argparse,json,subprocess,sys,time
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--shader',action='store_true');a=ap.parse_args()
p=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
selected=json.loads((p/'selected-contexts.json').read_text())
for ctx in [128,4096,8192,16384,32768]:
 config=p/selected[str(ctx)]
 reference=p/('baseline-short-layer.json'if ctx==128 else'baseline-long-layer.json')
 plain=json.loads((p/('baseline-short.json'if ctx==128 else'baseline-long.json')).read_text());reference.write_text(json.dumps({'attention':plain},indent=2))
 label=f'all16-{ctx}'+('-shader'if a.shader else'');out=p/(label+'.jsonl')
 if out.exists():raise RuntimeError('refusing duplicate output '+str(out))
 cmd=[sys.executable,str(repo/'tools/bench/modelopt_layer_bench.py'),'--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--layers',','.join(map(str,range(3,64,4))),'--ctx',str(ctx),'--capacity','33024','--part','layer','--fusion','--fusion-scope','mixer-prefix','--config',str(config),'--reference-config',str(reference),'--reference-fusion-scope','mixer-prefix','--reps','1'if a.shader else'9','--steps','1'if a.shader else'32','--fp8-mode','both','--mlx-cache-lifetime','both','--out',str(out)]
 controls=p/'selected-controls.json'
 if controls.exists():
  mapping=json.loads(controls.read_text());cmd += ['--comparison-control-config',str(p/mapping[str(ctx)])]
 with(p/(label+'.log')).open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=repo)
 rows=[json.loads(line)for line in out.read_text().splitlines()]
 assert len(rows)==16 and all(r['oracle_pass']for r in rows),label
 if not a.shader:
  assert all(r['every_pair_vs_mlx_best']['megakernel']for r in rows),label+' selected megakernel failed strict MLX gate'
 print(time.strftime('%H:%M:%S'),'completed',label,flush=True)
