"""Run selected-recipe confirmations and shared regressions serially."""
import json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;repo=Path('/Users/zhihaojia/lithos/mpk-apple')
def run(label,args,shader=False):
 env=dict(os.environ)
 if shader:env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1')
 else:
  env.pop('MTL_SHADER_VALIDATION',None);env.pop('MTL_SHADER_VALIDATION_REPORT_TO_STDERR',None)
 print(time.strftime('%H:%M:%S'),'starting',label,flush=True)
 with(p/(label+'.log')).open('w')as log:subprocess.run([sys.executable,*args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(time.strftime('%H:%M:%S'),'completed',label,flush=True)
assert (p/'selected-contexts.json').exists()
run('all16-run',[str(p/'run_all16.py')])
run('all16-summary',[str(p/'summarize_all16.py')])
run('isolated-run',[str(p/'run_isolated.py')])
run('all16-shader-run',[str(p/'run_all16.py'),'--shader'],True)
run('task-audit-run',[str(p/'run_task_audit.py')],True)
run('shared-shader-regressions',['-m','pytest','tests/contract','tests/kernels/test_attention_static.py','tests/kernels/test_gdn_block_static.py','tests/kernels/test_gdn_default.py','tests/kernels/test_mlp_block_static.py','tests/kernels/test_modelopt_mlx.py','-o','addopts=','-q','--junitxml='+str(p/'shared-shader-regressions.xml')],True)
print('Final confirmations and regressions complete.',flush=True)
