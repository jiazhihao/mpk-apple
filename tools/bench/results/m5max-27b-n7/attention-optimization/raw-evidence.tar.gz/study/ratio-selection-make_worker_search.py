"""Exhaust the compiler's valid worker-count domain for each selected recipe."""
import argparse,copy,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--sources',nargs='+',required=True);a=ap.parse_args()
p=Path(__file__).resolve().parent
raw=[json.loads(s)for f in a.sources for s in(p/f).read_text().splitlines()]
bad={json.dumps(r['config'],sort_keys=True)for r in raw if 'error'in r}
rows=[r for r in raw if 'results'in r and json.dumps(r['config'],sort_keys=True)not in bad]
for ctx in (128,8192,32768):
 base=copy.deepcopy(min((r for r in rows if r['ctx']==ctx),key=lambda r:r['results']['single_kernel']['gpu_us']/r['results']['production']['gpu_us'])['config'])
 candidates=[dict(base,workers=w)for w in range(1,257)]
 (p/f'worker-refine-{ctx}-configs.json').write_text(json.dumps(candidates,indent=2))
 (p/f'worker-refine-{ctx}-seed.json').write_text(json.dumps(base,indent=2));print(ctx,len(candidates))
