from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text()
s=s.replace('attention_prepare=False, attention_chunk_tiles=1):',"attention_prepare=False, attention_chunk_tiles=1,\n              attention_style='staged', attention_key_tile=32):",1)
s=s.replace("    if attention_qm not in (8,16):", "    if attention_style not in ('staged','cooperative') or attention_key_tile not in (32,64,128):\n        raise ValueError('unsupported attention matrix style or key tile')\n    if attention_style=='cooperative' and (not attention_prepare or attention_chunk_tiles!=1):\n        raise ValueError('cooperative attention requires prepared Q/K and one matrix tile per partition')\n    if attention_style=='staged' and attention_key_tile!=32:\n        raise ValueError('staged attention uses 32-key matrix tiles')\n    if attention_style=='cooperative' and sgs*attention_qm*attention_key_tile*4>32000:\n        raise ValueError('cooperative attention scratch exceeds the threadgroup budget')\n    if attention_qm not in (8,16):",1)
s=s.replace('attention_prepare=attention_prepare,attention_chunk_tiles=attention_chunk_tiles)', 'attention_prepare=attention_prepare,attention_chunk_tiles=attention_chunk_tiles,\n                    attention_style=attention_style,attention_key_tile=attention_key_tile)',1)
s=s.replace("if mode != 'coop' or sgs not in (1,2,4,8,16,32) or", "if sgs not in (1,2,4,8,16,32) or",1)
s=s.replace('p=specialize_attention(p,sgs,attention_prepare,attention_chunk_tiles)', 'p=specialize_attention(p,sgs,attention_prepare,attention_chunk_tiles,attention_style,attention_key_tile)',1)
s=s.replace("            o.meta['dynamic_task_count']=True", "            if k.macros.get('COOPERATIVE_ATTN')=='1':\n                k.source=k.source.replace('const uint blocks = p.kv_heads * chunks * ((rows + QM - 1u) / QM);',\n                    'const uint blocks = (p.kv_heads * chunks * ((rows + QM - 1u) / QM) + ATTENTION_SG - 1u) / ATTENTION_SG;')\n            o.meta['dynamic_task_count']=True",1)
p.write_text(s)
p=Path('monolith/compiler/attention_fusion.py');s=p.read_text().replace('from monolith.runtime.program import BufferSpec, OpSpec','from monolith.runtime.program import BufferSpec, OpSpec\nfrom monolith.kernels import KERNELS_DIR')
s=s.replace('def specialize_attention(program, sgs, prepare, chunk_tiles):', "def specialize_attention(program, sgs, prepare, chunk_tiles, style='staged', key_tile=32):")
s=s.replace('        for target in (k,prep):', '''        if style=='cooperative':
            qm=int(re.search(r'#define QM (\\d+)',k.source)[1])
            k.source=k.source[:k.source.index('// Matrix-accelerator attention:')]+(KERNELS_DIR/'gqa_decode_cooperative.metal').read_text()
            k.macros.update(CH=f'{key_tile}u',QM=str(qm),ATTENTION_SG=str(sgs),COOPERATIVE_ATTN='1')
            for fold in p.ops:
                fk=p.kernels[fold.kernel]
                if fk.function=='gqa_merge' and any(n==cb[7][0] for _,n,_ in fold.bindings):fk.macros['CH']=k.macros['CH']
        for target in (k,prep):''')
p.write_text(s)
p=Path('tests/kernels/test_attention_static.py');s=p.read_text().replace("chunk=32*cfg.get('attention_chunk_tiles',1)", "chunk=cfg.get('attention_key_tile',32)*cfg.get('attention_chunk_tiles',1)")
s=s.replace("            tiles=min(scheduler.get('attention_task_tiles',1),max(1,expected_core//16))", "            if cfg.get('attention_style')=='cooperative':expected_core=(expected_core+sgs-1)//sgs\n            tiles=min(scheduler.get('attention_task_tiles',1),max(1,expected_core//16))")
s+='''

@pytest.mark.parametrize('sgs,qm,key_tile',[(1,16,32),(4,16,32),(8,8,32),(4,16,64),(8,8,64),(4,8,128)])
def test_cooperative_attention(attention,sgs,qm,key_tile):
    test_attention_geometry_preserves_causal_cache_and_replay(
        attention,sgs,qm,80,min(sgs,4),4,
        dict(schedule='queue',task_grain='tile',task_batch=1,task_seed=True,task_stats=True),
        dict(attention_prepare=True,attention_style='cooperative',attention_key_tile=key_tile))
'''
p.write_text(s)
