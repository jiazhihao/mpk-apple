
#include <metal_stdlib>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
namespace s0 {
using namespace metal;
struct StepState {
  uint step;
  uint position;
  uint kv_len;
  uint t_this_step;
  int pending_tokens[8];
  uint rng_lo;
  uint rng_hi;
  int anchor;
  uint gamma;
  int draft_tokens[7];
  float confidence[7];
  uint verify_len;
  uint accepted;
  uint checkpoint_index;
  uint drafter_ctx_len;
  uint done;
  uint error;
  uint ring_head;
  uint ring_tail;
  uint prefill_left;
  uint n_inject;
  uint stop_at;
  uint n_chain;
  uint _pad[2];
};
static inline uint pick_chunk(uint ctx, uint kv_heads, uint rep, uint n_sg, uint n_chunks_max) {
  return 256u;
  const uint n_rg1 = (rep + 16u - 1u) / 16u;
  uint ch = 256u;
  while (ch > 16u) {
    const uint ch2 = ch / 2u, n_half = (ctx + ch2 - 1u) / ch2;
    if (kv_heads * n_rg1 * n_half > n_sg || n_half > n_chunks_max) break;
    ch = ch2;
  }
  return ch;
}
struct GqaParams {
  uint heads; uint kv_heads; uint t_active; uint position;
  uint n_sg; uint q_off; uint gate_off; uint k_off;
  uint v_off; uint in_stride; uint out_stride; uint ctx_max;
  float eps; float scaling; uint has_gate; uint n_chunks_max;
  uint rows_max; uint pad0; uint pad1; uint nominal_sg;
};
static inline float bf16f(ushort u) { return as_type<float>(uint(u) << 16); }
static inline float round_bf16(float v) { uint u = as_type<uint>(v); u += 0x7FFFu + ((u >> 16) & 1u); return as_type<float>(u & 0xFFFF0000u); }
static inline ushort bf16bits(float v) { return ushort(as_type<uint>(round_bf16(v)) >> 16); }
static inline float bf16lo(uint u) { return as_type<float>(u << 16); }
static inline float bf16hi(uint u) { return as_type<float>(u & 0xFFFF0000u); }
static inline void load_dl(coherent(device) device const ushort* p, thread float* f) {
  const uint4 q = *(coherent(device) device const uint4*)p;
  f[0] = bf16lo(q.x); f[1] = bf16hi(q.x); f[2] = bf16lo(q.y); f[3] = bf16hi(q.y);
  f[4] = bf16lo(q.z); f[5] = bf16hi(q.z); f[6] = bf16lo(q.w); f[7] = bf16hi(q.w);
}
static inline uint pack_bf16x2_bits(float lo, float hi) { return uint(bf16bits(lo)) | (uint(bf16bits(hi)) << 16); }
static inline void store_dl(coherent(device) device ushort* p, const thread float* f) {
  *(coherent(device) device uint4*)p = uint4(pack_bf16x2_bits(f[0], f[1]), pack_bf16x2_bits(f[2], f[3]), pack_bf16x2_bits(f[4], f[5]), pack_bf16x2_bits(f[6], f[7]));
}
static inline void copy_dl(coherent(device) device ushort* dst, coherent(device) device const ushort* src) {
  *(coherent(device) device uint4*)dst = *(coherent(device) device const uint4*)src;
}
static inline void load_part(coherent(device) device const float* p, thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) { const float4 q = *(coherent(device) device const float4*)(p + e); f[e] = q.x; f[e + 1] = q.y; f[e + 2] = q.z; f[e + 3] = q.w; }
}
static inline void store_part(coherent(device) device float* p, const thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) *(coherent(device) device float4*)(p + e) = float4(f[e], f[e + 1], f[e + 2], f[e + 3]);
}
static inline void norm_rope(thread float* f, coherent(device) device const float* nw, coherent(device) device const ushort* cos_row, coherent(device) device const ushort* sin_row,
                             float eps, uint lane) {
  float ss = 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) ss = fma(f[e], f[e], ss);
  ss = simd_sum(ss);
  const float rstd = rsqrt(ss / float(256) + eps);
  for (uint e = 0; e < (256 / 32u); e++) f[e] = round_bf16(f[e] * rstd * nw[lane * (256 / 32u) + e]);
  const bool lo = lane < 16u;
  float r[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) {
    const float partner = simd_shuffle_xor(f[e], 16u);
    const float c = bf16f(cos_row[lane * (256 / 32u) + e]), s = bf16f(sin_row[lane * (256 / 32u) + e]);
    const float a = round_bf16(f[e] * c), b = round_bf16(partner * s);
    r[e] = round_bf16(lo ? a - b : a + b);
  }
  for (uint e = 0; e < (256 / 32u); e++) f[e] = r[e];
}
static inline uint chunk_of(uint ctx, uint kv, uint n_tg) {
  uint ch = 32u;
  if (kv * ((ctx + 12u * 64u - 1u) / (12u * 64u)) >= n_tg) ch = 64u;
  if (kv * ((ctx + 12u * 128u - 1u) / (12u * 128u)) >= n_tg) ch = 128u;
  return ch;
}


using namespace mpp::tensor_ops;
using GqaTG = tensor<threadgroup bfloat, dextents<int, 2>, tensor_inline>;
using GqaFloatTG = tensor<threadgroup float, dextents<int, 2>, tensor_inline>;
constexpr constant auto score_desc = matmul2d_descriptor(16, 32u, 256, false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
constexpr constant auto value_desc = matmul2d_descriptor(16, 256, 32u, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);
struct GqaTileScratch { bfloat query[16 * 256]; float score[16 * 32u]; };



struct Scratch { uint unused; };
static inline void task(coherent(device) device const ushort* qkvg,coherent(device) device ushort* k_cache,coherent(device) device ushort* v_cache,device const ushort* cos_t,device const ushort* sin_t,device const float* q_norm,device const float* k_norm,constant GqaParams& p,coherent(device) device ushort* prepared_q,coherent(device) device const StepState* st,uint group,uint lane,uint sg, threadgroup Scratch& sm) {

  if (st->done) return;
  const uint idx = group * 4u + sg, T = st->t_this_step, position = st->position;
  if (idx < T * 12u) {
    const uint t = idx / 12u, h = idx % 12u;
    float q[(256 / 32u)];
    coherent(device) device const ushort* row = qkvg + t * 7168u + 0u + h * 256 + lane * (256 / 32u);
    load_dl(row, q);
    norm_rope(q, q_norm, cos_t + (position + t) * 256, sin_t + (position + t) * 256, 9.999999974752427e-07f, lane);
    store_dl(prepared_q + t*7168u +0u +h*256 +lane*(256 / 32u), q);
  }
  if (idx < T * 2u) {
    const uint t = idx / 2u, h = idx % 2u;
    float k[(256 / 32u)];
    load_dl(qkvg + t * 7168u + 3072u + h * 256 + lane * (256 / 32u), k);
    norm_rope(k, k_norm, cos_t + (position + t) * 256, sin_t + (position + t) * 256, 9.999999974752427e-07f, lane);
    store_dl(k_cache + ((position + t) * 2u + h) * 256 + lane * (256 / 32u), k);
    copy_dl(v_cache + ((position + t) * 2u + h) * 256 + lane * (256 / 32u),
            qkvg + t * 7168u + 3584u + h * 256 + lane * (256 / 32u));
  }

}

}
namespace s1 {
using namespace metal;
struct StepState {
  uint step;
  uint position;
  uint kv_len;
  uint t_this_step;
  int pending_tokens[8];
  uint rng_lo;
  uint rng_hi;
  int anchor;
  uint gamma;
  int draft_tokens[7];
  float confidence[7];
  uint verify_len;
  uint accepted;
  uint checkpoint_index;
  uint drafter_ctx_len;
  uint done;
  uint error;
  uint ring_head;
  uint ring_tail;
  uint prefill_left;
  uint n_inject;
  uint stop_at;
  uint n_chain;
  uint _pad[2];
};
static inline uint pick_chunk(uint ctx, uint kv_heads, uint rep, uint n_sg, uint n_chunks_max) {
  return 256u;
  const uint n_rg1 = (rep + 16u - 1u) / 16u;
  uint ch = 256u;
  while (ch > 16u) {
    const uint ch2 = ch / 2u, n_half = (ctx + ch2 - 1u) / ch2;
    if (kv_heads * n_rg1 * n_half > n_sg || n_half > n_chunks_max) break;
    ch = ch2;
  }
  return ch;
}
struct GqaParams {
  uint heads; uint kv_heads; uint t_active; uint position;
  uint n_sg; uint q_off; uint gate_off; uint k_off;
  uint v_off; uint in_stride; uint out_stride; uint ctx_max;
  float eps; float scaling; uint has_gate; uint n_chunks_max;
  uint rows_max; uint pad0; uint pad1; uint nominal_sg;
};
static inline float bf16f(ushort u) { return as_type<float>(uint(u) << 16); }
static inline float round_bf16(float v) { uint u = as_type<uint>(v); u += 0x7FFFu + ((u >> 16) & 1u); return as_type<float>(u & 0xFFFF0000u); }
static inline ushort bf16bits(float v) { return ushort(as_type<uint>(round_bf16(v)) >> 16); }
static inline float bf16lo(uint u) { return as_type<float>(u << 16); }
static inline float bf16hi(uint u) { return as_type<float>(u & 0xFFFF0000u); }
static inline void load_dl(coherent(device) device const ushort* p, thread float* f) {
  const uint4 q = *(coherent(device) device const uint4*)p;
  f[0] = bf16lo(q.x); f[1] = bf16hi(q.x); f[2] = bf16lo(q.y); f[3] = bf16hi(q.y);
  f[4] = bf16lo(q.z); f[5] = bf16hi(q.z); f[6] = bf16lo(q.w); f[7] = bf16hi(q.w);
}
static inline uint pack_bf16x2_bits(float lo, float hi) { return uint(bf16bits(lo)) | (uint(bf16bits(hi)) << 16); }
static inline void store_dl(coherent(device) device ushort* p, const thread float* f) {
  *(coherent(device) device uint4*)p = uint4(pack_bf16x2_bits(f[0], f[1]), pack_bf16x2_bits(f[2], f[3]), pack_bf16x2_bits(f[4], f[5]), pack_bf16x2_bits(f[6], f[7]));
}
static inline void copy_dl(coherent(device) device ushort* dst, coherent(device) device const ushort* src) {
  *(coherent(device) device uint4*)dst = *(coherent(device) device const uint4*)src;
}
static inline void load_part(coherent(device) device const float* p, thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) { const float4 q = *(coherent(device) device const float4*)(p + e); f[e] = q.x; f[e + 1] = q.y; f[e + 2] = q.z; f[e + 3] = q.w; }
}
static inline void store_part(coherent(device) device float* p, const thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) *(coherent(device) device float4*)(p + e) = float4(f[e], f[e + 1], f[e + 2], f[e + 3]);
}
static inline void norm_rope(thread float* f, coherent(device) device const float* nw, coherent(device) device const ushort* cos_row, coherent(device) device const ushort* sin_row,
                             float eps, uint lane) {
  float ss = 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) ss = fma(f[e], f[e], ss);
  ss = simd_sum(ss);
  const float rstd = rsqrt(ss / float(256) + eps);
  for (uint e = 0; e < (256 / 32u); e++) f[e] = round_bf16(f[e] * rstd * nw[lane * (256 / 32u) + e]);
  const bool lo = lane < 16u;
  float r[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) {
    const float partner = simd_shuffle_xor(f[e], 16u);
    const float c = bf16f(cos_row[lane * (256 / 32u) + e]), s = bf16f(sin_row[lane * (256 / 32u) + e]);
    const float a = round_bf16(f[e] * c), b = round_bf16(partner * s);
    r[e] = round_bf16(lo ? a - b : a + b);
  }
  for (uint e = 0; e < (256 / 32u); e++) f[e] = r[e];
}
static inline uint chunk_of(uint ctx, uint kv, uint n_tg) {
  uint ch = 32u;
  if (kv * ((ctx + 12u * 64u - 1u) / (12u * 64u)) >= n_tg) ch = 64u;
  if (kv * ((ctx + 12u * 128u - 1u) / (12u * 128u)) >= n_tg) ch = 128u;
  return ch;
}


using namespace mpp::tensor_ops;
using GqaTG = tensor<threadgroup bfloat, dextents<int, 2>, tensor_inline>;
using GqaFloatTG = tensor<threadgroup float, dextents<int, 2>, tensor_inline>;
constexpr constant auto score_desc = matmul2d_descriptor(16, 32u, 256, false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
constexpr constant auto value_desc = matmul2d_descriptor(16, 256, 32u, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);
struct GqaTileScratch { bfloat query[16 * 256]; float score[16 * 32u]; };
static inline void prefix_load_dl(device const ushort* p, thread float* f) {
  const uint4 q = *(device const uint4*)p;
  f[0] = bf16lo(q.x); f[1] = bf16hi(q.x); f[2] = bf16lo(q.y); f[3] = bf16hi(q.y);
  f[4] = bf16lo(q.z); f[5] = bf16hi(q.z); f[6] = bf16lo(q.w); f[7] = bf16hi(q.w);
}
static inline uint tiles_per_task(uint blocks) {
  return min(1u, max(1u, blocks / 16u));
}

static inline uint task_count(constant GqaParams& p, coherent(device) device const StepState* st) {
  if (st->done || st->t_this_step == 0u) return 0u;
  const uint rows = st->t_this_step * (p.heads / p.kv_heads);
  const uint chunks = (st->position + st->t_this_step + 256u - 1u) / 256u;
  const uint blocks = p.kv_heads * chunks * ((rows + 16 - 1u) / 16);
  const uint tiles = tiles_per_task(blocks);
  return (blocks + tiles - 1u) / tiles;
}

struct Scratch { GqaTileScratch scratch; bfloat kv_tile[32u * 256]; bfloat prob[16 * 32u]; float row_md[16 * 2]; float carry[16 * 2]; };
static inline void task(coherent(device) device const ushort* qkvg,coherent(device) device ushort* k_cache,coherent(device) device ushort* v_cache,device const ushort* cos_t,device const ushort* sin_t,device const float* q_norm,device const float* k_norm,device const ushort* prefix_k,device const ushort* prefix_v,coherent(device) device float* part_o,coherent(device) device float* part_md,constant GqaParams& p,coherent(device) device const StepState* st,uint tgid,uint lane,uint sgi, threadgroup Scratch& sm) {

  
  
  
  
  
  if (st->done) return;
  const uint T = st->t_this_step, position = st->position;
  if (T == 0u) return;
  const uint rows = T * (12u / 2u), rep = 12u / 2u;
  const uint ctx = position + T, chunks = (ctx + 256u - 1u) / 256u;
  const uint groups = (rows + 16 - 1u) / 16;
  const uint task_tiles=tiles_per_task(2u * chunks * groups);
  for (uint block = tgid*task_tiles; block < min(2u * chunks * groups, (tgid+1u)*task_tiles); block++) {
    const uint j = block / (chunks * groups), c = (block / groups) % chunks, r0 = (block % groups) * 16;
    if (j >= 2u) return;
    for (uint r = sgi; r < 16; r += 4) {
      float q[(256 / 32u)];
      const uint row = r0 + r, t = row / rep, h = j * rep + row % rep;
      for (uint e = 0; e < (256 / 32u); e++) q[e] = 0.0f;
      if (row < rows) {
        load_dl(qkvg + t * 7168u + 0u + h * 256 + lane * (256 / 32u), q);
      }
      for (uint e = 0; e < (256 / 32u); e++) sm.scratch.query[r * 256 + lane * (256 / 32u) + e] = bfloat(q[e]);
    }
    matmul2d<value_desc, execution_simdgroups<4>> value_op;
    GqaTG vt(sm.kv_tile, dextents<int, 2>(256, 32u));
    auto accum = value_op.get_destination_cooperative_tensor<GqaTG, GqaTG, float>();
    for (uint16_t i=0; i<accum.get_capacity(); i++) if (accum.is_valid_element(i)) accum[i]=0.0f;
    for (uint r=sgi; r<16; r+=4) if (lane==0) { sm.row_md[2*r]=-INFINITY; sm.row_md[2*r+1]=0.0f; }
    for (uint sub=0; sub<256u/32u && c*256u +sub*32u<ctx; sub++) {
    const uint key_base=c*256u +sub*32u;
    for (uint kk = sgi; kk < 32u; kk += 4) {
      const uint key = key_base + kk;
      float k[(256 / 32u)];
      for (uint e = 0; e < (256 / 32u); e++) k[e] = 0.0f;
      if (key < position) prefix_load_dl(prefix_k + (key*2u +j)*256 +lane*(256 / 32u),k);
      else if (key < ctx) load_dl(k_cache + (key*2u +j)*256 +lane*(256 / 32u),k);
      for (uint e = 0; e < (256 / 32u); e++) sm.kv_tile[kk * 256 + lane * (256 / 32u) + e] = bfloat(k[e]);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    matmul2d<score_desc, execution_simdgroups<4>> score_op;
    GqaTG qt(sm.scratch.query, dextents<int, 2>(256, 16));
    GqaTG kt(sm.kv_tile, dextents<int, 2>(256, 32u));
    auto scores = score_op.get_destination_cooperative_tensor<GqaTG, decltype(kt), float>();
    for (uint16_t i = 0; i < scores.get_capacity(); i++) if (scores.is_valid_element(i)) scores[i] = 0.0f;
    score_op.run(qt, kt, scores);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    GqaFloatTG score_tile(sm.scratch.score, dextents<int, 2>(32u, 16));
    scores.store(score_tile);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint r = sgi; r < 16; r += 4) {
      const uint row = r0 + r, t = row / rep;
      float sc[32u / 32];
      for (uint u = 0; u < 32u / 32; u++) {
        const uint key = key_base + lane + u * 32;
        sc[u] = row < rows && key < ctx && key <= position + t ? round_bf16(round_bf16(sm.scratch.score[r * 32u + lane + u * 32]) * 0.0625f) : -INFINITY;
      }
      float local_max = -INFINITY;
      for (uint u = 0; u < 32u / 32; u++) local_max = max(local_max, sc[u]);
      const float m = simd_max(local_max);
      float den = 0;
      for (uint u = 0; u < 32u / 32; u++) {
        const float pr = sc[u] == -INFINITY ? 0.0f : exp(sc[u] - m);
        sm.prob[r * 32u + lane + u * 32] = bfloat(pr);
        den += pr;
      }
      den = simd_sum(den);
      if (lane == 0) {
        const float old_m=sm.row_md[2*r], new_m=max(old_m,m);
        const float a=old_m == -INFINITY ? 0.0f : exp(old_m-new_m);
        const float b=m == -INFINITY ? 0.0f : exp(m-new_m);
        sm.row_md[2*r]=new_m;
        sm.row_md[2*r+1]=a*sm.row_md[2*r+1]+b*den;
        sm.carry[2*r]=a; sm.carry[2*r+1]=b;
      }
    }
    for (uint kk = sgi; kk < 32u; kk += 4) {
      const uint key = key_base + kk;
      float v[(256 / 32u)];
      for (uint e = 0; e < (256 / 32u); e++) v[e] = 0.0f;
      if (key < position) prefix_load_dl(prefix_v + (key*2u +j)*256 +lane*(256 / 32u),v);
      else if (key < ctx) load_dl(v_cache + (key*2u +j)*256 +lane*(256 / 32u),v);
      for (uint e = 0; e < (256 / 32u); e++) sm.kv_tile[kk * 256 + lane * (256 / 32u) + e] = bfloat(v[e]);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    GqaTG pt(sm.prob, dextents<int, 2>(32u, 16));
    auto out = value_op.get_destination_cooperative_tensor<GqaTG, decltype(vt), float>();
    for (uint16_t i = 0; i < out.get_capacity(); i++) if (out.is_valid_element(i)) out[i] = 0.0f;
    value_op.run(pt, vt, out);
    for (uint16_t i=0; i<out.get_capacity(); i++) if (out.is_valid_element(i)) {
      const uint r=out.get_multidimensional_index(i)[1];
      accum[i]=sm.carry[2*r]*accum[i]+sm.carry[2*r+1]*out[i];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    for (uint16_t i=0; i<accum.get_capacity(); i++) if (accum.is_valid_element(i)) {
      auto idx=accum.get_multidimensional_index(i);
      const uint row=r0+idx[1], dim=idx[0];
      if (row<rows) part_o[((j*1032u +c)*48u +row)*256 +dim]=accum[i];
    }
    for (uint r=sgi; r<16; r+=4) if (lane==0 && r0+r<rows) {
      const uint base=((j*1032u +c)*48u +r0+r)*2;
      part_md[base]=sm.row_md[2*r]; part_md[base+1]=sm.row_md[2*r+1];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
  }

}

}
namespace s2 {
using namespace metal;
struct StepState {
  uint step;
  uint position;
  uint kv_len;
  uint t_this_step;
  int pending_tokens[8];
  uint rng_lo;
  uint rng_hi;
  int anchor;
  uint gamma;
  int draft_tokens[7];
  float confidence[7];
  uint verify_len;
  uint accepted;
  uint checkpoint_index;
  uint drafter_ctx_len;
  uint done;
  uint error;
  uint ring_head;
  uint ring_tail;
  uint prefill_left;
  uint n_inject;
  uint stop_at;
  uint n_chain;
  uint _pad[2];
};
static inline uint pick_chunk(uint ctx, uint kv_heads, uint rep, uint n_sg, uint n_chunks_max) {
  return 256u;
  const uint n_rg1 = (rep + 16u - 1u) / 16u;
  uint ch = 256u;
  while (ch > 16u) {
    const uint ch2 = ch / 2u, n_half = (ctx + ch2 - 1u) / ch2;
    if (kv_heads * n_rg1 * n_half > n_sg || n_half > n_chunks_max) break;
    ch = ch2;
  }
  return ch;
}
struct GqaParams {
  uint heads; uint kv_heads; uint t_active; uint position;
  uint n_sg; uint q_off; uint gate_off; uint k_off;
  uint v_off; uint in_stride; uint out_stride; uint ctx_max;
  float eps; float scaling; uint has_gate; uint n_chunks_max;
  uint rows_max; uint pad0; uint pad1; uint nominal_sg;
};
static inline float bf16f(ushort u) { return as_type<float>(uint(u) << 16); }
static inline float round_bf16(float v) { uint u = as_type<uint>(v); u += 0x7FFFu + ((u >> 16) & 1u); return as_type<float>(u & 0xFFFF0000u); }
static inline ushort bf16bits(float v) { return ushort(as_type<uint>(round_bf16(v)) >> 16); }
static inline float bf16lo(uint u) { return as_type<float>(u << 16); }
static inline float bf16hi(uint u) { return as_type<float>(u & 0xFFFF0000u); }
static inline void load_dl(coherent(device) device const ushort* p, thread float* f) {
  const uint4 q = *(coherent(device) device const uint4*)p;
  f[0] = bf16lo(q.x); f[1] = bf16hi(q.x); f[2] = bf16lo(q.y); f[3] = bf16hi(q.y);
  f[4] = bf16lo(q.z); f[5] = bf16hi(q.z); f[6] = bf16lo(q.w); f[7] = bf16hi(q.w);
}
static inline uint pack_bf16x2_bits(float lo, float hi) { return uint(bf16bits(lo)) | (uint(bf16bits(hi)) << 16); }
static inline void store_dl(coherent(device) device ushort* p, const thread float* f) {
  *(coherent(device) device uint4*)p = uint4(pack_bf16x2_bits(f[0], f[1]), pack_bf16x2_bits(f[2], f[3]), pack_bf16x2_bits(f[4], f[5]), pack_bf16x2_bits(f[6], f[7]));
}
static inline void copy_dl(coherent(device) device ushort* dst, coherent(device) device const ushort* src) {
  *(coherent(device) device uint4*)dst = *(coherent(device) device const uint4*)src;
}
static inline void load_part(coherent(device) device const float* p, thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) { const float4 q = *(coherent(device) device const float4*)(p + e); f[e] = q.x; f[e + 1] = q.y; f[e + 2] = q.z; f[e + 3] = q.w; }
}
static inline void store_part(coherent(device) device float* p, const thread float* f) {
  for (uint e = 0; e < (256 / 32u); e += 4) *(coherent(device) device float4*)(p + e) = float4(f[e], f[e + 1], f[e + 2], f[e + 3]);
}
static inline void norm_rope(thread float* f, coherent(device) device const float* nw, coherent(device) device const ushort* cos_row, coherent(device) device const ushort* sin_row,
                             float eps, uint lane) {
  float ss = 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) ss = fma(f[e], f[e], ss);
  ss = simd_sum(ss);
  const float rstd = rsqrt(ss / float(256) + eps);
  for (uint e = 0; e < (256 / 32u); e++) f[e] = round_bf16(f[e] * rstd * nw[lane * (256 / 32u) + e]);
  const bool lo = lane < 16u;
  float r[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) {
    const float partner = simd_shuffle_xor(f[e], 16u);
    const float c = bf16f(cos_row[lane * (256 / 32u) + e]), s = bf16f(sin_row[lane * (256 / 32u) + e]);
    const float a = round_bf16(f[e] * c), b = round_bf16(partner * s);
    r[e] = round_bf16(lo ? a - b : a + b);
  }
  for (uint e = 0; e < (256 / 32u); e++) f[e] = r[e];
}
static inline uint chunk_of(uint ctx, uint kv, uint n_tg) {
  uint ch = 32u;
  if (kv * ((ctx + 12u * 64u - 1u) / (12u * 64u)) >= n_tg) ch = 64u;
  if (kv * ((ctx + 12u * 128u - 1u) / (12u * 128u)) >= n_tg) ch = 128u;
  return ch;
}


using namespace mpp::tensor_ops;
using GqaTG = tensor<threadgroup bfloat, dextents<int, 2>, tensor_inline>;
using GqaFloatTG = tensor<threadgroup float, dextents<int, 2>, tensor_inline>;
constexpr constant auto score_desc = matmul2d_descriptor(16, 256u, 256, false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
constexpr constant auto value_desc = matmul2d_descriptor(16, 256, 256u, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);
union GqaTileScratch { bfloat query[16 * 256]; float score[16 * 256u]; };


struct Scratch { uint unused; };
static inline void task(coherent(device) device const float* part_o,coherent(device) device const float* part_md,coherent(device) device const ushort* qkvg,coherent(device) device ushort* out,constant GqaParams& p,coherent(device) device const StepState* st,uint gid,uint lane,uint sw, threadgroup Scratch& sm) {

  const uint sg = gid / sw;
  const uint t = sg / 12u, h = sg % 12u;
  if (st->done) return;
  const uint T = st->t_this_step, ctx = st->position + T;
  if (t >= T) return;
  const uint rep = 12u / 2u;
  const uint j = h / rep, row = t * rep + (h % rep);
  const uint ch = pick_chunk(ctx, 2u, rep, 80u, 1032u);
  const uint n_chunks = (ctx + ch - 1u) / ch;
  float m_g = -INFINITY;
  for (uint c = 0; c < n_chunks; c++) m_g = max(m_g, part_md[((j * 1032u + c) * 48u + row) * 2u]);
  float d_g = 0.0f, o[(256 / 32u)];
  for (uint e = 0; e < (256 / 32u); e++) o[e] = 0.0f;
  for (uint c0 = 0; c0 < n_chunks; c0 += 4u) {
    float m_c[4u], d_c[4u], oc[4u][(256 / 32u)];
    for (uint u = 0; u < 4u; u++) {
      const uint base = (j * 1032u + min(c0 + u, n_chunks - 1u)) * 48u + row;
      m_c[u] = part_md[base * 2u]; d_c[u] = part_md[base * 2u + 1u];
      load_part(part_o + base * 256 + lane * (256 / 32u), oc[u]);
    }
    for (uint u = 0; u < 4u; u++) {
      if (c0 + u >= n_chunks) break;
      const bool live = m_c[u] != -INFINITY;
      const float w = live ? exp(m_c[u] - m_g) : 0.0f;
      d_g = live ? fma(d_c[u], w, d_g) : d_g;
      for (uint e = 0; e < (256 / 32u); e++) o[e] = live ? fma(w, oc[u][e], o[e]) : o[e];
    }
  }
  const float inv = d_g > 0.0f ? 1.0f / d_g : 0.0f;
  for (uint e = 0; e < (256 / 32u); e++) {
    float y = round_bf16(o[e] * inv);
    if (1u) {
      const float g = bf16f(qkvg[t * 7168u + 4096u + h * 256 + lane * (256 / 32u) + e]);
      y = round_bf16(y * round_bf16(1.0f / (1.0f + exp(-g))));
    }
    out[t * 3072u + h * 256 + lane * (256 / 32u) + e] = bf16bits(y);
  }

}

}

#define WORKERS 8u
// Bounded, coherent all-worker barrier. One SIMD group polls the arrival flags
// in parallel; all threads still publish/observe through device-scope fences.
static inline bool stage_barrier(coherent(device) device atomic_uint* flags,
                                 uint worker, uint tid, threadgroup uint& ok) {
  atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst, thread_scope_device);
  threadgroup_barrier(mem_flags::mem_device | mem_flags::mem_threadgroup);
  if (tid == 0)
    ok = atomic_fetch_add_explicit(flags + worker, 1u, memory_order_relaxed) + 1u;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if (tid < 32u) {
    const uint epoch = ok;
    bool success = true;
    for (uint i = tid; i < WORKERS; i += 32u) {
      uint spins = 0;
      while (atomic_load_explicit(flags + i, memory_order_relaxed) < epoch) {
        if (++spins == 1000000u) { success = false; break; }
      }
    }
    success = simd_all(success);
    if (tid == 0) {
      ok = uint(success);
      if (!success) atomic_store_explicit(flags + WORKERS, 1u, memory_order_relaxed);
    }
  }
  threadgroup_barrier(mem_flags::mem_device | mem_flags::mem_threadgroup);
  atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst, thread_scope_device);
  return ok != 0;
}

kernel void full_gdn(coherent(device) device uchar* b0 [[buffer(0)]],coherent(device) device uchar* b1 [[buffer(1)]],coherent(device) device uchar* b2 [[buffer(2)]],device uchar* b3 [[buffer(3)]],device uchar* b4 [[buffer(4)]],device uchar* b5 [[buffer(5)]],device uchar* b6 [[buffer(6)]],constant uchar* b7 [[buffer(7)]],coherent(device) device uchar* b8 [[buffer(8)]],coherent(device) device uchar* b9 [[buffer(9)]],coherent(device) device uchar* b10 [[buffer(10)]],coherent(device) device uchar* b11 [[buffer(11)]],coherent(device) device uchar* b12 [[buffer(12)]],coherent(device) device atomic_uint* flags [[buffer(13)]],uint tid [[thread_index_in_threadgroup]],uint worker [[threadgroup_position_in_grid]],coherent(device) device atomic_uint* task_queue [[buffer(14)]]) {

threadgroup uchar scratch[((((sizeof(s0::Scratch))>(sizeof(s1::Scratch))?(sizeof(s0::Scratch)):(sizeof(s1::Scratch))))>(sizeof(s2::Scratch))?(((sizeof(s0::Scratch))>(sizeof(s1::Scratch))?(sizeof(s0::Scratch)):(sizeof(s1::Scratch)))):(sizeof(s2::Scratch)))];
threadgroup uint& ok=*((threadgroup uint*)scratch);
threadgroup uint queue_job;
if(worker==0u && tid==0u) {
atomic_store_explicit(task_queue+0u,0u,memory_order_relaxed);
atomic_store_explicit(task_queue+1u,0u,memory_order_relaxed);
atomic_store_explicit(task_queue+2u,0u,memory_order_relaxed);
}
{
if (!stage_barrier(flags, worker, tid, ok)) return;
const uint count0=24u; uint done0=0u;
const uint total=count0;
for(uint claim=0;claim<(total+0u)/1u;claim++) {
if(tid==0u) queue_job=atomic_fetch_add_explicit(task_queue+0u,1u,memory_order_relaxed);
threadgroup_barrier(mem_flags::mem_threadgroup);
const uint first=queue_job;
if(first>=total) break;
for(uint job=first;job<min(first+1u,total);job++) {
const uint kind=0u, task_id=job;
switch(kind) {
case 0u: { using namespace s0; s0::task((coherent(device) device const ushort*)(b0+0ul),(coherent(device) device ushort*)(b1+0ul),(coherent(device) device ushort*)(b2+0ul),(device const ushort*)(b3+0ul),(device const ushort*)(b4+0ul),(device const float*)(b5+0ul),(device const float*)(b6+0ul),*(constant GqaParams*)(b7+0ul),(coherent(device) device ushort*)(b9+0ul),(coherent(device) device const StepState*)(b8+0ul),task_id,tid%32u,tid/32u,*(threadgroup s0::Scratch*)scratch); done0++; break; }
}
threadgroup_barrier(mem_flags::mem_threadgroup);
}
}
}
{
if (!stage_barrier(flags, worker, tid, ok)) return;
const uint count1=s1::task_count(*(constant s1::GqaParams*)(b7+0ul),(coherent(device) device const s1::StepState*)(b8+0ul)); uint done1=0u;
const uint total=count1;
for(uint claim=0;claim<(total+0u)/1u;claim++) {
if(tid==0u) queue_job=atomic_fetch_add_explicit(task_queue+1u,1u,memory_order_relaxed);
threadgroup_barrier(mem_flags::mem_threadgroup);
const uint first=queue_job;
if(first>=total) break;
for(uint job=first;job<min(first+1u,total);job++) {
const uint kind=0u, task_id=job;
switch(kind) {
case 0u: { using namespace s1; s1::task((coherent(device) device const ushort*)(b9+0ul),(coherent(device) device ushort*)(b1+0ul),(coherent(device) device ushort*)(b2+0ul),(device const ushort*)(b3+0ul),(device const ushort*)(b4+0ul),(device const float*)(b5+0ul),(device const float*)(b6+0ul),(device const ushort*)(b1+0ul),(device const ushort*)(b2+0ul),(coherent(device) device float*)(b10+0ul),(coherent(device) device float*)(b11+0ul),*(constant GqaParams*)(b7+0ul),(coherent(device) device const StepState*)(b8+0ul),task_id,tid%32u,tid/32u,*(threadgroup s1::Scratch*)scratch); done1++; break; }
}
threadgroup_barrier(mem_flags::mem_threadgroup);
}
}
}
{
if (!stage_barrier(flags, worker, tid, ok)) return;
const uint count2=24u; uint done2=0u;
const uint total=count2;
for(uint claim=0;claim<(total+0u)/1u;claim++) {
if(tid==0u) queue_job=atomic_fetch_add_explicit(task_queue+2u,1u,memory_order_relaxed);
threadgroup_barrier(mem_flags::mem_threadgroup);
const uint first=queue_job;
if(first>=total) break;
for(uint job=first;job<min(first+1u,total);job++) {
const uint kind=0u, task_id=job;
switch(kind) {
case 0u: { using namespace s2; s2::task((coherent(device) device const float*)(b10+0ul),(coherent(device) device const float*)(b11+0ul),(coherent(device) device const ushort*)(b0+0ul),(coherent(device) device ushort*)(b12+0ul),*(constant GqaParams*)(b7+0ul),(coherent(device) device const StepState*)(b8+0ul),task_id*128u+tid,tid%32u,32u,*(threadgroup s2::Scratch*)scratch); done2++; break; }
}
threadgroup_barrier(mem_flags::mem_threadgroup);
}
}
}
}
