"""Coordinate search for each of the three attention FP8 projections."""
import argparse,copy,itertools,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--sources',nargs='+',required=True);a=ap.parse_args()
p=Path(__file__).resolve().parent
raw=[json.loads(s)for f in a.sources for s in(p/f).read_text().splitlines()]
bad={json.dumps(r['config'],sort_keys=True)for r in raw if 'error'in r}
rows=[r for r in raw if 'results'in r and json.dumps(r['config'],sort_keys=True)not in bad]
for ctx in (128,8192,32768):
 base=copy.deepcopy(min((r for r in rows if r['ctx']==ctx),key=lambda r:r['results']['single_kernel']['gpu_us']/r['results']['production']['gpu_us'])['config'])
 out={json.dumps(base,sort_keys=True):base}
 def add(stage,override):
  c=copy.deepcopy(base);over=c.setdefault('gemm_overrides',{});over[str(stage)]=dict(over.get(str(stage),{}),**override)
  out[json.dumps(c,sort_keys=True)]=c
 for stage in range(3):
  for tn,ks,q in itertools.product((16,32),(k for k in (1,2,4,8,16,32)if k<=base['sgs']),(0,1)):add(stage,dict(tn=tn,ksplit=ks,q_outer=q))
  for decoder in ('standard','half','bits','lut','subtract','vector','half_operand'):add(stage,dict(fp8_decode=decoder))
  for block in (1,2,4,8,16,32,64,128,256,512):add(stage,dict(fp8_tile_block=block))
  for prefetch in (1,2,4):add(stage,dict(weight_prefetch=prefetch))
  if base.get('schedule')!='queue' or base.get('task_grain')!='tile':
   for groups in (40,80,120,160,240,320,640):add(stage,dict(groups=groups))
 (p/f'stage-refine-{ctx}-configs.json').write_text(json.dumps(list(out.values()),indent=2))
 (p/f'stage-refine-{ctx}-seed.json').write_text(json.dumps(base,indent=2))
 print(ctx,len(out))
