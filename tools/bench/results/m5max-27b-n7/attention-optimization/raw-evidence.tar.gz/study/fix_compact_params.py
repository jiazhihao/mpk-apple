from pathlib import Path
p=Path('/Users/zhihaojia/lithos/mpk-apple/monolith/compiler/attention_fusion.py')
s=p.read_text();a=s.index('def compact_partials(');b=s.index('\ndef _replace(',a)
s=s[:a]+'''def compact_partials(program):
    """Size private partial buffers to the chosen partition, preserving capacity.

    Core and merge may use separate records (their gate/input fields differ).
    Validate their shared workspace geometry, then update both records and give
    each consumer a private kernel specialization. Reduction order is unchanged.
    """
    cores=[o for o in program.ops if program.kernels[o.kernel].function=='gqa_decode_mma']
    for ordinal,core in enumerate(cores):
        bindings={slot:(name,off)for slot,name,off in core.bindings}
        workspaces={bindings[7][0],bindings[8][0]}
        if len(workspaces)!=2 or bindings[7][1] or bindings[8][1]:
            raise ValueError('compact attention partials require distinct whole buffers')
        for name in workspaces:
            spec=program.buffers[name]
            if spec.role!='arena' or spec.init is not None or spec.file is not None:
                raise ValueError('compact attention partials require private uninitialized arenas')
        consumers=[];records=set()
        for op in program.ops:
            touched=[(slot,name,off)for slot,name,off in op.bindings if name in workspaces]
            if not touched:continue
            fn=program.kernels[op.kernel].function
            expected={7:bindings[7],8:bindings[8]} if op is core else {0:bindings[7],1:bindings[8]}
            if (op is not core and fn!='gqa_merge') or {slot:(n,off)for slot,n,off in touched}!=expected:
                raise ValueError('attention partials have an incompatible consumer or alias')
            slot=9 if op is core else 4
            record=next(((n,off)for i,n,off in op.bindings if i==slot),None)
            if record is None or record[0] not in program.buffers:
                raise ValueError('attention partial consumer has no parameter record')
            records.add(record);consumers.append(op)
        if len(consumers)!=2:
            raise ValueError('compact attention partials require one core and one merge')
        geometry=None;data={}
        # Heads, KV heads, active rows, capacity, old partial stride and rows.
        # Gate/input offsets deliberately differ between core and merge.
        for name,offset in records:
            spec=program.buffers[name]
            if spec.role!='params' or spec.init is None or offset<0 or len(spec.init)<offset+80:
                raise ValueError('attention partial consumer has an invalid parameter record')
            params=data.setdefault(name,bytearray(spec.init))
            fields=tuple(struct.unpack_from('<I',params,offset+i)[0]for i in (0,4,8,44,60,64))
            if geometry is not None and fields!=geometry:
                raise ValueError('attention partial consumers have incompatible workspace geometry')
            geometry=fields
        _,kv,_,capacity,_,rows=geometry
        kernel=program.kernels[core.kernel]
        chunk=int(kernel.macros['CH'].rstrip('u'));dim=int(kernel.macros['D'].rstrip('u'))
        for op in consumers:
            k=program.kernels[op.kernel]
            if int(k.macros['CH'].rstrip('u'))!=chunk or int(k.macros['D'].rstrip('u'))!=dim:
                raise ValueError('attention partial consumers have incompatible tile geometry')
        chunks=(capacity+chunk-1)//chunk
        selected=[]
        for index,op in enumerate(program.ops):
            if not any((n,off)in records for _,n,off in op.bindings):continue
            old=program.kernels[op.kernel]
            if not any(op is c for c in consumers) and old.function!='gqa_prepare_mma':
                raise ValueError('attention parameter record has an incompatible consumer')
            selected.append((index,op))
        # Commit only after all compatibility checks; preserve other fields.
        for name,offset in records:struct.pack_into('<I',data[name],offset+60,chunks)
        for name,params in data.items():program.buffers[name].init=bytes(params)
        program.buffers[bindings[7][0]].nbytes=kv*chunks*rows*dim*4
        program.buffers[bindings[8][0]].nbytes=kv*chunks*rows*2*4
        for index,op in selected:
            key=op.kernel+f'.compact{ordinal}.{index}'
            private=copy.deepcopy(program.kernels[op.kernel])
            if 'STATIC_GQA_P_N_CHUNKS_MAX' in private.macros:
                private.macros['STATIC_GQA_P_N_CHUNKS_MAX']=f'{chunks}u'
            program.kernels[key]=private
            op.kernel=key

''' + s[b:];p.write_text(s)
