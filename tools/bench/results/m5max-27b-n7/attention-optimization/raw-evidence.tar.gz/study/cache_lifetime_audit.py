"""Paired cache-lifetime audit using the same MLX-LM decoder and weights."""
import json,sys
from pathlib import Path
import numpy as np
repo=Path('/Users/zhihaojia/lithos/mpk-apple');sys.path.insert(0,str(repo))
from tools.bench.modelopt_layer_bench import inputs,mlx_runner
from tools.bench.modelopt_mlx import load_layer
from tools.bench.layer_vs_mlx import our_model
import mlx.core as mx
p=Path(__file__).resolve().parent;model='/tmp/monolith-models/Qwen3.8-27B-NVFP4'
layer=our_model(model,None,33024).layers()[3]
for mode in ('mxfp8','bf16'):
 mlayer,_=load_layer(model,3,mode)
 for ctx in (128,8192,32768):
  x,state=inputs(layer,3,ctx);engines={}
  for name,retain in [('previous',True),('output_only',False)]:
   step,run=mlx_runner(mlayer,x,state,ctx,'layer',retain_state_outputs=retain,evaluate_state_each_step=True)
   result=step();mx.eval(*result);value=np.asarray(result[0].astype(mx.float32)).copy();del result
   engines[name]=(run,value)
  assert np.array_equal(engines['previous'][1],engines['output_only'][1])
  for run,_ in engines.values():run(16)
  samples={name:[]for name in engines};rng=np.random.default_rng(141)
  for _ in range(9):
   for name in rng.permutation(list(engines)):samples[name].append(engines[name][0](32)['wall_us'])
  row=dict(ctx=ctx,mode=mode,output_bit_exact=True,reps=9,steps=32,samples=samples,min_wall_us={n:min(v)for n,v in samples.items()})
  with(p/'cache-lifetime-audit.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
  print(ctx,mode,row['min_wall_us'],flush=True)
