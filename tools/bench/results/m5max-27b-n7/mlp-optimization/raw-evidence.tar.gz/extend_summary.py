from pathlib import Path
import json
import numpy as np
r=Path(__file__).parent
summary=json.loads((r/'final.summary.json').read_text())
for name,groups in summary.items():
 rows=[json.loads(l) for l in (r/(name+'.jsonl')).read_text().splitlines()]
 for kind,data in groups.items():
  rs=[x for x in rows if kind=='all' or x['kind']==kind]
  comparisons={}
  for label,a,b in [('fused_vs_original','optimized_mlp','production'),('native_vs_original','optimized_mlp_native','production'),('fused_vs_native','optimized_mlp','optimized_mlp_native'),('native_vs_fused','optimized_mlp_native','optimized_mlp'),('fused_vs_current_mixers','optimized_mlp','megakernel'),('native_vs_current_mixers','optimized_mlp_native','megakernel')]:
   if b not in rs[0]['results']:continue
   mins=[x['results'][a]['min_wall_us']/x['results'][b]['min_wall_us'] for x in rs]
   pairs=[u['wall_us']/v['wall_us'] for x in rs for u,v in zip(x['samples'][a],x['samples'][b])]
   comparisons[label]=dict(median_min_ratio=float(np.median(mins)),min_ratio=min(mins),max_ratio=max(mins),cases_won=sum(x<1 for x in mins),paired_wins=sum(x<1 for x in pairs),pairs=len(pairs),median_paired_ratio=float(np.median(pairs)),worst_paired_ratio=max(pairs))
  for n in ('optimized_mlp','optimized_mlp_native'):
   mins=[x['results'][n]['min_wall_us']/min(v['min_wall_us'] for k,v in x['results'].items() if k.startswith('mlx')) for x in rs]
   comparisons[n+'_vs_fastest_mlx']=dict(median_min_ratio=float(np.median(mins)),min_ratio=min(mins),max_ratio=max(mins),cases_won=sum(x<1 for x in mins))
  data['comparisons']=comparisons
(r/'final.summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
