from pathlib import Path
import json,itertools
r=Path(__file__).parent
c=[]
for s,tn,tk,w,layout in itertools.product((2,4,8),(16,32),(64,128,256),(40,80,160,240,320),('blm','tile')):
 if (17408//tk)%s:continue
 c.append(dict(workers=w,sgs=s,tn=tn,ksplit=s,compact=True,mode='native',staged_tk=tk,nvfp4_layout=layout))
(r/'native-configs.json').write_text(json.dumps(c,indent=2))
d=[]
for operand,s,w in itertools.product(('standard','half','half2','half4','float4'),(8,16,32),(40,80)):
 d.append(dict(workers=w,sgs=s,tn=32,ksplit=s,compact=True,barrier='simd',nvfp4_layout='tile',nvfp4_operand=operand))
for s,ks,tn,w in itertools.product((4,8,16,32),(1,2,4,8,16),(16,32),(40,80,120)):
 if ks>s:continue
 d.append(dict(workers=w,sgs=s,tn=tn,ksplit=ks,compact=True,barrier='simd',nvfp4_layout='tile',nvfp4_tile_block=8))
(r/'packed-geometry-configs.json').write_text(json.dumps(d,indent=2))
print('native',len(c),'packed geometry+arithmetic',len(d))
