from pathlib import Path
import subprocess,sys,json
r=Path(__file__).parent
rows=[json.loads(l) for l in (r/'all-layers-32768.jsonl').read_text().splitlines()]
layers=sorted({x['layer'] for x in rows if any(a['wall_us']>=b['wall_us'] for a,b in zip(x['samples']['optimized_mlp_native'],x['samples']['production']))})
(r/'repeat-outliers-plan.json').write_text(json.dumps(dict(layers=layers,reason='Repeat observed native-vs-original losses at32K. Preserve all original samples; this is an additional diagnostic, not a replacement dataset.',reps=9,steps=32),indent=2))
if layers:
 cmd=[sys.executable,'tools/bench/modelopt_layer_bench.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--capacity','33024','--part','layer','--layers',','.join(map(str,layers)),'--ctx','32768','--fusion','--fusion-scope','mixer-prefix','--config',str(r/'mixers-32768.json'),'--mlp-config',str(r/'selected-mega.json'),'--mlp-control-config',str(r/'selected-native.json'),'--reps','9','--steps','32','--fp8-mode','both','--mlx-cache-lifetime','both','--out',str(r/'repeat-32k.jsonl')]
 with (r/'repeat-32k.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
