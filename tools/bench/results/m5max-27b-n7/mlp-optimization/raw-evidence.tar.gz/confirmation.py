from pathlib import Path
import subprocess,sys
r=Path(__file__).parent
for script in ['boundary_search.py','finalists.py','select_final.py']:
 with (r/(script.removesuffix('.py')+'-run.log')).open('w') as f:subprocess.run([sys.executable,str(r/script)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print(script,'done',flush=True)
