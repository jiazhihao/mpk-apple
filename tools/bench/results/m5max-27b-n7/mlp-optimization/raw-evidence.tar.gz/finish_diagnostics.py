from pathlib import Path
import subprocess,sys
r=Path(__file__).parent
for script in ['repeat_outliers.py','summarize_repeat.py','audit_geometry.py']:
 with (r/(script.removesuffix('.py')+'-run.log')).open('w') as f:subprocess.run([sys.executable,str(r/script)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print(script,'done',flush=True)
