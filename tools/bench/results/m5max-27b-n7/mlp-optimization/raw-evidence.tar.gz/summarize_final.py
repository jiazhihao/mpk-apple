from pathlib import Path
import json,csv,hashlib
import numpy as np
R=Path(__file__).parent
summary={};tab=[]
for name in ['all64-mlp',*[f'all-layers-{c}' for c in (128,4096,8192,16384,32768)]]:
 rows=[json.loads(l) for l in (R/(name+'.jsonl')).read_text().splitlines()]
 bykind={}
 for r in rows:
  refs=[n for n in r['results'] if n.startswith('mlx')]
  engines=[n for n in r['results'] if n not in refs]
  best=min(r['results'][n]['min_wall_us'] for n in refs)
  line=dict(part=r['part'],layer=r['layer'],ctx=r['ctx'],kind=r['kind'],oracle_pass=r['oracle_pass'],fastest_mlx_us=best)
  for n in engines:line[n+'_us']=r['results'][n]['min_wall_us']
  for n in ('optimized_mlp','optimized_mlp_native'):
   line[n+'_all_pairs_original']=all(a['wall_us']<b['wall_us'] for a,b in zip(r['samples'][n],r['samples']['production']))
   line[n+'_wins_original']=sum(a['wall_us']<b['wall_us'] for a,b in zip(r['samples'][n],r['samples']['production']))
   line[n+'_wins_mlx']=sum(r['samples'][n][i]['wall_us']<min(r['samples'][m][i]['wall_us'] for m in refs) for i in range(r['reps']))
  tab.append(line);bykind.setdefault(r['kind'],[]).append((r,line))
 groups={}
 for kind,entries in {'all':[(r,t) for r,t in zip(rows,tab[-len(rows):])],**bykind}.items():
  ss=[t for r,t in entries]
  keys=[k for k in ss[0] if k.endswith('_us') or k.endswith('_wins_original') or k.endswith('_wins_mlx')]
  groups[kind]=dict(cases=len(ss),oracles_pass=all(x['oracle_pass'] for x in ss),total_pairs=sum(r['reps'] for r,t in entries),
   medians={k:float(np.median([x[k] for x in ss])) for k in keys if k.endswith('_us')},
   wins={k:sum(x[k] for x in ss) for k in keys if '_wins_'in k})
 summary[name]=groups
keys=list(dict.fromkeys(k for row in tab for k in row))
with (R/'final.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(tab)
(R/'final.summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
