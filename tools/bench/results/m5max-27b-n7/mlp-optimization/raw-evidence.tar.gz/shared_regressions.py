from pathlib import Path
import subprocess,sys,os
r=Path(__file__).parent
env=os.environ.copy();env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1')
cmd=[sys.executable,'-m','pytest','tests/contract','tests/kernels/test_attention_static.py','tests/kernels/test_gdn_block_static.py','tests/kernels/test_gdn_default.py','tests/kernels/test_mlp_block_static.py','tests/kernels/test_modelopt_mlx.py','-o','addopts=','-q','--junitxml='+str(r/'shared-shader-regressions.xml')]
with (r/'shared-shader-regressions.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
