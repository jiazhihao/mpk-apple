"""Deterministic adaptive domains; independent GPU jobs always execute serially."""
from pathlib import Path
import copy,json,itertools,subprocess,sys,random
import numpy as np
R=Path(__file__).parent
BASE=[sys.executable,'tools/bench/modelopt_mega_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/target-pack','--kind','mlp','--reps','3','--steps','8']
def read(names):
 return [json.loads(l) for name in names for l in (R/(name+'.jsonl')).read_text().splitlines()]
def score(r,metric):
 name=r.get('selected_engine','single_kernel')
 if metric=='absolute':return r['results'][name]['gpu_us']
 ratios=[a['gpu_us']/b['gpu_us'] for a,b in zip(r['samples'][name],r['samples']['production'])]
 return float(np.median(ratios)) if metric=='median' else max(ratios)
def leaders(names,count=2):
 rows=read(names);bad={json.dumps(r['config'],sort_keys=True) for r in rows if 'error' in r}
 rows=[r for r in rows if 'results' in r and json.dumps(r['config'],sort_keys=True) not in bad]
 out=[]
 for metric in ('absolute','median','worst'):
  best=min(rows,key=lambda r:score(r,metric))['config']
  if best not in out:out.append(best)
 return out[:count]
def unique(cs):
 out=list({json.dumps(c,sort_keys=True):c for c in cs}.values());random.Random(141).shuffle(out);return out
def run(name,cs,native=False,reps=None,steps=None,layer=None):
 cs=unique(cs);(R/(name+'-configs.json')).write_text(json.dumps(cs,indent=2));print(name,len(cs),flush=True)
 cmd=BASE+['--configs',str(R/(name+'-configs.json')),'--out',str(R/(name+'.jsonl'))]
 if native:cmd+=['--control-only']
 if reps:cmd+=['--reps',str(reps)]
 if steps:cmd+=['--steps',str(steps)]
 if layer is not None:cmd+=['--layer',str(layer)]
 with (R/(name+'.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'done',flush=True)
def variants(b,updates):return [dict(copy.deepcopy(b),**u) for u in updates]
def global_search(native):
 names=['native'] if native else ['geometry','packing','packed-geometry']
 seeds=leaders(names,3);cs=[]
 for b in seeds:
  cs.append(b)
  updates=[]
  for key,values in dict(decode=range(4),k_unroll=(1,2,4,8),compact=(False,True),q_outer=(0,1),nvfp4_tile_block=(1,2,4,8,16,32,64,128,256,512),nvfp4_scale_mode=('shared','duplicated'),nvfp4_operand=('standard','half','half2','half4','float4'),perm_sgs=(1,2,4,8,16,32,64,128)).items():
   for value in values:updates.append({key:value})
  if not native:
   for key,values in dict(tm=(16,32),unroll=(False,True),short_decode=(False,True),nvfp4_prefetch=(1,2,4),direct_norm=(False,True),task_barrier=(False,True),noinline=(False,True),restrict_weights=(False,True),flag_stride=(1,2,4,8,16,32,64),arrival=('rmw','store','register'),barrier=('simd','serial','leader'),poll_sgs=(1,2,4,8)).items():
    for value in values:updates.append({key:value})
   for grain,batch,seed in itertools.product(('group','tile'),(1,2,4,8,16,32),(False,True)):
    updates.append(dict(schedule='queue',task_grain=grain,task_batch=batch,task_seed=seed,task_seed_bound=seed))
   updates+=[dict(schedule='interleave'),dict(schedule='stages')]
  for scalar in (1,2,4,8,16,32):
   if scalar<=b['sgs']:updates.append(dict(scalar_sgs=scalar))
  cs+=variants(b,updates)
 run('global-native' if native else 'global-mega',cs,native)
if __name__=='__main__':
 for native in (False,True):global_search(native)
