from pathlib import Path
import json,shutil,itertools,hashlib
root=Path('/Users/zhihaojia/lithos/mpk-apple');out=Path('/tmp/monolith-m5max/mlp-exhaustive')
files=['monolith/compiler/static_fusion.py','monolith/compiler/fp8_tiles.py','kernels/gemm_tile.metal','tests/kernels/test_mlp_block_static.py','tools/bench/modelopt_layer_bench.py','tools/bench/modelopt_mega_tune.py','profiles/apple-m5-max-40c.json']
for f in files:shutil.copy(root/f,out/('initial-'+f.replace('/','_')))
plan=dict(scope='Fixed N7/T8 NVFP4 MLP on M5 Max 40 cores; no speculative decoding performance',model='nvidia/Qwen3.8-27B-NVFP4',phases=['Original BLM geometry and scheduling screen','Lossless operand packing and decoder alternatives','Per-projection geometry, reduction splitting, task and synchronization interactions','Dense worker sweep and local refinement','Paired finalists on early/middle/late layers','All64 MLP versus original and MLX-LM, complete-layer integration','Shader validation and shared regressions'],screen=dict(reps=3,steps=8),final=dict(reps=9,steps=32),selection='Carry minimum, median and worst paired-ratio leaders. Reject errors and unstable configurations. Report finite search domains and remaining algorithmic limits.')
(out/'study-plan.json').write_text(json.dumps(plan,indent=2))
c=[]
for s,tn in itertools.product((1,2,4,8,16,32),(16,32)):
 for ks in (1,2,4,8,16,32):
  if ks>s:continue
  for w in (40,80,120):
   c.append(dict(workers=w,sgs=s,tn=tn,ksplit=ks,compact=True,narrow_scales=True,barrier='simd',schedule='queue',task_grain='tile',task_seed=True,task_seed_bound=True))
for s,tn,tk in itertools.product((2,4,8),(16,32),(64,128,256)):
 c.append(dict(workers=80,sgs=s,tn=tn,ksplit=s,compact=True,mode='staged',staged_tk=tk,barrier='simd',schedule='queue',task_grain='tile',task_seed=True,task_seed_bound=True))
old=dict(workers=40,sgs=32,tn=32,ksplit=32,compact=True,narrow_scales=True,barrier='simd')
c.insert(0,old);(out/'prior.json').write_text(json.dumps(old,indent=2))
(out/'geometry-configs.json').write_text(json.dumps(c,indent=2))
print('baseline configurations',len(c))
