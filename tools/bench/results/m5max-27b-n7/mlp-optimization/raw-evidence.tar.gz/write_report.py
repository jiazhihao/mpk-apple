from pathlib import Path
import json
r=Path(__file__).parent
repo=Path('/Users/zhihaojia/lithos/mpk-apple')
s=json.loads((r/'final.summary.json').read_text());coverage=json.loads((r/'coverage.json').read_text());v=json.loads((r/'validation.json').read_text())
a=s['all64-mlp']['all'];med=a['medians'];comp=a['comparisons'];native=comp['native_vs_original'];mega=comp['fused_vs_original']
link='../../tools/bench/results/m5max-27b-n7/mlp-optimization/'
text=f'''# MLP optimization on M5 Max

**[M] The selected native MLP reduces standalone MLP latency by {100*(1-native['median_min_ratio']):.1f}% versus original Monolith; the selected fused MLP reduces it by {100*(1-mega['median_min_ratio']):.1f}%.** The native path retains separate projection dispatches. The fused alternative is also measured, with its own matched control. These are explicit fixed-eight-row recipes; automatic generation selection is unchanged.

Follow-up to [issue #141](https://github.com/jiazhihao/mpk-apple/issues/141), the [GDN study](m5max-gdn-mixer-optimization.md), and the [attention study](m5max-27b-attention-optimization.md).

## All 64 standalone MLPs

[M] Median across layers of each layer's minimum wall time, in microseconds. Nine paired repetitions of 32 replays per layer. Ratios are computed per layer before taking the median.

| Engine | Wall µs | Ratio to original | Layer minima beating original | Paired wins vs original | Paired wins vs MLX-LM |
| --- | ---: | ---: | ---: | ---: | ---: |
| Original Monolith | {med['production_us']:.2f} | 1.0000 | — | — | — |
'''
for label,key,c in [('Optimized native','optimized_mlp_native',native),('Optimized megakernel','optimized_mlp',mega)]:
 text+=f"| {label} | {med[key+'_us']:.2f} | {c['median_min_ratio']:.4f} | {c['cases_won']}/64 | {c['paired_wins']}/{c['pairs']} | {a['wins'][key+'_wins_mlx']}/{a['total_pairs']} |\n"
text+=f"| Fastest MLX-LM | {med['fastest_mlx_us']:.2f} | — | — | — | — |\n\n"
text+=f"The fused/native latency ratio is {comp['fused_vs_native']['median_min_ratio']:.4f} (median per-layer ratio). Improvements from packing and geometry are distinct from any benefit of combining dispatches. [All per-layer results]({link}final.csv) and [paired summaries]({link}final.summary.json) include the matched control. Differences inside 3% are treated as near parity.\n\n"
text+='''## Complete layers with the selected mixers

[M] Median minimum wall times in microseconds. “Current mixer” uses the previously selected mixer with the original MLP; the two new columns keep that mixer and change the MLP. The MLX column is the fastest tested reference for each layer.

| Layers | Prefix | Original | Current mixer | New native MLP | New fused MLP | Fastest MLX-LM | Native/current ratio |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''
sets=[('GDN ×48',128,s['all-layers-128']['gdn'])]+[('Attention ×16',ctx,s[f'all-layers-{ctx}']['attention']) for ctx in (128,4096,8192,16384,32768)]
for name,ctx,d in sets:
 m=d['medians'];c=d['comparisons']['native_vs_current_mixers']
 text+=f"| {name} | {ctx} | {m['production_us']:.2f} | {m['megakernel_us']:.2f} | {m['optimized_mlp_native_us']:.2f} | {m['optimized_mlp_us']:.2f} | {m['fastest_mlx_us']:.2f} | {c['median_min_ratio']:.4f} |\n"
text+='\n| Layers | Prefix | Native wins vs current mixer | Fused wins vs current mixer | Native wins vs fastest MLX | Fused wins vs fastest MLX |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
for name,ctx,d in sets:
 c=d['comparisons'];n=c['native_vs_current_mixers'];f=c['fused_vs_current_mixers'];w=d['wins'];pairs=d['total_pairs']
 text+=f"| {name} | {ctx} | {n['paired_wins']}/{pairs} | {f['paired_wins']}/{pairs} | {w['optimized_mlp_native_wins_mlx']}/{pairs} | {w['optimized_mlp_wins_mlx']}/{pairs} |\n"
text+='\n| Layers | Prefix | Median fused/native ratio | Native wins vs fused |\n| --- | ---: | ---: | ---: |\n'
for name,ctx,d in sets:
 c=d['comparisons'];n=c['native_vs_fused']
 text+=f"| {name} | {ctx} | {c['fused_vs_native']['median_min_ratio']:.4f} | {n['paired_wins']}/{n['pairs']} |\n"
text+='\nIndependent medians can reverse the apparent ranking: at 4K the latency columns favor fusion, while the per-layer ratio and paired rounds favor native execution. Use the per-layer and paired comparisons to assess the difference; values within 3% remain near parity. These are per-layer measurements, not generation throughput or a streaming full-model speedup. Any paired losses are retained.\n\n'
long=s['all-layers-32768']['all'];c=long['comparisons']['native_vs_original']
text+=f"At 32K the native path wins {c['paired_wins']}/{c['pairs']} paired rounds against original Monolith. The original dataset retains every latency spike. Improvements over the previous mixer setup are less consistent at long contexts, where the MLP is a smaller fraction of total time.\n\n"
repeat=r/'repeat-32k-summary.json'
if repeat.exists():
 d=json.loads(repeat.read_text())
 text+=f"An additional repeat of the affected layer(s) records {d['native_original_wins']}/{d['pairs']} native wins versus original and {d['native_mlx_wins']}/{d['pairs']} versus MLX-LM. This diagnostic does not replace the original samples; the cause of the reproducible first-round slowdown is not established.\n\n"
text+=f'A seven-point integration check (120, 140, 144, 148, 152, 156 and 157 attention workers) did not remove the first-round slowdown. The existing 157-worker recipe kept the best median. These seven diagnostic trials are separate from the screening count, and no configuration was changed. [Diagnostic summary]({link}coupled-workers-summary.json).\n\n'
mono=r/'monolith-only-32k.jsonl'
if mono.exists():
 row=json.loads(mono.read_text());times=[a['wall_us'] for a in row['samples']['optimized_mlp_native']]
 text+=f"The same layer's Monolith-only diagnostic has native times of {min(times):.1f}–{max(times):.1f} µs across nine rounds, with {times[0]:.1f} µs in the first round. The large spike was absent in that run. This narrows the observation to the interleaved-reference conditions without establishing a specific cache, residency or scheduling cause. It does not replace the MLX comparisons.\n\n"
text+=f'''## Reusable recipes

Use one [native MLP recipe]({link}selected-native.json) or one [fused MLP recipe]({link}selected-mega.json) across all measured context lengths. [The context map]({link}selected-contexts.json) references the existing attention recipes without duplicating them.

'''
for kind in ('native','mega'):
 selection=json.loads((r/f'selection-{kind}.json').read_text())
 text+=f"Selected {kind} configuration:\n\n```json\n{json.dumps(selection['winner']['config'],indent=2)}\n```\n\n"
text+=f'The [logical tile audit]({link}task-audit.json) distinguishes launched workers from useful work. The fused recipe gives its 116 workers 8–10 gate/up tiles each; 80 workers handle two down tiles each. The native gate/up projection uses 160 groups with 6–7 tiles each. Its 640-group down launch has 160 active groups. These are logical assignments, not measured physical-core occupancy.\n\n'
text+='Selection required all 36 paired confirmation rounds to beat original Monolith, then retained candidates within 2% of the fastest eligible median paired ratio and within 3% of the best worst paired ratio in that set. The fastest remaining median determines the winner. The selection files retain every finalist, including rejected candidates.\n\n'
text+=(r/'report-methods.md').read_text()
text+='\n## Recorded search totals\n\n'
text+=f"[M] **{coverage['total_trials']:,} completed screening trials:** {coverage['accepted']:,} accepted and {coverage['rejected']:,} rejected. Finalist confirmations and all-layer/shader validation are separate from this count. [Coverage and observed domains]({link}coverage.json).\n\n"
text+='| Phase | Completed | Accepted | Rejected |\n| --- | ---: | ---: | ---: |\n'
for x in coverage['phases']:text+=f"| {x['phase']} | {x['trials']} | {x['accepted']} | {x['rejected']} |\n"
t=v['shared_tests'];audits=sum(x['cases'] for k,x in v['datasets'].items() if k.endswith('-shader'))
text+=f"\n[M] **{t['tests']-t['skipped']:,} shared tests passed**, {t['skipped']} optional module/test skipped, with {t['failures']} failures and {t['errors']} errors under Metal shader validation. All **{audits} real-model shader cases** passed. Numerical checks and dataset counts are recorded in [validation.json]({link}validation.json). The optional HTTP-serving module requires FastAPI, which is absent in this environment.\n\n"
text+=f'''## Reproduction

Run GPU jobs serially. Model and pack paths below are local inputs; the original pack stays immutable. The 33K pack contains the same weights with extended, prefix-identical position tables.

```bash
.venv/bin/python tools/bench/modelopt_layer_bench.py \\
  --model /tmp/monolith-models/Qwen3.8-27B-NVFP4 \\
  --pack /tmp/monolith-m5max/attention-tasks/pack-33k --capacity 33024 \\
  --part mlp --layers all --ctx 128 --reps 9 --steps 32 --fp8-mode mxfp8 \\
  --mlp-config tools/bench/results/m5max-27b-n7/mlp-optimization/selected-mega.json \\
  --mlp-control-config tools/bench/results/m5max-27b-n7/mlp-optimization/selected-native.json \\
  --out /tmp/recheck-mlp.jsonl
```

For complete layers, use `--part layer --fusion --fusion-scope mixer-prefix`, add the prior mixer's `--config` for that context, and set `--fp8-mode both --mlx-cache-lifetime both`. The archive's `run_final.py` records every exact invocation and shader audit. `modelopt_mlp_suffix_tune.py` reproduces the producer-boundary screens from a JSON list of configurations; pass `--control-only` for native recipes.

[Raw evidence archive]({link}raw-evidence.tar.gz) · [Source manifest]({link}source-manifest.json) · [Artifact hashes]({link}artifact-sha256.json)
'''
(repo/'docs/research/m5max-27b-mlp-optimization.md').write_text(text)
print(repo/'docs/research/m5max-27b-mlp-optimization.md')
