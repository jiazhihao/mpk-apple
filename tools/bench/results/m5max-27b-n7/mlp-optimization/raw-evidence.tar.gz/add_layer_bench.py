from pathlib import Path
p=Path('tools/bench/modelopt_layer_bench.py');s=p.read_text()
s=s.replace('from monolith.generate import Session','from monolith.compiler.mlp_fusion import tune_mlp_suffix\nfrom monolith.compiler.static_fusion import normalize, _MERGE_OPTIONS\nfrom monolith.generate import Session')
s=s.replace("    ap.add_argument('--comparison-control-config'", "    ap.add_argument('--mlp-config',type=Path,help='optimized MLP recipe; preserve the complete-layer producer boundary')\n    ap.add_argument('--mlp-control-config',type=Path,help='independently optimized multi-dispatch MLP reference')\n    ap.add_argument('--comparison-control-config'",1)
s=s.replace("    failed = False\n", "    mlp_config=json.loads(a.mlp_config.read_text()) if a.mlp_config else None\n    mlp_control_config=json.loads(a.mlp_control_config.read_text()) if a.mlp_control_config else None\n    if (mlp_config or mlp_control_config) and a.part not in ('mlp','layer'):ap.error('MLP tuning requires an MLP or complete layer')\n    if mlp_config and a.part=='layer' and a.fusion and a.fusion_scope!='mixer-prefix':ap.error('MLP suffix requires mixer-prefix fusion')\n    failed = False\n",1)
needle="        mlayer, storage = load_layer"
insert='''        for label,mcfg in (('optimized_mlp',mlp_config),('optimized_mlp_native',mlp_control_config)):
            if not mcfg:continue
            if a.part=='layer':
                cp,mp=tune_mlp_suffix(p,mcfg,mixer_config=configs['gdn' if linear else 'attention'] if a.fusion else None)
            else:
                cp=normalize(p,mcfg['sgs'],groups=mcfg['workers'],**{k:v for k,v in mcfg.items() if k not in ('workers','sgs',*_MERGE_OPTIONS)})
                mp=None if mcfg.get('mode')=='native' or label=='optimized_mlp_native' else compile_config(p,mcfg)[1]
            shared={n:b for e in engines.values() for n,b in e.buffers.items() if e.program.buffers[n].role=='weights'}
            engines[label+'_control' if mp is not None else label]=Engine(cp,sess.dev,buffers=shared)
            if mp is not None:
                shared.update({n:b for n,b in engines[label+'_control'].buffers.items() if cp.buffers[n].role=='weights'})
                engines[label]=Engine(mp,sess.dev,buffers=shared)
'''
assert needle in s;s=s.replace(needle,insert+needle,1)
needle="            runners = {n:"
insert='''            for name in ('optimized_mlp','optimized_mlp_native'):
                if name not in snaps:continue
                checks[name+'_vs_production']=metrics(bf16_to_f32(np.frombuffer(snaps[name],np.uint16)),
                    bf16_to_f32(np.frombuffer(snaps['production'],np.uint16)))
                if name+'_control' in snaps:
                    assert snaps[name]==snaps[name+'_control'],'optimized MLP control/fusion mismatch'
                    assert state_snaps[name]==state_snaps[name+'_control'],'optimized MLP state mismatch'
                    checks[name+'_control_bit_exact']=True
'''
s=s.replace(needle,insert+needle,1)
s=s.replace("'packed_control_vs_production'):","'packed_control_vs_production','optimized_mlp_vs_production','optimized_mlp_native_vs_production'):")
s=s.replace("comparison_control_configs=comparison_configs,", "comparison_control_configs=comparison_configs,mlp_config=mlp_config,mlp_control_config=mlp_control_config,")
p.write_text(s)
