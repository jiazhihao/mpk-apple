"""Explicit fixed-row MLP tuning at the existing residual/normalization boundary."""
from __future__ import annotations

import copy

from .static_fusion import normalize, merge, fuse_mixer_prefix, _MERGE_OPTIONS


def repair_projection_layouts(program):
    """Connect independently tuned projection tiles to their local producers."""
    consumers={}
    for op in program.ops:
        k=program.kernels[op.kernel]
        if k.function!='gemm_tile':continue
        binding=next((n,off) for slot,n,off in op.bindings if slot==2)
        tk=k.macros['TK']
        if binding in consumers and consumers[binding]!=tk:
            raise ValueError('shared activation consumers require identical reduction layouts')
        consumers[binding]=tk
    for i,op in enumerate(program.ops):
        k=program.kernels[op.kernel]
        for flag,slot,macro in (('PERM_OUT',3,'PERM_TK'),('NORM_OUT',14,'NORM_TK')):
            if k.macros.get(flag)!='1':continue
            binding=next(((n,off) for s,n,off in op.bindings if s==slot),None)
            if binding in consumers and k.macros.get(macro)!=consumers[binding]:
                k=copy.deepcopy(k);op.kernel=f'{op.kernel}.layout{i}';program.kernels[op.kernel]=k
                k.macros[macro]=consumers[binding]
        if k.function=='x_permute':
            binding=next((n,off) for slot,n,off in op.bindings if slot==3)
            if binding in consumers and k.macros.get('TK')!=consumers[binding]:
                k=copy.deepcopy(k);op.kernel=f'{op.kernel}.layout{i}';program.kernels[op.kernel]=k
                k.macros['TK']=consumers[binding]
    return program


def tune_mlp_suffix(program,config,*,mixer_config=None):
    """Return matched control/fusion with the original complete-layer boundary.

    Optional mixer tuning is compiled after its output layout follows the MLP.
    Each megakernel owns separate synchronization/parameter buffers. Native
    device-tensor MLP recipes return only a multi-dispatch control.
    """
    p=copy.deepcopy(program)
    tail=p.ops[-2:]
    if ([p.kernels[o.kernel].function for o in tail]!=['gemm_tile','gemm_tile'] or
            p.kernels[tail[0].kernel].macros.get('EPILOGUE')!='2' or
            p.kernels[tail[1].kernel].macros.get('EPILOGUE')!='1'):
        raise ValueError('expected gate/up and residual down projections at the layer tail')
    half=copy.deepcopy(p);half.ops=half.ops[-2:]
    # The final residual may also be a producer for another layer. Preserve its
    # external normalization layout, which this half does not own.
    outgoing=half.kernels[tail[1].kernel].macros.get('NORM_TK')
    for i,op in enumerate(half.ops):
        key=f'mlp.tuned.{op.kernel}.{i}'
        while key in half.kernels:key+='_'
        half.kernels[key]=copy.deepcopy(half.kernels[op.kernel]);op.kernel=key
    normal=normalize(half,config['sgs'],groups=config['workers'],
        **{k:v for k,v in config.items() if k not in ('workers','sgs',*_MERGE_OPTIONS)})
    repair_projection_layouts(normal)
    if outgoing is not None:normal.kernels[normal.ops[-1].kernel].macros['NORM_TK']=outgoing
    p.ops=p.ops[:-2]+normal.ops
    p.buffers.update(normal.buffers);p.kernels.update(normal.kernels)
    repair_projection_layouts(p)
    if mixer_config is not None:
        _,p=fuse_mixer_prefix(p,mixer_config)
    if config.get('mode')=='native':return p,None
    fused_half=merge(normal,config['workers'],config['sgs'],
        **{k:v for k,v in config.items() if k in _MERGE_OPTIONS})
    # Namespace transient fusion records before combining independent regions.
    renames={n:'mlp.'+n for n in fused_half.buffers if n.startswith('mega.')}
    for old,new in renames.items():fused_half.buffers[new]=fused_half.buffers.pop(old)
    for op in fused_half.ops:
        op.bindings=[(slot,renames.get(n,n),off) for slot,n,off in op.bindings]
        key='mlp.'+op.kernel
        fused_half.kernels[key]=fused_half.kernels[op.kernel];op.kernel=key
    fused=copy.deepcopy(p)
    fused.buffers.update(fused_half.buffers)
    fused.kernels.update({op.kernel:fused_half.kernels[op.kernel] for op in fused_half.ops})
    fused.ops=fused.ops[:-2]+fused_half.ops
    return p,fused
