from search import *

def combos(native):
 name='stage-native' if native else 'stage-mega';rs=[r for r in read([name]) if 'results' in r]
 groups={}
 for row in rs:
  c=copy.deepcopy(row['config']);c.pop('gemm_overrides',None);key=json.dumps(c,sort_keys=True)
  groups.setdefault(key,[]).append(row)
 cs=[]
 for key,rows in groups.items():
  b=json.loads(key)
  if len(rows)<15:continue
  stage=[]
  for index in ('0','1'):
   selected=[r for r in rows if index in r['config'].get('gemm_overrides',{})]
   opts=[{}]
   for metric in ('absolute','median','worst'):
    for row in sorted(selected,key=lambda r:score(r,metric))[:2]:
     o=row['config']['gemm_overrides'][index]
     if o not in opts:opts.append(o)
   stage.append(opts)
  for x,y in itertools.product(*stage):cs.append(dict(copy.deepcopy(b),gemm_overrides={'0':x,'1':y}))
 for b in leaders([name,'global-native' if native else 'global-mega'],3):
  cs.append(b)
  # Revisit global options with per-projection improvements in place.
  for q,block in itertools.product((0,1),(1,4,8,16,32,64,128,256,512)):
   cs.append(dict(copy.deepcopy(b),q_outer=q,nvfp4_tile_block=block))
  if native:
   for stage in ('0','1'):
    for s,ks in itertools.product((1,2,4,8,16,32),(1,2,4,8,16)):
     if ks>s:continue
     c=copy.deepcopy(b);o=c.setdefault('gemm_overrides',{}).setdefault(stage,{})
     o.update(sgs=s,ksplit=ks,scalar_sgs=1)
     cs.append(c)
   cs.append(dict(copy.deepcopy(b),nvfp4_vector_loads=True))
  else:
   for schedule,grain,batch in itertools.product(('stages','queue'),('group','tile'),(1,2,4,8)):
    cs.append(dict(copy.deepcopy(b),schedule=schedule,task_grain=grain,task_batch=batch,task_seed=schedule=='queue',task_seed_bound=schedule=='queue'))
 run('combined-native' if native else 'combined-mega',cs,native)
if __name__=='__main__':
 for native in (False,True):combos(native)
