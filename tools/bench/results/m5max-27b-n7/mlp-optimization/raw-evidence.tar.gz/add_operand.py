from pathlib import Path
p=Path('monolith/compiler/nvfp4_tiles.py');s=p.read_text().replace('def specialize_source(kernel, tile_block, scale_mode, scale_base):','def specialize_source(kernel, tile_block, scale_mode, scale_base, operand="standard"):')
s=s.replace('    kernel.source=kernel.source[:begin]+fill+kernel.source[end:]','''    if operand!='standard':
        if operand not in ('half','half2','half4','float4'):
            raise ValueError('unsupported NVFP4 operand arithmetic')
        width={'half':1,'half2':2,'half4':4,'float4':4}[operand]
        typ='half' if width==1 else 'half'+str(width)
        ityp='ushort' if width==1 else 'ushort'+str(width)
        # E2M1 * finite E4M3 is exact in half (at most five mantissa bits,
        # magnitudes from 2^-10 through 2688). Convert the exact product to
        # BF16, preserving the production operand rounding and tensor scale.
        helper=f"""
static inline {typ} nvfp4_operand_bits(uint word) {{
  {ityp} c={ityp}({','.join(f'(word>>{4*i}u)&15u' for i in range(width))});
  {ityp} m=c&{ityp}(7u);
  {ityp} bits=select({ityp}(0u),{ityp}(0x3600u)+m*{ityp}(0x200u)+
    select({ityp}(0u),{ityp}(0x200u),m>={ityp}(2u)),m>{ityp}(0u));
  return as_type<{typ}>(bits|((c&{ityp}(8u))<<12));
}}
"""
        at=kernel.source.index('kernel void gemm_tile(')
        # Insert after replacing the old operand body so source offsets remain valid.
        init_end=fill.index('#pragma clang loop unroll(full)\\n        for(uint jump=')
        init_begin=fill.index('        float wv[')
        fill=fill[:init_begin]+fill[init_end:]
        fill=fill.replace('for(uint qq=0;qq<4u;qq++)',f'for(uint qq=0;qq<4u;qq+={width}u)')
        original='''+repr('''            float v=wv[e]*decode_scale(&sc,0u);
            bT[uint16_t(((jump*NS_B+s)<<2)|qq)]=bfloat(v);''')+'''
        value=f'nvfp4_operand_bits(words[e/32u][(e%32u)/8u]>>((e%8u)*4u))'
        value=(f'float4({value})*fp8_e4m3_scale(sc)' if operand=='float4' else
               f'{value}*half(fp8_e4m3_scale(sc))')
        assignment=f'            auto exact={value};\\n'
        for component in range(width):
            element='exact' if width==1 else f'exact[{component}]'
            assignment+=f'            bT[uint16_t(((jump*NS_B+s)<<2)|qq)+{component}u]=bfloat({element});\\n'
        fill=fill.replace(original,assignment)
        kernel.source=kernel.source[:begin]+fill+kernel.source[end:]
        at=kernel.source.index('kernel void gemm_tile(')
        kernel.source=kernel.source[:at]+helper+kernel.source[at:]
    else:
        kernel.source=kernel.source[:begin]+fill+kernel.source[end:]''')
p.write_text(s)
p=Path('monolith/compiler/static_fusion.py');s=p.read_text().replace('nvfp4_scale_mode="shared"): ','nvfp4_scale_mode="shared", nvfp4_operand="standard"):')
s=s.replace("if (nvfp4_layout not in ('blm','tile')", "if (nvfp4_operand not in ('standard','half','half2','half4','float4') or (nvfp4_operand!='standard' and nvfp4_layout!='tile') or nvfp4_layout not in ('blm','tile')",1)
s=s.replace('nvfp4_scale_mode=nvfp4_scale_mode)', 'nvfp4_scale_mode=nvfp4_scale_mode,nvfp4_operand=nvfp4_operand)',1)
s=s.replace('nvfp4_tiles.specialize_source(k,nvfp4_tile_block,nvfp4_scale_mode,scale_base)','nvfp4_tiles.specialize_source(k,nvfp4_tile_block,nvfp4_scale_mode,scale_base,nvfp4_operand)')
p.write_text(s)
