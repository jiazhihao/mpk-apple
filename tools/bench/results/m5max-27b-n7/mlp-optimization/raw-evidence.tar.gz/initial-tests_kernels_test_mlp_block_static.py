"""NVFP4 quarter-word cooperative loads and full gated-MLP fusion."""
import numpy as np
import pytest

from monolith.bench import profile_for_device
from monolith.compiler import emit_program
from monolith.compiler.passes import DEFAULT_PASSES
from monolith.core import Graph, DType, T
from monolith.formats import FORMATS, PackLayout
from monolith.formats.fp import bf16_to_f32, f32_to_bf16
from monolith.formats.safetensors_reader import SafetensorsDir
from monolith.nn import GatedMLP, RMSNorm, Module, LowerContext
from monolith.nn.pack_plan import slab_requests, aux_requests, bind_formats, bind_pack_formats
from monolith.packs.packer import Packer, PackFile
from monolith.runtime import Engine, _native as nt
from tools.bench.gdn_block_bench import checked_run
from tools.bench.gdn_block_static import normalize, merge


@pytest.fixture(scope='module',params=['block','inline'])
def mlp(tmp_path_factory,request):
    torch = pytest.importorskip('torch')
    from safetensors.torch import save_file
    root = tmp_path_factory.mktemp('nvfp4-mlp-block')
    rng = np.random.default_rng(141)
    m = Module()
    m.mlp = GatedMLP(1024, 2048, hf_prefix='mlp.', prefix='mlp.')
    m.norm = RMSNorm(1024, 1e-6, 'norm.weight', prefix='norm.')
    weights = {}
    for _, mod in m.named_modules():
        for local, ws in mod.weight_map().items():
            a = rng.normal(0, .03, ws.shape).astype(np.float32)
            if ws.aux:
                weights[ws.hf_name] = torch.from_numpy(a).to(torch.bfloat16)
            else:
                spec = FORMATS.get('nvfp4').quantize(a)
                base = ws.hf_name[:-7]
                weights[ws.hf_name] = torch.from_numpy(spec.tensors['weight'])
                weights[base+'.weight_scale'] = torch.from_numpy(spec.tensors['weight_scale']).view(torch.float8_e4m3fn)
                weights[base+'.weight_scale_2'] = torch.tensor(spec.params['weight_scale_2'], dtype=torch.float32)
    save_file(weights, str(root/'model.safetensors'))
    ck = SafetensorsDir(root); bind_formats(m, ck); ck.close()
    pk = Packer(root, root/'pack')
    for r in slab_requests(m, PackLayout(scale_placement=request.param, scale_order='payload')): pk.add_slab(r)
    for r in aux_requests(m): pk.add_aux(r)
    pk.write({})
    pack = PackFile(root/'pack'); bind_pack_formats(m, pack)
    g = Graph('mlp_block'); x = g.input('hidden', (T,1024), DType.BF16)
    y = m.mlp.lower(g, x, m.norm.lower(g,x), LowerContext(t=T))
    for ps in DEFAULT_PASSES: ps(g)
    dev = nt.Device(); info = dev.info()
    p = emit_program(g, pack=pack, profile=profile_for_device(info.gpu_cores,info.apple_family),
                     t=8, tail=None, commute_norm=True)
    return dev,p,y.name


@pytest.mark.parametrize('sgs,tn,split,ksplit,compact', [
    (4,16,False,None,False),(8,32,False,None,False),(4,32,True,None,False),
    (8,16,True,None,False),(16,32,True,None,False),(32,16,True,None,False),
    (16,32,True,4,True),(32,32,True,8,True),(16,16,False,1,True),
    (16,16,True,2,False)])
def test_nvfp4_mlp_matches_original_and_control(mlp, sgs, tn, split, ksplit, compact):
    dev,p,output = mlp
    control = normalize(p,sgs,groups=4,tn=tn,split=split,ksplit=ksplit,compact=compact)
    engines = [Engine(pr,dev) for pr in (p,control,merge(control,4,sgs))]
    for seed in (3,8):
        x=f32_to_bf16(np.random.default_rng(seed).normal(0,.1,(8,1024)).astype(np.float32)).tobytes()
        for e in engines:
            e.buffers['hidden'].write(x,0)
            e.buffers[e.program.step_state].write(e.program.layout.pack({'t_this_step':8}),0)
            checked_run(e,3)
        snaps=[e.read(output,8*1024*2) for e in engines]
        assert snaps[1]==snaps[2]
        ref,got=[bf16_to_f32(np.frombuffer(s,np.uint16)).astype(np.float64) for s in (snaps[0],snaps[2])]
        assert np.isfinite(got).all()
        assert ref @ got/(np.linalg.norm(ref)*np.linalg.norm(got)) > .9999
        assert np.linalg.norm(ref-got)/np.linalg.norm(ref) < .005


@pytest.mark.parametrize('barrier', ['simd','leader'])
@pytest.mark.parametrize('short_decode',[False,True])
def test_nvfp4_specializations_and_projection_overrides(mlp,barrier,short_decode):
    dev,p,output=mlp
    control=normalize(p,16,groups=4,tn=32,split=True,narrow_scales=True,k_unroll=2,short_decode=short_decode,
                      gemm_overrides={'1':{'tn':16,'ksplit':4,'compact':True,'groups':8}})
    engines=[Engine(pr,dev) for pr in (p,control,merge(control,4,16,barrier=barrier,task_barrier=False))]
    x=f32_to_bf16(np.random.default_rng(45).normal(0,.1,(8,1024)).astype(np.float32)).tobytes()
    for e in engines:
        e.buffers['hidden'].write(x,0)
        e.buffers[e.program.step_state].write(e.program.layout.pack({'t_this_step':8}),0)
        checked_run(e,64)
    snaps=[e.read(output,8*1024*2) for e in engines]
    assert snaps[1]==snaps[2]
    ref,got=[bf16_to_f32(np.frombuffer(s,np.uint16)).astype(np.float64) for s in (snaps[0],snaps[2])]
    assert ref @ got/(np.linalg.norm(ref)*np.linalg.norm(got))>.9999
