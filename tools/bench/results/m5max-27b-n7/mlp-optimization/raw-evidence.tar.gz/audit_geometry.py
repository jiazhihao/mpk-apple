from pathlib import Path
import sys,json,struct
import numpy as np
repo=Path('/Users/zhihaojia/lithos/mpk-apple');sys.path.insert(0,str(repo))
from monolith.generate import Session
from tools.bench.layer_vs_mlx import our_model
from tools.bench.modelopt_layer_bench import build
from monolith.compiler.mlp_fusion import tune_mlp_suffix
r=Path(__file__).parent
s=Session(our_model('/tmp/monolith-models/Qwen3.8-27B-NVFP4',None,8704),'/tmp/monolith-m5max/target-pack',attention='auto')
p,_=build(s,0,'layer');result={}
for kind in ('native','mega'):
 cfg=json.loads((r/f'selected-{kind}.json').read_text());cp,mp=tune_mlp_suffix(p,cfg);stages=[]
 for label,op in zip(('gate_up','down'),cp.ops[-2:]):
  k=cp.kernels[op.kernel];name,off=next((n,off) for slot,n,off in op.bindings if slot==4)
  pars=struct.unpack_from('<IIIIfIII',cp.buffers[name].init,off)
  ks=int(k.macros.get('KSPLIT','1').rstrip('u'));sg=op.threadgroup[0]//32;groups=op.grid[0];teams=sg//ks
  tiles=int(k.macros.get('STATIC_GEMM_P_N_TILES',str(pars[1])).rstrip('u'));total_teams=int(k.macros.get('STATIC_GEMM_P_N_SG',str(pars[2])).rstrip('u'))//ks
  group_counts=[sum(max(0,(tiles-1-(g*teams+t))//total_teams+1) for t in range(teams)) for g in range(groups)]
  logical=group_counts if kind=='native' else [sum(group_counts[w::cfg['workers']]) for w in range(cfg['workers'])]
  assert sum(logical)==tiles,(label,logical,tiles)
  stages.append(dict(stage=label,tile_columns=int(k.macros['TN'].rstrip('u')),reduction_tile=int(k.macros['TK'].rstrip('u')),simd_groups=sg,k_split=ks,projection_groups=groups,total_matrix_tiles=tiles,logical_workers=len(logical),active_workers=sum(x>0 for x in logical),min_tiles=min(logical),max_tiles=max(logical),min_active_tiles=min(x for x in logical if x>0),tiles_per_worker=logical))
 result[kind]=dict(configuration=cfg,dispatches=2 if kind=='native' else 1,stages=stages)
result['scope']='Deterministic logical tile ownership from compiled program parameters; not measured physical GPU-core occupancy. Native projection groups are independent launches; fused logical workers persist across stages.'
(r/'task-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:[{a:b for a,b in t.items() if a!='tiles_per_worker'} for t in v['stages']] for k,v in result.items() if isinstance(v,dict)},indent=2))
