import subprocess,sys
from pathlib import Path
r=Path(__file__).parent
base=[sys.executable,'tools/bench/modelopt_mega_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/target-pack','--kind','mlp','--reps','3','--steps','8']
for name,extra in [('native',['--control-only']),('packed-geometry',[])]:
 with (r/(name+'.log')).open('w') as log:
  subprocess.run(base+['--configs',str(r/(name+'-configs.json')),'--out',str(r/(name+'.jsonl'))]+extra,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'completed',flush=True)
