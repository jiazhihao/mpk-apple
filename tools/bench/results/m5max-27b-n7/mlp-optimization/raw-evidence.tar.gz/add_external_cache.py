from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text()
s=s.replace("direct_norm=False,poll_sgs=1,restrict_weights=False,flag_stride=1,arrival='rmw'):","direct_norm=False,poll_sgs=1,restrict_weights=False,flag_stride=1,arrival='rmw',cache_external_inputs=False):",1)
s=s.replace("    if not isinstance(workers,int)","    if type(cache_external_inputs) is not bool:\n        raise ValueError('external input caching must be boolean')\n    if not isinstance(workers,int)",1)
needle='    calls=[];sizes=[];task_calls=[];counts=[]\n'
insert='''    external_inputs=set()
    if cache_external_inputs:
        # A dispatch boundary publishes these inputs. Any non-const device
        # binding in this region makes the entire named buffer mutable,
        # including disjoint offsets; cross-task intermediates stay coherent.
        written=set()
        for i,o in enumerate(p.ops):
            _,pars=stage(p.kernels[o.kernel],i)
            for typ,name,attr in pars:
                if attr.startswith('buffer(') and re.search(r'\\bdevice\\b',typ) and not re.search(r'\\bconst\\b',typ):
                    slot=int(attr[7:-1]);written.add(next(n for s,n,_ in o.bindings if s==slot))
        external_inputs=set(names)-written
'''
assert needle in s;s=s.replace(needle,insert+needle,1)
s=s.replace("p.buffers[next(n for slot,n,off in o.bindings if slot==int(attr[7:-1]))].role=='weights']", "(p.buffers[next(n for slot,n,off in o.bindings if slot==int(attr[7:-1]))].role=='weights' or\n                                                     next(n for slot,n,off in o.bindings if slot==int(attr[7:-1])) in external_inputs)]",1)
s=s.replace("'flag_stride','arrival')", "'flag_stride','arrival','cache_external_inputs')",1)
p.write_text(s)
