from search import *
import search,os
from suffix_search import check_run

def configs(native):
 names=['suffix-native'] if native else ['suffix-mega']
 seeds=leaders(names,3)
 simple=json.loads((R/('smoke-native.json' if native else 'smoke-mega.json')).read_text())
 if simple not in seeds:seeds.append(simple)
 cs=[]
 for b in seeds:
  for cache,once,loads,prefold in itertools.product((False,True) if not native else (False,), (False,True),(4,8,16,32),(False,True)):
   if prefold and once:continue
   cs.append(dict(copy.deepcopy(b),cache_external_inputs=cache,post_norm_once=once,post_norm_loads=loads,post_norm_prefold=prefold))
 return cs
if __name__=='__main__':
 env=os.environ.copy();env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1')
 check_run([sys.executable,'-m','pytest','tests/kernels/test_gdn_default.py','-k','mlp_suffix','-q','-o','addopts='],'postnorm-shader.log',env)
 base=[sys.executable,'tools/bench/modelopt_mlp_suffix_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/target-pack']
 for native in (False,True):
  kind='native' if native else 'mega';cs=configs(native)
  smoke=[cs[0],next(c for c in cs if c['post_norm_prefold'])]
  if not native:smoke.append(dict(smoke[-1],cache_external_inputs=True))
  (R/f'postnorm-{kind}-smoke-configs.json').write_text(json.dumps(smoke,indent=2))
  cmd=base+['--configs',str(R/f'postnorm-{kind}-smoke-configs.json'),'--out',str(R/f'postnorm-{kind}-smoke-shader.jsonl'),'--reps','1','--steps','2']
  if native:cmd+=['--control-only']
  check_run(cmd,f'postnorm-{kind}-smoke-shader.log',env)
  rows=read([f'postnorm-{kind}-smoke-shader']);assert len(rows)==len(smoke) and all('results'in r for r in rows),rows
  search.BASE=base+['--reps','3','--steps','8'];run('postnorm-'+kind,cs,native)
