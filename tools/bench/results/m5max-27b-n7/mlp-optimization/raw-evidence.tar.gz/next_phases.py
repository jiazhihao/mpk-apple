import subprocess,sys
from pathlib import Path
r=Path(__file__).parent
for name in ['combine_search','small_search','worker_search']:
 with (r/(name+'-run.log')).open('w') as log:subprocess.run([sys.executable,str(r/(name+'.py'))],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'done',flush=True)
