from search import *
import search,os
from suffix_search import check_run
if __name__=='__main__':
 env=os.environ.copy();env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1')
 check_run([sys.executable,'-m','pytest','tests/kernels/test_gdn_default.py','-k','mlp_suffix','-q','-o','addopts='],'const-cache-shader.log',env)
 search.BASE=[sys.executable,'tools/bench/modelopt_mlp_suffix_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/target-pack','--reps','3','--steps','8']
 seeds=leaders(['postnorm-mega'],2);cs=[]
 # Revisit all physical occupancy choices with real-boundary winners, plus
 # task scheduling and packing interactions. Dense standalone sweeps remain
 # in the record; this refinement is deliberately local to the winning region.
 for b in seeds:
  for w in [*range(80,161),20,40,60,180,200,220,240,256]:
   cs.append(dict(copy.deepcopy(b),workers=w))
  for cache,once,loads,prefold in itertools.product((False,'const'),(False,True),(4,8,16,32),(False,True)):
   if once and prefold:continue
   cs.append(dict(copy.deepcopy(b),cache_external_inputs=cache,post_norm_once=once,post_norm_loads=loads,post_norm_prefold=prefold))
  for block,unroll in itertools.product((1,4,8,16,32,64),(1,2,4)):
   cs.append(dict(copy.deepcopy(b),nvfp4_tile_block=block,k_unroll=unroll))
  for grain,batch in itertools.product(('group','tile'),(1,2,4,8,16)):
   cs.append(dict(copy.deepcopy(b),schedule='queue',task_grain=grain,task_batch=batch,task_seed=True,task_seed_bound=True))
 run('boundary-mega',cs)
 seeds=leaders(['postnorm-native','suffix-native'],2);cs=[]
 for b in seeds:
  cs.append(b)
  for stage in ('0','1'):
   # Revisit the measured region and useful overdecomposition factors after
   # normalization tuning; both independent projection sweeps are archived.
   for w in [*range(100,181,4),200,240,280,320,400,440,480,640,1088]:
    c=copy.deepcopy(b);c.setdefault('gemm_overrides',{}).setdefault(stage,{})['groups']=w;cs.append(c)
   for block,tk,once,loads in itertools.product((8,16,32,64),(64,128),(False,True),(4,16)):
    c=copy.deepcopy(b);c.setdefault('gemm_overrides',{}).setdefault(stage,{}).update(nvfp4_tile_block=block,staged_tk=tk,post_norm_once=once,post_norm_loads=loads);cs.append(c)
 run('boundary-native',cs,True)
