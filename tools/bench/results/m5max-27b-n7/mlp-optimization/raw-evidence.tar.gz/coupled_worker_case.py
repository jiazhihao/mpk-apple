from pathlib import Path
import sys,json,copy
sys.path.insert(0,'/Users/zhihaojia/lithos/mpk-apple')
import monolith.compiler.mlp_fusion as mf
from tools.bench import modelopt_layer_bench as bench
worker=int(sys.argv.pop(1));original=mf.tune_mlp_suffix

def adapted(program,config,*,mixer_config=None):
 if mixer_config is not None and config.get('mode')=='native':
  mixer_config=dict(copy.deepcopy(mixer_config),workers=worker)
 return original(program,config,mixer_config=mixer_config)
mf.tune_mlp_suffix=adapted
out=Path(sys.argv[sys.argv.index('--out')+1]);status=bench.main()
rows=[json.loads(l) for l in out.read_text().splitlines()]
for x in rows:x['optimized_mlp_native_mixer_override']={'workers':worker}
out.write_text(''.join(json.dumps(x)+'\n' for x in rows))
raise SystemExit(status)
