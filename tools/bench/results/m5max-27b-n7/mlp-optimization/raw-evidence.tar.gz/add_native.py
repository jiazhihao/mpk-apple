from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text()
s=s.replace("if mode not in ('coop','staged'):","if mode not in ('coop','staged','native'):",1)
s=s.replace("(tm!=16 and mode!='coop')","(tm!=16 and mode!='coop')",1)
s=s.replace("mode!='staged' or type(staged_tk)","mode not in ('staged','native') or type(staged_tk)",1)
s=s.replace("layout_tk=staged_tk if mode=='staged' else tk","layout_tk=staged_tk if mode in ('staged','native') else tk",1)
s=s.replace("(mode=='staged' and staged_tk is None)","(mode in ('staged','native') and staged_tk is None)")
s=s.replace("                if mode=='staged':\n                    if staged_tk", "                if mode=='native':\n                    if staged_tk is None:raise ValueError('native tuning requires an explicit reduction tile')\n                    k.macros.update(TM='8',TN=f'{tn}u',TK=f'{staged_tk}u',SCALE_CACHE='0')\n                elif mode=='staged':\n                    if staged_tk",1)
s=s.replace("elif mode=='staged':selection=", "elif mode in ('staged','native'):selection=")
# Native tensor memory accesses cannot communicate intermediate data inside one dispatch.
s=s.replace("    src='#include <metal_stdlib>","    if any('tensor<device bfloat,' in p.kernels[o.kernel].source and p.kernels[o.kernel].function=='gemm_tile' for o in p.ops):\n        raise ValueError('native device tensor projections require dispatch boundaries')\n    src='#include <metal_stdlib>",1)
p.write_text(s)
p=Path('tools/bench/modelopt_mega_tune.py');s=p.read_text()
s=s.replace('from monolith.generate import Session','from monolith.compiler.static_fusion import normalize, _MERGE_OPTIONS\nfrom monolith.generate import Session')
s=s.replace("    ap.add_argument('--reference-config'", "    ap.add_argument('--control-only',action='store_true',help='measure normalized multi-dispatch configurations without fusion')\n    ap.add_argument('--reference-config'",1)
s=s.replace("                control,fused=(fuse_mixer_prefix if kind.endswith('-prefix') else compile_config)(p,cfg)","""                if a.control_only:
                    if kind.endswith('-prefix'):raise ValueError('control-only screen requires a standalone half')
                    control=normalize(p,sgs,groups=workers,**{k:v for k,v in cfg.items() if k not in ('workers','sgs',*_MERGE_OPTIONS)})
                    fused=None
                else:
                    control,fused=(fuse_mixer_prefix if kind.endswith('-prefix') else compile_config)(p,cfg)""")
s=s.replace("                engines['single_kernel'] = Engine(fused,sess.dev,buffers=candidate_weights)","                if fused is not None:engines['single_kernel'] = Engine(fused,sess.dev,buffers=candidate_weights)\n                selected='matched_control' if a.control_only else 'single_kernel'")
s=s.replace("                    assert snap['matched_control']==snap['single_kernel'],'control/fusion hidden mismatch'","                    if not a.control_only:assert snap['matched_control']==snap['single_kernel'],'control/fusion hidden mismatch'")
s=s.replace("engines['single_kernel']", "engines[selected]")
# Restore engine creation target before selected is assigned.
s=s.replace("if fused is not None:engines[selected] = Engine", "if fused is not None:engines['single_kernel'] = Engine")
s=s.replace("snap['single_kernel'],np.uint16)","snap[selected],np.uint16)")
s=s.replace("control_bit_exact=True,replay_bit_exact=True,", "control_bit_exact=not a.control_only,replay_bit_exact=True,selected_engine=selected,")
p.write_text(s)
