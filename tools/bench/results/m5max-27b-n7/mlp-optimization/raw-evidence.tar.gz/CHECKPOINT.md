# MLP study completion checkpoint
All GPU jobs have completed and been reaped. No GPU process remains owned by this study.

4863 adaptive screening trials:4816 accepted,47 rejected. Cached-input suffix worker sweep was pruned after240/514points.80 finalist cases(10recipes×4layers×2modes),36pairedrounds perrecipe. Separate7-point coupledattention-worker diagnostic retained157; allcounts120..157hadfirst-roundslowdown.

SelectednativeMLP:SG4,TN32,TK64,KS4,gate160groups/down640groups,packedNVFP4tileblock32,post_norm_onceTrue. Selectedfused:116workers,SG8,TN32,TK32,KS4,tileblock16,k_unroll2,post_norm_onceTrue. BothcacheFalse,prefoldFalse. SingleMLPconfigpermode acrosscontexts; noautomaticgenerationpromotion.

Finalperformance:64standaloneMLPs +128complete-layer/contextcases,9x32. Everychosenvariant beatsfastesttestedMLX in1728/1728pairs. Standaloneoriginal318.4759us,native288.8535us(-9.3%),fused298.0781us(-6.4%),MLX675.8763us. Fused/native1.03169medianratio. Allstandalonepairsbeat original. Complete native32Khasoneoriginal-loss(143/144)butstill144/144vsMLX. Retainedrepeatlayer15has8/9originalwinsand9/9MLXwins. First-roundslowdown persists across7attentionworkerchoices; absentinMonolith-onlydiagnostic(native1246.2–1252.0us). Exactcache/residency/schedulingcausenotestablished. Originaldatasetsnotreplaced.

1042sharedshader-tests passed,1optionalFastAPIskip. All80real-modelshadercasespass,alloracles/replays/control-fusionbitidentityverified. Sourcefrozenbeforefinaltests. Additionaldiagnosticschangeonlyconfiguration,notrepositorykernelcode.

Report:docs/research/m5max-27b-mlp-optimization.md. Evidence:tools/bench/results/m5max-27b-n7/mlp-optimization. BenchREADMEupdated. archive_results.py packagesallrawtext(no binaryweights/caches),selectedconfigs,contextmap,source/artifacthashes; write_report.py reproducesreportfromsummaries. audit_geometry.py reportslogicaltilecountsfromeffectiveparameters,notphysicalcoreutilization.

No commit,push,PR,GitHubcomment,MLPdefaultchange. ExistingGDN/attentionworkpreserved. Final steps at checkpoint creation: regeneratearchive/reportafterfinalnotes,verifyhashes/links/numbers/gitdiff--check,openreportanddeliverconciseresult.
