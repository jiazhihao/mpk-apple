from search import *
if __name__=='__main__':
 mega_names=['global-mega','stage-mega','combined-mega','small-mega']
 native_names=['global-native','stage-native','combined-native','small-native']
 mega_names=[n for n in mega_names if (R/(n+'.jsonl')).exists()]
 native_names=[n for n in native_names if (R/(n+'.jsonl')).exists()]
 ms=leaders(mega_names,2);ns=leaders(native_names,1)
 (R/'worker-mega-seeds.json').write_text(json.dumps(ms,indent=2));(R/'worker-native-seeds.json').write_text(json.dumps(ns,indent=2))
 run('worker-mega',[dict(copy.deepcopy(b),workers=w) for b in ms for w in range(1,257)])
 cs=[]
 for b in ns:
  for stage in ('0','1'):
   for w in [*range(1,513),640,768,1024,1088,2176,4096]:
    c=copy.deepcopy(b);c.setdefault('gemm_overrides',{}).setdefault(stage,{})['groups']=w;cs.append(c)
 run('worker-native',cs,True)
