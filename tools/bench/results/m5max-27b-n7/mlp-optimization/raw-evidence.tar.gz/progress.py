from pathlib import Path
import json,numpy as np
r=Path(__file__).parent
for name in ['all64-mlp',*[f'all-layers-{c}' for c in (128,4096,8192,16384,32768)]]:
 p=r/(name+'.jsonl')
 if not p.exists():continue
 rows=[json.loads(l) for l in p.read_text().splitlines()]
 if not rows:continue
 stats={}
 for n in ('optimized_mlp','optimized_mlp_native'):
  original=[];mlx=[];current=[]
  for x in rows:
   for i,a in enumerate(x['samples'][n]):
    original.append(a['wall_us']<x['samples']['production'][i]['wall_us'])
    mlx.append(a['wall_us']<min(v[i]['wall_us'] for k,v in x['samples'].items() if k.startswith('mlx')))
    if 'megakernel'in x['samples']:current.append(a['wall_us']<x['samples']['megakernel'][i]['wall_us'])
  stats[n]=dict(original=sum(original),mlx=sum(mlx),pairs=len(original),current=sum(current) if current else None,median_min_us=float(np.median([x['results'][n]['min_wall_us'] for x in rows])))
 print(name,len(rows),all(x['oracle_pass'] for x in rows),json.dumps(stats))
