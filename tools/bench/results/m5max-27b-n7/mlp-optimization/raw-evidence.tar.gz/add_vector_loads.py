from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text().replace('nvfp4_prefetch=0):','nvfp4_prefetch=0, nvfp4_vector_loads=False):',1)
s=s.replace("    if type(nvfp4_prefetch)","    if type(nvfp4_vector_loads) is not bool or (nvfp4_vector_loads and nvfp4_layout!='tile'):\n        raise ValueError('vector operand loads require packed NVFP4')\n    if type(nvfp4_prefetch)",1)
s=s.replace('nvfp4_prefetch=nvfp4_prefetch)', 'nvfp4_prefetch=nvfp4_prefetch,nvfp4_vector_loads=nvfp4_vector_loads)',1)
s=s.replace('scale_base,nvfp4_operand,nvfp4_prefetch)','scale_base,nvfp4_operand,nvfp4_prefetch,nvfp4_vector_loads)',1)
p.write_text(s)
p=Path('monolith/compiler/nvfp4_tiles.py');s=p.read_text().replace('prefetch=0):','prefetch=0, vector_loads=False):',1)
s+='''
    if vector_loads and not prefetch:
        start=kernel.source.index('        uint4 words[NW];',kernel.source.index('const ulong packed_group='))
        end=kernel.source.index('        }',start)+len('        }')
        original=kernel.source[start:end]
        replacement='''+repr('''        uint4 words[NW];
#if CT >= 32
#pragma clang loop unroll(full)
        for(uint i=0;i<NW;i++) words[i]=w[((packed_group*NS_B+s)*32u+lane)*NW+i];
#elif CT == 16
        uint2 codes=reinterpret_cast<device const uint2*>(w)[(packed_group*NS_B+s)*32u+lane];
        words[0]=uint4(codes.x,codes.y,0u,0u);
#else
        words[0]=uint4(reinterpret_cast<device const uint*>(w)[(packed_group*NS_B+s)*32u+lane],0u,0u,0u);
#endif
''')+'''
        kernel.source=kernel.source[:start]+replacement+kernel.source[end:]
'''
p.write_text(s)
