"""Final comparisons only; invoke after selecting and validating recipes."""
from pathlib import Path
import subprocess,sys,json,os
r=Path(__file__).parent
base=[sys.executable,'tools/bench/modelopt_layer_bench.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--capacity','33024','--mlp-config',str(r/'selected-mega.json'),'--mlp-control-config',str(r/'selected-native.json')]
def run(name,args,shader=False):
 cmd=base+args+['--out',str(r/(name+'.jsonl'))]
 env=os.environ.copy()
 if shader:env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1')
 with (r/(name+'.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
 print(name,'done',flush=True)
if __name__=='__main__':
 run('all64-mlp',['--part','mlp','--layers','all','--ctx','128','--reps','9','--steps','32','--fp8-mode','mxfp8'])
 for ctx in (128,4096,8192,16384,32768):
  layers='all' if ctx==128 else ','.join(map(str,range(3,64,4)))
  run(f'all-layers-{ctx}',['--part','layer','--layers',layers,'--ctx',str(ctx),'--fusion','--fusion-scope','mixer-prefix','--config',str(r/f'mixers-{ctx}.json'),'--reps','9','--steps','32','--fp8-mode','both','--mlx-cache-lifetime','both'])
 run('all64-mlp-shader',['--part','mlp','--layers','all','--ctx','128','--reps','1','--steps','2','--fp8-mode','mxfp8'],True)
 for ctx in (128,4096,8192,16384,32768):
  run(f'integration-final-{ctx}-shader',['--part','layer','--layers','0,3,31,63' if ctx==128 else '3,31,63','--ctx',str(ctx),'--fusion','--fusion-scope','mixer-prefix','--config',str(r/f'mixers-{ctx}.json'),'--reps','1','--steps','2','--fp8-mode','mxfp8'],True)
