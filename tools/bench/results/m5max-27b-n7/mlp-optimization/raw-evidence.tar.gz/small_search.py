from search import *
if __name__=='__main__':
 cs=[]
 for s,w,tn,tm,ks in itertools.product((4,8,16,32),(40,80,120),(16,32),(16,32),(4,8,16,32)):
  if ks>s or (tn==16 and tm==16):continue
  cs.append(dict(workers=w,sgs=s,tn=tn,tm=tm,tk=16,ksplit=ks,compact=True,nvfp4_layout='tile',nvfp4_tile_block=8,barrier='simd'))
 run('small-mega',cs)
 cs=[]
 for s,w,tn,q,vector in itertools.product((2,4,8,16),(80,160,320),(16,32,64,128),(0,1),(False,True)):
  cs.append(dict(workers=w,sgs=s,tn=tn,ksplit=s,compact=True,mode='native',staged_tk=32,nvfp4_layout='tile',nvfp4_tile_block=8,q_outer=q,nvfp4_vector_loads=vector))
 run('small-native',cs,True)
