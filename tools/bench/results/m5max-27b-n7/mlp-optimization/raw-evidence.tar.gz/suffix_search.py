from search import *
import search,os

def check_run(cmd,log,env=None):
 with (R/log).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,check=True)

def combine_groups():
 rs=[r for r in read(['worker-native']) if 'results'in r]
 seed=json.loads((R/'worker-native-seeds.json').read_text())[0]
 opts=[]
 for stage in ('0','1'):
  ss=[r for r in rs if r['config'].get('gemm_overrides',{}).get(stage,{}).get('groups')!=seed.get('gemm_overrides',{}).get(stage,{}).get('groups')]
  values=[]
  for metric in ('absolute','median','worst'):
   for row in sorted(ss,key=lambda r:score(r,metric))[:3]:
    value=row['config']['gemm_overrides'][stage]['groups']
    if value not in values:values.append(value)
  opts.append(values)
 cs=[]
 for a,b in itertools.product(*opts):
  c=copy.deepcopy(seed)
  for stage,w in [('0',a),('1',b)]:c.setdefault('gemm_overrides',{}).setdefault(stage,{})['groups']=w
  cs.append(c)
 return cs

if __name__=='__main__':
 env=os.environ.copy();env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1')
 check_run([sys.executable,'-m','pytest','-q','tests/kernels/test_gdn_default.py','-k','mlp_suffix'],'external-cache-shader.log',env)
 base=[sys.executable,'tools/bench/modelopt_mlp_suffix_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/target-pack']
 smoke=[json.loads((R/'smoke-mega.json').read_text())]
 smoke.append(dict(smoke[0],cache_external_inputs=True))
 (R/'suffix-smoke-configs.json').write_text(json.dumps(smoke,indent=2))
 check_run(base+['--configs',str(R/'suffix-smoke-configs.json'),'--out',str(R/'suffix-smoke-shader.jsonl'),'--reps','1','--steps','2'],'suffix-smoke-shader.log',env)
 rows=read(['suffix-smoke-shader']);assert len(rows)==len(smoke) and all('results'in r for r in rows),rows
 search.BASE=base+['--reps','3','--steps','8']
 seeds=leaders(['worker-mega','combined-mega','global-mega'],3)
 cs=[dict(copy.deepcopy(b),cache_external_inputs=cache) for b in seeds for cache in (False,True)]
 # Dense workers on the best measured configuration at the real producer boundary.
 for b in seeds[:2]:
  for w in range(1,257):cs.append(dict(copy.deepcopy(b),workers=w,cache_external_inputs=True))
 run('suffix-mega',cs)
 cs=combine_groups()+leaders(['worker-native','combined-native','global-native'],3)
 run('suffix-native',cs,True)
