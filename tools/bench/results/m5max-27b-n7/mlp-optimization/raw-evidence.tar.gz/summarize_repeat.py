from pathlib import Path
import json
r=Path(__file__).parent;p=r/'repeat-32k.jsonl'
if p.exists():
 rows=[json.loads(l) for l in p.read_text().splitlines()];pairs=sum(x['reps'] for x in rows)
 out=dict(layers=[x['layer'] for x in rows],pairs=pairs,all_oracles_pass=all(x['oracle_pass'] for x in rows),native_original_wins=sum(a['wall_us']<b['wall_us'] for x in rows for a,b in zip(x['samples']['optimized_mlp_native'],x['samples']['production'])),native_mlx_wins=sum(x['samples']['optimized_mlp_native'][i]['wall_us']<min(v[i]['wall_us'] for n,v in x['samples'].items() if n.startswith('mlx')) for x in rows for i in range(x['reps'])),samples_retained=True)
 assert out['all_oracles_pass'];(r/'repeat-32k-summary.json').write_text(json.dumps(out,indent=2));print(out)
