from pathlib import Path
import json,collections
r=Path(__file__).parent
names=['geometry','packing','native','packed-geometry','global-mega','global-native','stage-mega','stage-native','combined-mega','combined-native','small-mega','small-native','worker-mega','worker-native','suffix-mega','suffix-native','postnorm-mega','postnorm-native','boundary-mega','boundary-native']
phases=[];domains=collections.defaultdict(set)
for name in names:
 path=r/(name+'.jsonl')
 if not path.exists():continue
 rows=[json.loads(l) for l in path.read_text().splitlines()];accepted=[x for x in rows if 'results'in x]
 cfgpath=r/(name+'-configs.json')
 planned=len(json.loads(cfgpath.read_text())) if cfgpath.exists() else len(rows)
 phases.append(dict(phase=name,planned=planned,trials=len(rows),accepted=len(accepted),rejected=len(rows)-len(accepted),errors=dict(collections.Counter(x['error'].split('\n')[0][:220] for x in rows if 'error'in x))))
 for x in rows:
  def visit(c,prefix=''):
   for k,v in c.items():
    if isinstance(v,dict):visit(v,prefix+k+'.')
    else:domains[prefix+k].add(json.dumps(v,sort_keys=True))
  visit(x['config'])
summary=dict(total_trials=sum(x['trials'] for x in phases),accepted=sum(x['accepted'] for x in phases),rejected=sum(x['rejected'] for x in phases),phases=phases,observed_domains={k:[json.loads(x) for x in sorted(v)] for k,v in sorted(domains.items())},scope='Adaptive finite search, not a full Cartesian product or proof of global optimality. Dense worker sweeps and all attempted configurations retained.')
(r/'coverage.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='observed_domains'},indent=2))
