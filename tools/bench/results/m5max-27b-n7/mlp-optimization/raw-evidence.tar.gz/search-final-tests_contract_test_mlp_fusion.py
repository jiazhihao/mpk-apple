"""MLP tensor-layout boundaries and unsupported combinations fail before GPU work."""
import pytest
from monolith.runtime.program import Program,KernelSpec,OpSpec
from monolith.compiler.mlp_fusion import repair_projection_layouts
from monolith.compiler.static_fusion import normalize,merge


def test_independent_projection_layouts_update_only_their_producers():
    p=Program({'producer':KernelSpec('','gemm_tile',dict(TK='128u',PERM_OUT='1',PERM_TK='128u')),
               'consumer':KernelSpec('','gemm_tile',dict(TK='64u'))}, {},
              [OpSpec('producer',[(2,'hidden',0),(3,'middle',0)],(1,1,1),(128,1,1)),
               OpSpec('consumer',[(2,'middle',0)],(1,1,1),(128,1,1))])
    repair_projection_layouts(p)
    assert p.kernels[p.ops[0].kernel].macros['PERM_TK']=='64u'
    assert p.kernels['producer'].macros['PERM_TK']=='128u'


def test_shared_input_rejects_incompatible_consumers():
    p=Program({n:KernelSpec('','gemm_tile',dict(TK=tk)) for n,tk in [('a','64u'),('b','128u')]},{},
        [OpSpec(n,[(2,'shared',0)],(1,1,1),(128,1,1)) for n in ('a','b')])
    with pytest.raises(ValueError,match='shared activation'):repair_projection_layouts(p)


def test_device_tensor_mlp_cannot_be_merged():
    p=Program({'a':KernelSpec('','gemm_tile',dict(STATIC_NATIVE_TENSOR='1'))},{},[OpSpec('a',[],(1,1,1),(128,1,1))])
    with pytest.raises(ValueError,match='dispatch boundaries'):merge(p,4,4)


@pytest.mark.parametrize('config',[
 {'nvfp4_layout':'unknown'}, {'nvfp4_layout':'tile','nvfp4_tile_block':3},
 {'nvfp4_operand':'half4'}, {'nvfp4_layout':'tile','nvfp4_operand':'bad'},
 {'nvfp4_layout':'tile','nvfp4_prefetch':8}, {'nvfp4_layout':'tile','nvfp4_prefetch':True},
 {'nvfp4_layout':'tile','nvfp4_prefetch':1,'mode':'native','staged_tk':128},
 {'nvfp4_vector_loads':True}, {'nvfp4_layout':'tile','nvfp4_vector_loads':1},
 {'nvfp4_layout':'tile','narrow_weights':True}, {'nvfp4_scale_mode':'duplicated'}])
def test_invalid_nvfp4_layout_is_rejected(config):
    with pytest.raises(ValueError):normalize(Program({}, {}, []),4,**config)
