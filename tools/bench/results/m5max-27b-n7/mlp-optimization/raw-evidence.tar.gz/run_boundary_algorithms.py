from search import *
import search
from suffix_search import combine_groups
search.BASE=[sys.executable,'tools/bench/modelopt_mlp_suffix_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/target-pack','--reps','3','--steps','8']
run('suffix-native',combine_groups()+leaders(['worker-native','combined-native','global-native'],3),True)
with (R/'postnorm_search-run.log').open('w') as f:subprocess.run([sys.executable,str(R/'postnorm_search.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
