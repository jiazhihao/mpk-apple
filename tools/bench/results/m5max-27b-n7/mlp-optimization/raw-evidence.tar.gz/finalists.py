from search import *
import search

def candidates(native):
 names=(['native','global-native','stage-native','combined-native','small-native','worker-native','local-native','suffix-native','postnorm-native','boundary-native'] if native else
        ['packing','packed-geometry','global-mega','stage-mega','combined-mega','small-mega','worker-mega','local-mega','suffix-mega','postnorm-mega','boundary-mega'])
 names=[n for n in names if n.startswith(('suffix-','postnorm-','boundary-')) and (R/(n+'.jsonl')).exists()]
 rs=read(names);bad={json.dumps(r['config'],sort_keys=True) for r in rs if 'error'in r}
 rs=[r for r in rs if 'results'in r and json.dumps(r['config'],sort_keys=True) not in bad]
 cs=[]
 for metric in ('absolute','median','worst'):
  for row in sorted(rs,key=lambda r:score(r,metric))[:3]:
   if row['config'] not in cs:cs.append(row['config'])
 # Always retain a previously validated simple configuration as a stability control.
 simple=json.loads((R/('smoke-native.json' if native else 'smoke-mega.json')).read_text())
 if simple not in cs:cs.append(simple)
 return cs
if __name__=='__main__':
 search.BASE=[sys.executable,'tools/bench/modelopt_mlp_suffix_tune.py','--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/target-pack']
 for native in (False,True):
  cs=candidates(native);kind='native' if native else 'mega'
  (R/(kind+'-finalists.json')).write_text(json.dumps(cs,indent=2))
  for layer in (0,15,31,63):run(f'finalists-{kind}-layer{layer}',cs,native,reps=9,steps=32,layer=layer)
