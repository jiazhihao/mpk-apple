from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text()
s=s.replace('attention_compact_partials=False):','attention_compact_partials=False, nvfp4_layout="blm", nvfp4_tile_block=1, nvfp4_scale_mode="shared"): ',1)
needle="    if mode not in ('coop','staged'):"
insert='''    if (nvfp4_layout not in ('blm','tile') or nvfp4_scale_mode not in ('shared','duplicated') or
            type(nvfp4_tile_block) is not int or nvfp4_tile_block not in (1,2,4,8,16,32,64,128,256,512) or
            (nvfp4_layout=='blm' and (nvfp4_tile_block!=1 or nvfp4_scale_mode!='shared')) or
            (nvfp4_layout=='tile' and (narrow_weights or tk!=32 or (mode=='staged' and staged_tk is None)))):
        raise ValueError('unsupported NVFP4 operand layout')
'''
s=s.replace(needle,insert+needle,1)
s=s.replace('attention_alias_scratch=attention_alias_scratch,attention_compact_partials=attention_compact_partials)', 'attention_alias_scratch=attention_alias_scratch,attention_compact_partials=attention_compact_partials,\n                    nvfp4_layout=nvfp4_layout,nvfp4_tile_block=nvfp4_tile_block,nvfp4_scale_mode=nvfp4_scale_mode)',1)
s=s.replace('    changed=set()','''    if nvfp4_layout=='tile':
        from . import nvfp4_tiles
        nvfp4_rows=nvfp4_tiles.projection_rows(p)
        nvfp4_repacked={}
    changed=set()''',1)
needle='            if layout_tk is not None:\n                pname='
insert='''            if nvfp4_layout=='tile' and '#ifndef NVFP4_DECODE' in k.source:
                binding=next((name,off) for slot,name,off in o.bindings if slot==0)
                layout_key=(binding,tuple(sorted(k.macros.items())))
                if layout_key not in nvfp4_repacked:
                    nvfp4_repacked[layout_key]=nvfp4_tiles.repack(p,binding,k.macros,nvfp4_rows[binding],tn,
                        int(k.macros['TK'].rstrip('u')),nvfp4_tile_block,nvfp4_scale_mode)
                name,spec,scale_base=nvfp4_repacked[layout_key]
                p.buffers[name]=spec
                o.bindings=[(slot,name,0) if slot==0 else (slot,n,off) for slot,n,off in o.bindings]
                if 'NVFP4_SCALE_BASE' not in k.macros:
                    nvfp4_tiles.specialize_source(k,nvfp4_tile_block,nvfp4_scale_mode,scale_base)
'''
assert needle in s;s=s.replace(needle,insert+needle,1)
p.write_text(s)
