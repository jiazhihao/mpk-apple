from pathlib import Path
import json,hashlib,shutil,tarfile,subprocess
r=Path(__file__).parent
repo=Path('/Users/zhihaojia/lithos/mpk-apple')
out=repo/'tools/bench/results/m5max-27b-n7/mlp-optimization';out.mkdir(parents=True,exist_ok=True)
sources=['monolith/compiler/static_fusion.py','monolith/compiler/mlp_fusion.py','monolith/compiler/nvfp4_tiles.py','monolith/compiler/fp8_tiles.py','kernels/gemm_tile.metal','tools/bench/modelopt_layer_bench.py','tools/bench/modelopt_mega_tune.py','tools/bench/modelopt_mlp_suffix_tune.py','tools/bench/modelopt_mlx.py','tests/contract/test_nvfp4_tiles.py','tests/contract/test_mlp_fusion.py','tests/kernels/test_mlp_block_static.py','tests/kernels/test_gdn_default.py','profiles/apple-m5-max-40c.json']
manifest={}
for name in sources:
 data=(repo/name).read_bytes();manifest[name]=hashlib.sha256(data).hexdigest();(r/('final-source-'+name.replace('/','_'))).write_bytes(data)
manifest=dict(source_sha256=manifest,branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),dirty_tree=True,model_revision='482ca0f3832238542f8f5295dde86b5f22711d80')
(r/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
for name in ['selected-mega.json','selected-native.json','selection-mega.json','selection-native.json','final.summary.json','final.csv','validation.json','coverage.json','weight-traffic.json','source-manifest.json','study-plan.json','suffix-pruning.json','task-audit.jsonl','task-audit.json','repeat-32k-summary.json','repeat-outliers-plan.json','coupled-workers-summary.json','coupled-workers-plan.json','monolith-only-32k.jsonl']:
 if (r/name).exists():shutil.copy2(r/name,out/name)
# Reuse the previous attention context map instead of duplicating mixer recipes.
(out/'selected-contexts.json').write_text(json.dumps(dict(mlp_native='selected-native.json',mlp_megakernel='selected-mega.json',attention_contexts='../attention-optimization/selected-contexts.json',gdn_profile='../../../../../profiles/apple-m5-max-40c.json',contexts=[128,4096,8192,16384,32768],scope='Explicit fixed-eight-row compiler/benchmark recipes; MLP is not automatically selected by generation.'),indent=2))
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as tar:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in ('.py','.json','.jsonl','.log','.md','.metal','.txt','.csv','.xml'):
   tar.add(p,arcname=p.name)
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='artifact-sha256.json'}
(out/'artifact-sha256.json').write_text(json.dumps(files,indent=2))
print(out)
