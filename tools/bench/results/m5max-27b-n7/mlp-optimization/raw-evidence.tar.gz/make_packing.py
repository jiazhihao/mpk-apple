from pathlib import Path
import json,itertools
r=Path(__file__).parent;c=[]
for s,w,tn in [(8,80,32),(16,40,32),(16,80,32),(32,20,32),(32,40,32),(32,40,16)]:
 for block,scale in itertools.product((1,4,8,16,64),('shared','duplicated')):
  c.append(dict(workers=w,sgs=s,tn=tn,ksplit=s,compact=True,barrier='simd',nvfp4_layout='tile',nvfp4_tile_block=block,nvfp4_scale_mode=scale))
for s,tn,tk in itertools.product((4,8),(16,32),(64,128,256)):
 c.append(dict(workers=80,sgs=s,tn=tn,ksplit=s,compact=True,mode='staged',staged_tk=tk,barrier='simd',nvfp4_layout='tile',nvfp4_tile_block=8))
(r/'packing-configs.json').write_text(json.dumps(c,indent=2));print(len(c))
