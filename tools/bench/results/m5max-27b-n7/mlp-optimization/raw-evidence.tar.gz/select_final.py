from search import *

def choose(native):
 kind='native' if native else 'mega';rs=read([f'finalists-{kind}-layer{i}' for i in (0,15,31,63)])
 grouped={}
 for row in rs:grouped.setdefault(json.dumps(row['config'],sort_keys=True),[]).append(row)
 scores=[]
 for key,rows in grouped.items():
  rec=dict(config=json.loads(key),layers=[r['layer'] for r in rows],errors=[r['error'] for r in rows if 'error'in r])
  good=[r for r in rows if 'results'in r]
  if len(good)!=4 or rec['errors']:rec['eligible']=False;scores.append(rec);continue
  paired=[];mins=[]
  for r in good:
   name=r.get('selected_engine','single_kernel')
   paired.extend(a['wall_us']/b['wall_us'] for a,b in zip(r['samples'][name],r['samples']['production']))
   mins.append(r['results'][name]['wall_us']/r['results']['production']['wall_us'])
  rec.update(median_paired_ratio=float(np.median(paired)),worst_paired_ratio=max(paired),median_min_ratio=float(np.median(mins)),paired_wins=sum(v<1 for v in paired),paired_count=len(paired),eligible=all(v<1 for v in paired))
  scores.append(rec)
 valid=[s for s in scores if s.get('eligible')]
 if not valid:raise RuntimeError(f'No {kind} finalist beats original in every paired round')
 fastest=min(s['median_paired_ratio'] for s in valid)
 near=[s for s in valid if s['median_paired_ratio']<=fastest*1.02]
 worst=min(s['worst_paired_ratio'] for s in near)
 stable=[s for s in near if s['worst_paired_ratio']<=worst*1.03]
 winner=min(stable,key=lambda s:(s['median_paired_ratio'],len(json.dumps(s['config']))))
 (R/f'selected-{kind}.json').write_text(json.dumps(winner['config'],indent=2))
 (R/f'selection-{kind}.json').write_text(json.dumps(dict(policy='All36 pairs faster than original; within2% fastest median paired ratio; worst ratio within3% of best within that set; minimize median ratio.',winner=winner,finalists=scores),indent=2))
 print(kind,winner,flush=True)
if __name__=='__main__':
 choose(False);choose(True)
