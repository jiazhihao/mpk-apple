import json,sys
from pathlib import Path
import numpy as np
root=Path(__file__).parent
rows=[]
for file in sys.argv[1:]:
 p=root/file
 rs=[json.loads(l) for l in p.read_text().splitlines()]
 good=[r for r in rs if 'results' in r]
 print(p.name,'total',len(rs),'pass',len(good),'reject',len(rs)-len(good))
 rows+=good
for r in sorted(rows,key=lambda r:r['results'][r.get('selected_engine','single_kernel')]['gpu_us']/r['results']['production']['gpu_us'])[:12]:
 print(round(r['results'][r.get('selected_engine','single_kernel')]['gpu_us']/r['results']['production']['gpu_us'],3),{k:round(v['gpu_us'],2) for k,v in r['results'].items()},r['config'])
