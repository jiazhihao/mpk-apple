from pathlib import Path
import sys,json,subprocess,random
r=Path(__file__).parent
workers=[120,140,144,148,152,156,157];random.Random(141).shuffle(workers)
(r/'coupled-workers-plan.json').write_text(json.dumps(dict(workers=workers,layers=[15],ctx=32768,reps=9,steps=32,scope='Only the independently tuned native MLP engine gets the mixer-worker override. Original, previous mixer, fused MLP and MLX references remain unchanged. Original spike datasets retained.'),indent=2))
for worker in workers:
 name=f'coupled-workers-{worker}'
 cmd=[sys.executable,str(r/'coupled_worker_case.py'),str(worker),'--model','/tmp/monolith-models/Qwen3.8-27B-NVFP4','--pack','/tmp/monolith-m5max/attention-tasks/pack-33k','--capacity','33024','--part','layer','--layers','15','--ctx','32768','--fusion','--fusion-scope','mixer-prefix','--config',str(r/'mixers-32768.json'),'--mlp-config',str(r/'selected-mega.json'),'--mlp-control-config',str(r/'selected-native.json'),'--reps','9','--steps','32','--fp8-mode','both','--mlx-cache-lifetime','both','--out',str(r/(name+'.jsonl'))]
 with (r/(name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 x=json.loads((r/(name+'.jsonl')).read_text().splitlines()[0]);assert x['oracle_pass']
 print(worker,x['results']['optimized_mlp_native'],[round(s['wall_us'],1) for s in x['samples']['optimized_mlp_native']],flush=True)
