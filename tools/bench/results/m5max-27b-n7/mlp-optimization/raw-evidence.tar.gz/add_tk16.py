from pathlib import Path
p=Path('monolith/compiler/nvfp4_tiles.py');s=p.read_text()
s=s.replace('tk not in (32,64,128,256)','tk not in (16,32,64,128,256)',1)
s=s.replace("*(2 if tk==32 and scale_mode=='duplicated' else 1)","*(max(1,64//tk) if scale_mode=='duplicated' else 1)",1)
s=s.replace("source_lane=q[None,:,None,None,None]*(tk//32)+bytecol//16\n        byte=j[None,:,None,None,None]*16+bytecol%16", "physical=q[None,:,None,None,None]*(tk//2)+bytecol\n        source_lane=physical//16\n        byte=j[None,:,None,None,None]*16+physical%16")
s=s.replace("sl=q[None,:,None,None,None]*(tk//32)+col//32\n            group=j[None,:,None,None,None]*2+(col%32)//16", "physical=q[None,:,None,None,None]*tk+col\n            sl=physical//32\n            group=j[None,:,None,None,None]*2+(physical%32)//16")
s=s.replace("sl=q[None,:,None,None]*(tk//32)+col//32\n            group=j[None,:,None,None]*2+(col%32)//16", "physical=q[None,:,None,None]*tk+col\n            sl=physical//32\n            group=j[None,:,None,None]*2+(physical%32)//16")
# v2 preserves old bytes for TK>=32; TK16 identities are new, so old content cache remains valid.
needle="    if operand!='standard':"
insert="""    if int(kernel.macros['TK'].rstrip('u'))==16:
        start=fill.index('        uint4 words[NW];')
        stop=fill.index('        }',start)+len('        }')
        fill=fill[:start]+'''        uint4 words[1]={uint4(reinterpret_cast<device const ushort*>(w)[(packed_group*NS_B+s)*32u+lane],0u,0u,0u)};
'''+fill[stop:]
        kernel.source=kernel.source.replace('#define LPT (TK / WPW)','#define LPT ((TK + WPW - 1u) / WPW)')
        kernel.source=kernel.source.replace('const uint kp = j * (32u / LPT) + q;',
            'const uint kp = Q_OUTER ? (kt % PAYLOAD_WORDS)*(1024u/TK)+kt/PAYLOAD_WORDS : kt;')
        # The substitutions before the operand body shift its original offsets.
        begin=kernel.source.index('#pragma clang loop unroll(full)\\n      for (uint s = 0; s < NS_B; s++)')
        end=kernel.source.index('#if EXP_MODE == 2\\n      }',begin)
"""
assert needle in s;s=s.replace(needle,insert+needle,1)
s=s.replace('if vector_loads and not prefetch:',"if vector_loads and not prefetch and int(kernel.macros['TK'].rstrip('u'))!=16:")
p.write_text(s)
p=Path('monolith/compiler/static_fusion.py');s=p.read_text().replace('tk not in (32,64,128,256)','tk not in (16,32,64,128,256)',1)
s=s.replace("staged_tk not in (64,128,256)","(staged_tk not in (64,128,256) and not (mode=='native' and nvfp4_layout=='tile' and staged_tk==32))",1)
s=s.replace("if word is None or int(word[1]) not in (8,16):", "if word is None or (int(word[1]) not in (8,16) and nvfp4_layout!='tile'):",1)
# No speculative BLM quarter-word loads survive the packed operand replacement.
p.write_text(s)
p=Path('tests/contract/test_nvfp4_tiles.py');s=p.read_text().replace("'tk', [32,64,128,256]", "'tk', [16,32,64,128,256]",1)
s=s.replace("source_col=(q*(tk//32)+col//32)*(width//32)+j*32+col%32", "source_col=((q*tk+col)//32)*(width//32)+j*32+(q*tk+col)%32")
s=s.replace("*max(1,tk//64)+e//16", "*max(1,tk//64)+e//16")
p.write_text(s)
