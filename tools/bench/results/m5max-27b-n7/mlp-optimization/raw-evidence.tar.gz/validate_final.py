from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
r=Path(__file__).parent
names=['all64-mlp',*[f'all-layers-{c}' for c in (128,4096,8192,16384,32768)],'all64-mlp-shader',*[f'integration-final-{c}-shader' for c in (128,4096,8192,16384,32768)]]
sets={};metrics=[]
for name in names:
 rows=[json.loads(l) for l in (r/(name+'.jsonl')).read_text().splitlines()]
 count=64 if name.startswith('all64') or name=='all-layers-128' else 16 if name.startswith('all-layers') else 4 if name=='integration-final-128-shader' else 3
 assert len(rows)==count,(name,len(rows),count)
 assert all(x['oracle_pass'] and x['checks']['replay_bit_exact'] for x in rows),name
 assert len({(x['layer'],x['ctx']) for x in rows})==len(rows),name
 for x in rows:
  assert x['checks']['optimized_mlp_control_bit_exact'],(name,x['layer'])
  metrics += [dict(dataset=name,layer=x['layer'],check=k,**v) for k,v in x['checks'].items() if isinstance(v,dict)]
 sets[name]=dict(cases=len(rows),all_oracles_pass=True,control_bit_exact=True,replay_bit_exact=True)
xml=ET.parse(r/'shared-shader-regressions.xml').getroot()
suites=list(xml) if xml.tag=='testsuites' else [xml]
tests={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
assert tests['failures']==tests['errors']==0,tests
validation=dict(datasets=sets,shared_tests=tests,numerical=dict(minimum_cosine=min(x['cosine'] for x in metrics),maximum_relative_l2=max(x['relative_l2'] for x in metrics),all_finite=all(x['finite'] for x in metrics)),metrics=metrics)
(r/'validation.json').write_text(json.dumps(validation,indent=2))
print(json.dumps({k:v for k,v in validation.items() if k!='metrics'},indent=2))
