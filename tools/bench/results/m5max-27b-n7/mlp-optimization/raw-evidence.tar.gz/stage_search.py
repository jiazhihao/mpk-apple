from search import *

def stage_search(native):
 names=['native','global-native'] if native else ['geometry','packing','packed-geometry','global-mega']
 seeds=leaders(names,2);cs=[]
 for b in seeds:
  cs.append(b)
  for stage in range(2):
   opts=[]
   for tn,ks,q in itertools.product((16,32,64,128) if native else (16,32),(k for k in (1,2,4,8,16,32) if k<=b['sgs']),(0,1)):
    opts.append(dict(tn=tn,ksplit=ks,q_outer=q))
   for key,values in dict(groups=(20,40,60,80,100,120,160,200,240,320,480,640,1088,2176),nvfp4_tile_block=(1,2,4,8,16,32,64,128,256,512),decode=range(4),nvfp4_operand=('standard','half','half2','half4','float4'),k_unroll=(1,2,4,8),compact=(False,True),nvfp4_scale_mode=('shared','duplicated'),nvfp4_vector_loads=(False,True)).items():
    opts += [{key:value} for value in values]
   if native:opts += [dict(staged_tk=tk) for tk in (64,128,256)]
   else:opts += [dict(nvfp4_prefetch=d) for d in (0,1,2,4)]
   for option in opts:
    c=copy.deepcopy(b);c.setdefault('gemm_overrides',{})[str(stage)]=option;cs.append(c)
  if native:
   for sg,ks,tn,w,tk in itertools.product((1,16,32),(1,2,4,8,16),(16,32),(40,80,160),(64,128)):
    if ks>sg or (17408//tk)%ks:continue
    cs.append(dict(b,sgs=sg,ksplit=ks,tn=tn,workers=w,staged_tk=tk,nvfp4_vector_loads=True,scalar_sgs=min(b.get('scalar_sgs',sg),sg)))
  else:
   for d,operand,q in itertools.product((1,2,4),('standard','half4'),(0,1)):
    cs.append(dict(b,nvfp4_prefetch=d,nvfp4_operand=operand,q_outer=q))
 run('stage-native' if native else 'stage-mega',cs,native)
if __name__=='__main__':
 for native in (False,True):stage_search(native)
