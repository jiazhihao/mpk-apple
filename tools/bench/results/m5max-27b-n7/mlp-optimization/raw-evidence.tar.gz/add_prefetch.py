from pathlib import Path
p=Path('monolith/compiler/static_fusion.py');s=p.read_text().replace('nvfp4_operand="standard"):', 'nvfp4_operand="standard", nvfp4_prefetch=0):',1)
s=s.replace("    if (nvfp4_operand not", "    if type(nvfp4_prefetch) is not int or nvfp4_prefetch not in (0,1,2,4) or (nvfp4_prefetch and (mode!='coop' or tk!=32 or nvfp4_layout!='tile')):\n        raise ValueError('NVFP4 prefetch requires packed cooperative TK32 operands')\n    if (nvfp4_operand not",1)
s=s.replace('nvfp4_operand=nvfp4_operand)', 'nvfp4_operand=nvfp4_operand,nvfp4_prefetch=nvfp4_prefetch)',1)
s=s.replace('scale_base,nvfp4_operand)', 'scale_base,nvfp4_operand,nvfp4_prefetch)',1)
p.write_text(s)
p=Path('monolith/compiler/nvfp4_tiles.py');s=p.read_text().replace('operand="standard"):', 'operand="standard", prefetch=0):',1)
s+='''
    if prefetch:
        depth=f'{prefetch}u'
        marker='for (uint16_t i = 0; i < cT.get_capacity(); i++) cT[i] = 0.0f;'
        setup=f"""
#if KSPLIT > 1
    const uint pf_begin=slice*KT_S,pf_end=(slice+1u)*KT_S;
#else
    const uint pf_begin=0u,pf_end=KT;
#endif
    uint ahead_codes[{depth}][NS_B],ahead_scales[{depth}][NS_B];
#pragma clang loop unroll(full)
    for(uint d=0;d<{depth};d++) {{
      uint kt=pf_begin+d;
      const ulong packed_tile=min(tile,p.tile0+p.n_tiles-1u);
      const ulong packed_group=(packed_tile/{tile_block}u*KT+kt)*{tile_block}u+packed_tile%{tile_block}u;
#pragma clang loop unroll(full)
      for(uint s=0;s<NS_B;s++) {{
        const uint e=0u;
        ahead_codes[kt%{depth}][s]=kt<pf_end?reinterpret_cast<device const uint*>(w)[(packed_group*NS_B+s)*32u+lane]:0u;
        ahead_scales[kt%{depth}][s]=kt<pf_end?reinterpret_cast<device const uchar*>(w)[NVFP4_SCALE_BASE+{scale}]:0u;
      }}
    }}
"""
        kernel.source=kernel.source.replace(marker,marker+setup,1)
        old='''+repr('''        uint4 words[NW];
#pragma clang loop unroll(full)
        for(uint i=0;i<NW;i++) {
          words[i]=uint4(0u);
#pragma clang loop unroll(full)
          for(uint j4=0;j4<min(4u,CT/8u);j4++)
            words[i][j4]=reinterpret_cast<device const uint*>(w)[((packed_group*NS_B+s)*32u+lane)*(CT/8u)+i*4u+j4];
        }''')+'''
        load=f"""uint current_scale=ahead_scales[kt%{depth}][s];
        uint4 words[1]={{uint4(ahead_codes[kt%{depth}][s],0u,0u,0u)}};
        if(kt+{depth}<pf_end) {{
          const ulong packed_group=(packed_tile/{tile_block}u*KT+kt+{depth})*{tile_block}u+packed_tile%{tile_block}u;
          const uint e=0u;
          ahead_codes[kt%{depth}][s]=reinterpret_cast<device const uint*>(w)[(packed_group*NS_B+s)*32u+lane];
          ahead_scales[kt%{depth}][s]=reinterpret_cast<device const uchar*>(w)[NVFP4_SCALE_BASE+{scale}];
        }}"""
        if old not in kernel.source:raise ValueError('NVFP4 prefetch operand loads not found')
        kernel.source=kernel.source.replace(old,load,1)
        kernel.source=kernel.source.replace(f'uint sc=reinterpret_cast<device const uchar*>(w)[NVFP4_SCALE_BASE+{scale}];','uint sc=current_scale;')
'''
p.write_text(s)
